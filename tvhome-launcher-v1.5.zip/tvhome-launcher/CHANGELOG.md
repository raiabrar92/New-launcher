# Changelog

## 1.5
- Left / Right switch between two side-by-side vertical lists: the quick menu on one side, the app list on the opposite side. App icons never disappear; only the highlighter moves between the lists. Back closes the quick menu.
- Quick menu: the WiFi row shows only the connected network name with the Wi-Fi logo (no "WiFi" label).
- Hide and Lock are one settings page ("Hide / Lock apps"): list of all apps with tick boxes, **Select all**, and **[Hide] [Lock]** side by side below the list. Locked apps show a lock icon beside them, hidden apps show a dark icon. Pressing the button on apps that are already hidden / locked undoes it (Unlock asks the PIN). "Change lock code" is on the same page.
- Screensaver (digital clock + calendar): clock/date, divider and calendar are spaced evenly from the left and right edges.

## 1.4
- Live stream: ad and promotion blocking (ad/tracker requests dropped, YouTube ad data stripped and ad overlays/end cards/suggestions hidden, ads skipped, pop-up redirects refused). Best effort: ads stitched into the video stream itself cannot be removed.
- Long-press app menu no longer shows the app name on top.
- Lock code is never shown. Changing it asks for the current PIN first (masked fields, confirm twice). App Lock settings open only after the PIN.
- Launcher Settings is now a menu of pages: Live stream links, Hidden Apps, App Lock, Wallpaper, Screensaver.
  - Hidden Apps: tick one by one or tick all, then Unhide or Lock.
  - App Lock: locked app list, tick one by one or tick all, then Unlock; Change lock code.
- Wallpaper: weather-matched wallpaper behind the home screen, source choice (Weather auto / Custom image / None), blur % (default 40), optional photo links per weather.
- Screensaver: Digital clock + calendar of the current month, Colors, Backdrop, Off, with a start-after timeout and Preview.
- Wi-Fi badge in the top corner above the clock: green + network name when connected, red + "Disconnected" for 10 s when not.
- Clock sits right above the date / temperature (weather icon above the temperature, small °C).
- Left key opens a quick menu in place of the app list: Optimize, WiFi, Bluetooth, Input Source, All Apps List, Launcher, Settings.
- Weather code moved to Weather.kt (now also returns day/night).

## 1.3
- Launcher Settings: unlimited stream links (first prefilled, "+ Add link" after filling the last one); "Play next stream after (min)" and "Muted play" side by side below the links; new App lock code setting.
- App menu: Rename, Change Icon (online), Lock / Unlock (PIN box in the app row, auto-verifies), Move, Hide, Info / Uninstall, Launcher Settings.
- Old link0..link4 settings are migrated automatically.

