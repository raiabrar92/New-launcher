# TV Home launcher

Google TV / Android TV home screen: full app list on the left, CPU / RAM / Storage
rings below it, Wi-Fi badge, big clock + live weather + date, and a muted LIVE tile on the right, over a
blurred wallpaper that follows the weather.

## Preview
Open `preview/preview.html` in any browser for an HTML replica of every screen (home, quick menu, app menu,
all settings pages, screensaver), same reference-pixel sizes as the Kotlin code. The v1.3 screenshots are kept in
`docs/screenshots-v1.3/` for reference. Android Studio users can also open `Previews.kt` for live Compose previews.

## Remote control
- **Up / Down** scroll the app list. **OK** opens the app.
- **Left** moves the highlighter to the quick menu, which appears beside the app list (the app list moves to the opposite side, its icons stay visible). **Right** moves the highlighter back to the apps; **Back** closes the quick menu. The highlighted quick item shows its name on the left of its icon.
  - **Optimize**: ends background processes of the other apps in the list to free RAM. The live stream, weather and the launcher run inside this launcher and are never touched. Android only lets an app end *background* processes, so an app that is actively playing is not force-stopped.
  - **WiFi** (shows the connected network name), **Bluetooth**, **Input Source** (lists the TV's HDMI / external inputs), **All Apps List** (system app list), **Launcher** (Launcher Settings), **Settings** (system settings).
- **Long-press OK** on an app opens a menu:
  - **Rename**: give the app your own name (empty / "Original name" restores it).
  - **Change Icon**: pick an icon found online for that app (Play Store listing icon, website favicons) or paste an image link. "Default icon" restores the original.
  - **Lock / Unlock**: locked apps show a lock icon and ask for the PIN before opening. When you select one and press OK, a PIN box appears in place of the app name and opens the app by itself as soon as the right code is typed. The code is set in Launcher Settings > Hide / Lock apps. Unlock also asks for the PIN.
  - **Move**: press Up / Down (hold to keep going), OK (or Back) drops it. Order is saved.
  - **Hide**: bring it back from Launcher Settings > Hide / Lock apps.
  - **Info / Uninstall**: opens the system app details page (Uninstall / Disable are there).
  - **Launcher Settings**.

## When the TV turns on / launcher resumes
Live stream restarts muted, the first app is highlighted, weather is refreshed
(retries every 10 s until the network is up).

## Launcher Settings
A menu of pages: **Live stream links**, **Hide / Lock apps**, **Wallpaper**, **Screensaver**, plus *Reset app order (A-Z)*.
- **Hide / Lock apps**: one list of all apps. Tick apps one by one or **Select all**, then press **Hide** or **Lock** (side by side below the list). Locked apps show a lock icon beside them; hidden apps show a dark icon. Pressing the button again on apps already hidden / locked shows **Unhide** / **Unlock** (Unlock asks the PIN). **Change lock code** is on the same page; the code is never shown and changing it needs the current PIN first.
- **Wallpaper**: *Weather (auto)* / *Custom image* / *None*, **Blur** (Left / Right on the remote, default 40 %), optional photo links per weather and a custom image link; **Download images** stores them on the TV. Without a photo the built-in scene for that weather is used.
- **Screensaver**: *Digital clock + calendar* (current month), *Colors*, *Backdrop*, *Off*; **Start after** 1 / 2 / 5 / 10 / 15 / 30 min of no remote input on the home screen; **Preview now**. Any button closes it.

## Live stream (Launcher Settings > Live stream links)
Unlimited links: the first is prefilled; once a link is filled in, **+ Add link** appears for the next one.
1 link = always plays that one. 2+ links = each plays for **Play next stream after (min)**
(default 1), then the next loads, looping. **Muted play** (default on) sits beside it.
The tile is not selectable and always fits the stream inside 16:9 (no cropping).
Ads and promotions are blocked (see CHANGELOG 1.4). This is best effort and untested against every YouTube change; ads stitched into the video stream itself cannot be removed.
Accepted links: YouTube (watch / live / youtu.be / embed / channel), direct
.m3u8 / .mp4 streams, or any web page.

## Wi-Fi badge
Top corner above the clock. Green icon + network name when connected; red icon + "Disconnected" for 10 s, then just the red icon. Android only gives the network name to apps with the location permission, so the launcher asks for it once on first start. If it is refused the badge shows "Wi-Fi".

## System status
RAM and Storage are exact. CPU: Android 8+ blocks apps from reading /proc/stat on
most devices, so the app falls back to average CPU clock vs max clock; if neither
is readable the CPU ring shows "--".

## Layout
Left: app list (or quick menu) + compact status rings. Right (540 ref px wide): Wi-Fi badge, clock, weather/date right under the clock, 16:9 muted live tile at the bottom. The stream is always
scaled to fit inside the tile (letterboxed, never cropped).

## Build
Push to GitHub; the **Build TV Home launcher** workflow produces the APK artifact.
Or locally: `gradle :app:assembleRelease`.

## Install
```
adb connect <tv-ip>:5555
adb install -r app-release.apk
```

## Customize
- Weather location: `LATITUDE` / `LONGITUDE` at the top of `Weather.kt`.
