package com.raiabrar.tvhome

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

/**
 * Keeps ads and promotions out of the live tile, like an ad blocker (Brave, TizenTube):
 *  1. Ad / tracker network requests are answered with an empty reply, so they never load.
 *  2. For YouTube, a script runs inside the player at page start: it strips the ad data from the
 *     player responses (the TizenTube method), hides the ad / end-card / suggestion overlays and
 *     skips any ad that still starts.
 *  3. Pop-up style redirects away from the stream are refused.
 * Best effort: ads that YouTube stitches into the video stream itself cannot be removed.
 */
internal object AdBlock {
    private val blockedHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "googletagservices.com",
        "adservice.google.", "2mdn.net", "imasdk.googleapis.com", "moatads.com", "adnxs.com",
        "amazon-adsystem.com", "adsafeprotected.com", "taboola.com", "outbrain.com", "adform.net",
        "exoclick.com", "popads.net", "propellerads.com", "scorecardresearch.com", "criteo.com",
    )
    private val blockedPaths = listOf(
        "/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll_", "/api/stats/atr?ads",
    )

    fun isAd(url: String): Boolean {
        val u = url.lowercase()
        val host = u.substringAfter("://", u).substringBefore('/').substringBefore('?')
        if (blockedHosts.any { host.contains(it) }) return true
        return (host.contains("youtube.com") || host.contains("youtube-nocookie.com")) &&
            blockedPaths.any { u.contains(it) }
    }

    fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    /** Runs inside the YouTube player (embed) before its own scripts. */
    private val YOUTUBE_SCRIPT = """
        (function () {
          if (window.__tvhomeAd) return; window.__tvhomeAd = 1;
          var KEYS = ['adPlacements', 'playerAds', 'adSlots', 'adBreakHeartbeatParams'];
          function strip(o) {
            if (!o || typeof o !== 'object') return o;
            for (var i = 0; i < KEYS.length; i++) {
              if (KEYS[i] in o) { try { delete o[KEYS[i]]; } catch (e) { o[KEYS[i]] = undefined; } }
            }
            return o;
          }
          function clean(r) { try { strip(r); if (r && r.playerResponse) strip(r.playerResponse); } catch (e) {} return r; }
          var pj = JSON.parse;
          JSON.parse = function () { return clean(pj.apply(this, arguments)); };
          if (window.Response && Response.prototype.json) {
            var rj = Response.prototype.json;
            Response.prototype.json = function () { return rj.apply(this, arguments).then(clean); };
          }
          try {
            var ipr;
            Object.defineProperty(window, 'ytInitialPlayerResponse', {
              configurable: true, get: function () { return ipr; }, set: function (v) { ipr = strip(v); }
            });
          } catch (e) {}
          var css = '.ytp-ad-module,.video-ads,.ytp-ad-overlay-container,.ytp-ad-overlay-slot,' +
            '.ytp-ce-element,.ytp-cards-teaser,.ytp-cards-button,.ytp-pause-overlay,.ytp-endscreen-content,' +
            '.ytp-suggested-action,.ytp-paid-content-overlay,.ytp-impression-link,.ytp-youtube-button,' +
            '.ytp-watermark,.ytp-chrome-top,.ytp-gradient-top,.ytp-videowall-still,.ytp-ad-skip-button-slot,' +
            '.ytp-ad-persistent-progress-bar-container{display:none!important}';
          function addCss() {
            var s = document.createElement('style'); s.textContent = css;
            (document.head || document.documentElement).appendChild(s);
          }
          if (document.documentElement) addCss(); else document.addEventListener('DOMContentLoaded', addCss);
          setInterval(function () {
            try {
              var p = document.querySelector('.html5-video-player');
              var v = document.querySelector('video');
              var ad = p && (p.classList.contains('ad-showing') || p.classList.contains('ad-interrupting'));
              if (ad && v) {
                v.muted = true; v.playbackRate = 16;
                if (isFinite(v.duration) && v.duration > 0) v.currentTime = v.duration;
              }
              var b = document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button');
              if (b) b.click();
              var o = document.querySelector('.ytp-ad-overlay-close-button');
              if (o) o.click();
            } catch (e) {}
          }, 250);
        })();
    """.trimIndent()

    /** For ordinary web pages: hides common ad containers. */
    const val GENERIC_JS =
        "(function(){var s=document.getElementById('__tvhome_noads');if(s)return;s=document.createElement('style');" +
            "s.id='__tvhome_noads';s.textContent='ins.adsbygoogle,[id*=\"google_ads\"],[id^=\"div-gpt-ad\"]," +
            "iframe[src*=\"doubleclick\"],iframe[src*=\"googlesyndication\"],[class*=\"advert\"],[id*=\"advert\"]," +
            "[class*=\"sponsor\"],[aria-label=\"Advertisement\"]{display:none!important}';" +
            "(document.head||document.documentElement).appendChild(s);})();"

    /** Installs the YouTube script so it runs in the player frame before the page's own scripts. */
    fun install(wv: WebView) {
        runCatching {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(
                    wv, YOUTUBE_SCRIPT,
                    setOf("https://www.youtube.com", "https://www.youtube-nocookie.com", "https://m.youtube.com"),
                )
            }
        }
    }
}

/** WebView client that drops ad requests and (in strict mode) refuses redirects away from the stream. */
internal class AdBlockClient(private val muted: () -> Boolean) : WebViewClient() {
    /** True for YouTube / direct streams: the page must never navigate away on its own. */
    @Volatile var strict = true
    /** True for ordinary web pages: also hide common ad containers. */
    @Volatile var generic = false

    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
        val u = request?.url?.toString() ?: return null
        return if (AdBlock.isAd(u)) AdBlock.empty() else null
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = strict

    override fun onPageFinished(view: WebView?, url: String?) {
        view?.evaluateJavascript(mediaJs(muted()) + if (generic) AdBlock.GENERIC_JS else "", null)
    }
}
