package com.raiabrar.tvhome

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** All launchable apps, user order, hidden / locked sets. Persisted in SharedPreferences. */
internal class AppsModel(ctx: Context) : SettingsHost {
    private val pm = ctx.packageManager
    private val self = ctx.packageName
    val prefs = Prefs(ctx)

    var labels by mutableStateOf<Map<String, String>>(emptyMap())
    val order = mutableStateListOf<String>()
    var hidden by mutableStateOf(prefs.hidden)
    var locked by mutableStateOf(prefs.locked)
    var names by mutableStateOf(prefs.names)
    private var pinState by mutableStateOf(prefs.pin)

    init { refresh() }

    val visible: List<String> get() = order.filter { it !in hidden }

    fun refresh() {
        val found = LinkedHashMap<String, String>()
        for (category in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(q, PackageManager.MATCH_ALL)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == self || pkg in found) continue
                found[pkg] = ri.loadLabel(pm).toString()
            }
        }
        val saved = prefs.order.filter { it in found }
        val fresh = found.keys.filter { it !in saved }.sortedBy { found[it]!!.lowercase() }
        labels = found
        order.clear()
        order.addAll(saved + fresh)
        prefs.order = order.toList()
        hidden = prefs.hidden
        locked = prefs.locked
        names = prefs.names
        pinState = prefs.pin
    }

    /** Custom name if the user renamed the app, else its own label. */
    fun displayName(pkg: String): String = names[pkg]?.takeIf { it.isNotBlank() } ?: labels[pkg] ?: pkg

    fun rename(pkg: String, name: String) {
        val n = name.trim()
        names = if (n.isEmpty() || n == labels[pkg]) names - pkg else names + (pkg to n)
        prefs.names = names
    }

    fun lock(pkg: String) { locked = locked + pkg; prefs.locked = locked }
    fun unlock(pkg: String) { locked = locked - pkg; prefs.locked = locked }

    /** Swap with the nearest visible neighbour up (-1) or down (+1). */
    fun move(pkg: String, delta: Int): Boolean {
        val i = order.indexOf(pkg)
        if (i < 0) return false
        var j = i + delta
        while (j in order.indices && order[j] in hidden) j += delta
        if (j !in order.indices) return false
        val t = order[i]
        order[i] = order[j]
        order[j] = t
        prefs.order = order.toList()
        return true
    }

    fun hide(pkg: String) { hidden = hidden + pkg; prefs.hidden = hidden }

    // ---- SettingsHost ----
    override val pin: String get() = pinState

    override fun setPin(v: String) { pinState = v; prefs.pin = v }

    /** Every app in launcher order, for the Hide / Lock page. */
    override val apps: List<AppEntry>
        get() = order.mapNotNull { p -> labels[p]?.let { AppEntry(p, displayName(p)) } }

    override val hiddenSet: Set<String> get() = hidden
    override val lockedSet: Set<String> get() = locked

    override fun hide(pkgs: Set<String>) { hidden = hidden + pkgs; prefs.hidden = hidden }
    override fun unhide(pkgs: Set<String>) { hidden = hidden - pkgs; prefs.hidden = hidden }
    override fun lock(pkgs: Set<String>) { locked = locked + pkgs; prefs.locked = locked }
    override fun unlock(pkgs: Set<String>) { locked = locked - pkgs; prefs.locked = locked }

    override fun resetOrder() {
        val sorted = order.sortedBy { displayName(it).lowercase() }
        order.clear()
        order.addAll(sorted)
        prefs.order = order.toList()
    }
}
