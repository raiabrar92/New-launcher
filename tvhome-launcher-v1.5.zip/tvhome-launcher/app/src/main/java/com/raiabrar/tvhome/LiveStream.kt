package com.raiabrar.tvhome

import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.delay

/** Live preview tile: not focusable and not clickable. Muted unless turned off in settings. */
@Composable
internal fun LiveCard(
    links: List<String>, intervalMin: Int, muted: Boolean, refreshKey: Int, modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(12.u())
    Box(
        modifier
            .clip(shape)
            .background(ThumbColor)
            // Border is drawn over the content, so the stream area stays exactly 16:9.
            .border(2.u(), LineColor, shape)
    ) {
        LivePreview(links, intervalMin, muted, refreshKey)
    }
}

private const val LIVE_PAGE = "https://live.geo.tv/"

// controls=0 / iv_load_policy=3 / rel=0 already remove controls, annotations and suggestions;
// AdBlock removes the ads themselves.
private fun ytParams(muted: Boolean) =
    "autoplay=1&mute=${if (muted) 1 else 0}&controls=0&fs=0&disablekb=1&cc_load_policy=0&iv_load_policy=3&playsinline=1&rel=0&modestbranding=1"

// Videos on any page: always "contain" (whole picture visible, no crop); muted when asked.
internal fun mediaJs(muted: Boolean): String =
    (if (muted) "document.querySelectorAll('video,audio').forEach(function(v){v.muted=true;v.volume=0;});" else "") +
        "document.querySelectorAll('video').forEach(function(v){v.style.objectFit='contain';});"

private fun youTubeSrc(u: String, muted: Boolean): String? {
    val params = ytParams(muted)
    Regex("""(?:youtu\.be/|youtube(?:-nocookie)?\.com/(?:watch\?(?:[^#]*&)?v=|embed/|live/|shorts/|v/))([A-Za-z0-9_-]{11})""")
        .find(u)?.let { return "https://www.youtube.com/embed/${it.groupValues[1]}?$params" }
    Regex("""youtube\.com/channel/(UC[A-Za-z0-9_-]{22})""")
        .find(u)?.let { return "https://www.youtube.com/embed/live_stream?channel=${it.groupValues[1]}&$params" }
    if (Regex("^[A-Za-z0-9_-]{11}$").matches(u)) return "https://www.youtube.com/embed/$u?$params"
    return null
}

private fun isMediaFile(u: String): Boolean {
    val path = u.substringBefore('?').lowercase()
    return path.endsWith(".m3u8") || path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".ts")
}

private fun loadLive(wv: WebView, raw: String, muted: Boolean, client: AdBlockClient) {
    val url = raw.trim()
    val yt = youTubeSrc(url, muted)
    when {
        yt != null -> {
            client.strict = true
            client.generic = false
            // Best fit: the largest 16:9 frame that fits inside the tile, centered, never cropped.
            val html = """
                <html><body style="margin:0;background:#000;overflow:hidden">
                <div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center">
                <iframe style="border:0;pointer-events:none;
                  width:min(100vw,calc(100vh*1.7778));height:min(100vh,calc(100vw*0.5625))"
                  allow="autoplay; encrypted-media" src="$yt">
                </iframe></div></body></html>
            """.trimIndent()
            wv.loadDataWithBaseURL(LIVE_PAGE, html, "text/html", "utf-8", null)
        }
        isMediaFile(url) -> {
            client.strict = true
            client.generic = false
            val safe = url.replace("\"", "%22")
            val html = """
                <html><body style="margin:0;background:#000;overflow:hidden">
                <video src="$safe" autoplay ${if (muted) "muted" else ""} loop playsinline
                  style="position:fixed;inset:0;width:100%;height:100%;object-fit:contain"></video>
                </body></html>
            """.trimIndent()
            wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "utf-8", null)
        }
        else -> {
            client.strict = false
            client.generic = true
            wv.loadUrl(if (url.startsWith("http")) url else "https://$url")
        }
    }
}

@Composable
private fun LivePreview(links: List<String>, intervalMin: Int, muted: Boolean, refreshKey: Int) {
    val clean = links.map { it.trim() }.filter { it.isNotEmpty() }
    var index by remember { mutableIntStateOf(0) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    val mutedNow by rememberUpdatedState(muted)
    val client = remember { AdBlockClient { mutedNow } }

    // 1 link: always that one. 2+ links: intervalMin minutes each, then the next (playlist).
    LaunchedEffect(clean, refreshKey, intervalMin) {
        index = 0
        if (clean.size > 1) {
            while (true) {
                delay(intervalMin.coerceAtLeast(1) * 60_000L)
                index = (index + 1) % clean.size
            }
        }
    }
    // Keep media muted (if enabled) and fitted (covers generic web pages with their own <video>).
    LaunchedEffect(webView, muted) {
        while (true) {
            webView?.evaluateJavascript(mediaJs(muted) + if (client.generic) AdBlock.GENERIC_JS else "", null)
            delay(2000)
        }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { webView?.onPause() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { webView?.onResume() }

    if (clean.isEmpty()) return
    val url = clean[index % clean.size]

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            WebView(c).apply {
                // Not selectable: the tile never takes focus or clicks.
                isFocusable = false
                isFocusableInTouchMode = false
                isClickable = false
                setOnTouchListener { _, _ -> true }
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                // No pop-up windows: ads cannot open new pages.
                settings.setSupportMultipleWindows(false)
                settings.javaScriptCanOpenWindowsAutomatically = false
                // Generic web pages: shrink the page to fit the tile instead of cropping it.
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                AdBlock.install(this)
                webViewClient = client
            }
        },
        update = { w ->
            if (webView !== w) webView = w
            val key = "$url|$refreshKey|$muted"
            if (w.tag != key) {
                w.tag = key
                loadLive(w, url, muted, client)
            }
        },
        onRelease = { it.destroy() },
    )
}
