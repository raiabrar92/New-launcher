package com.raiabrar.tvhome

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.delay

internal data class NetState(val connected: Boolean, val name: String)

private fun describe(ctx: Context, caps: NetworkCapabilities?): NetState {
    if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
        return NetState(false, "Disconnected")
    }
    if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return NetState(true, "Ethernet")
    if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
        var ssid: String? = null
        if (Build.VERSION.SDK_INT >= 29) {
            ssid = (caps.transportInfo as? WifiInfo)?.ssid
        }
        if (ssid.isNullOrBlank() || ssid == WifiManager.UNKNOWN_SSID) {
            ssid = runCatching {
                @Suppress("DEPRECATION")
                (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo?.ssid
            }.getOrNull()
        }
        val clean = ssid?.trim('"')?.takeIf { it.isNotBlank() && it != WifiManager.UNKNOWN_SSID }
        // Android hides the Wi-Fi name without the location permission; show a generic label then.
        return NetState(true, clean ?: "Wi-Fi")
    }
    return NetState(true, "Connected")
}

/** Live network state: updates the moment the TV connects or loses the network. */
@Composable
internal fun rememberNetState(): NetState {
    val ctx = LocalContext.current
    var state by remember { mutableStateOf(NetState(false, "Disconnected")) }
    DisposableEffect(ctx) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        // Show the real state straight away (the callback below may take a moment).
        state = describe(ctx, cm.getNetworkCapabilities(cm.activeNetwork))
        val cb: ConnectivityManager.NetworkCallback =
            if (Build.VERSION.SDK_INT >= 31) {
                object : ConnectivityManager.NetworkCallback(ConnectivityManager.NetworkCallback.FLAG_INCLUDE_LOCATION_INFO) {
                    override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                        state = describe(ctx, caps)
                    }
                    override fun onLost(network: Network) { state = describe(ctx, null) }
                }
            } else {
                object : ConnectivityManager.NetworkCallback() {
                    override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                        state = describe(ctx, caps)
                    }
                    override fun onLost(network: Network) { state = describe(ctx, null) }
                }
            }
        runCatching { cm.registerDefaultNetworkCallback(cb) }
        onDispose { runCatching { cm.unregisterNetworkCallback(cb) } }
    }
    return state
}

/**
 * Top-corner Wi-Fi badge. Green icon + network name when connected. Red icon + "Disconnected"
 * when not; the words show for 10 seconds, then only the red icon stays.
 */
@Composable
internal fun WifiBadge(modifier: Modifier = Modifier, net: NetState = rememberNetState()) {
    var showName by remember { mutableStateOf(true) }
    LaunchedEffect(net.connected) {
        showName = true
        if (!net.connected) {
            delay(10_000)
            showName = false
        }
    }
    val tint = if (net.connected) WifiGreen else WifiRed
    Row(
        modifier.height(30.u()),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (showName) {
            Text(
                if (net.connected) net.name else "Disconnected",
                color = TextPrimary, fontSize = 20.us(), maxLines = 1, fontWeight = FontWeight.Medium,
                style = TextStyle(lineHeight = 24.us(), lineHeightStyle = MidLine),
            )
            Spacer(Modifier.width(10.u()))
        }
        Icon(
            if (net.connected) Icons.Outlined.Wifi else Icons.Outlined.WifiOff,
            contentDescription = null, tint = tint, modifier = Modifier.size(28.u()),
        )
    }
}
