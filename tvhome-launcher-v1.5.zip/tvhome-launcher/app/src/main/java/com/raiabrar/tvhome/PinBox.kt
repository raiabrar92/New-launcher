@file:OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)

package com.raiabrar.tvhome

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.delay

private val WrongColor = Color(0xFFE57373)

/**
 * PIN entry that replaces the app name inside the highlighted app row. It is as tall as the
 * app icon, so it fits the highlighted area exactly. Verifies by itself as soon as the
 * entered digits equal the lock code. Leaving the box (focus lost) cancels.
 */
@Composable
internal fun PinBox(pin: String, onOk: () -> Unit, onCancel: () -> Unit, modifier: Modifier = Modifier) {
    var text by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var had by remember { mutableStateOf(false) }
    val requester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val shape = RoundedCornerShape(10.u())

    LaunchedEffect(Unit) {
        delay(150)
        runCatching { requester.requestFocus() }
        keyboard?.show()
    }

    Box(
        modifier
            .height(50.u())
            .clip(shape)
            .background(Color(0xFF14161B))
            .border(2.u(), if (wrong) WrongColor else TextPrimary, shape)
            .padding(horizontal = 16.u()),
        contentAlignment = Alignment.CenterStart,
    ) {
        BasicTextField(
            value = text,
            onValueChange = { v ->
                val d = v.filter { it.isDigit() }.take(8)
                wrong = false
                text = d
                if (d.isNotEmpty() && d == pin) {
                    onOk()
                } else if (d.length >= pin.length) {
                    text = ""
                    wrong = true
                }
            },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation('\u2022'),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            textStyle = TextStyle(
                color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium,
                letterSpacing = 4.us(), lineHeight = 32.us(), lineHeightStyle = MidLine,
            ),
            cursorBrush = SolidColor(TextPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(requester)
                .onFocusChanged { s ->
                    if (s.isFocused) had = true else if (had) onCancel()
                },
            decorationBox = { inner ->
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                    if (text.isEmpty()) {
                        Text(
                            if (wrong) "Wrong PIN" else "Enter PIN",
                            color = if (wrong) WrongColor else TextDim, fontSize = 22.us(), maxLines = 1,
                            style = TextStyle(lineHeight = 28.us(), lineHeightStyle = MidLine),
                        )
                    }
                    inner()
                }
            },
        )
    }
}
