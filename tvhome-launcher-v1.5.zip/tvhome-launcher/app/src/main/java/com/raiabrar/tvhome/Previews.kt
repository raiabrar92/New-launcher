package com.raiabrar.tvhome

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

// Android Studio previews (open this file and use the Split / Design view).
// Panel is the 990 x 619 reference size, so LocalScale = 1.

@Composable
private fun PreviewFrame(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalScale provides 1f) {
        Box(Modifier.fillMaxSize().background(BgColor)) { content() }
    }
}

private class FakeHost(
    override val pin: String = "1234",
    override val apps: List<AppEntry> = listOf(
        AppEntry("a.b.one", "YouTube"), AppEntry("a.b.two", "Netflix"), AppEntry("a.b.three", "Play Store"),
        AppEntry("a.b.four", "Files"), AppEntry("a.b.five", "Prime Video"),
    ),
    override val hiddenSet: Set<String> = setOf("a.b.three", "a.b.four"),
    override val lockedSet: Set<String> = setOf("a.b.two", "a.b.five"),
) : SettingsHost {
    override fun setPin(v: String) {}
    override fun hide(pkgs: Set<String>) {}
    override fun unhide(pkgs: Set<String>) {}
    override fun lock(pkgs: Set<String>) {}
    override fun unlock(pkgs: Set<String>) {}
    override fun resetOrder() {}
}

@Composable
private fun SettingsPreview(page: SettingsPage, host: SettingsHost = FakeHost()) {
    LauncherSettings(
        page = page, onPage = {},
        host = host, prefs = Prefs(LocalContext.current),
        links = listOf(DEFAULT_LINK, "https://example.com/live.m3u8"), onLinks = {},
        intervalMin = 1, onIntervalMin = {},
        muted = true, onMuted = {},
        wallMode = "weather", onWallMode = {},
        blurPct = 40, onBlurPct = {},
        saverType = "clock", onSaverType = {},
        saverMin = 5, onSaverMin = {},
        onPreviewSaver = {}, onClose = {},
    )
}

@Preview(name = "Settings - main", widthDp = 990, heightDp = 619)
@Composable
private fun SettingsMainPreview() = PreviewFrame { SettingsPreview(SettingsPage.Main) }

@Preview(name = "Settings - Live stream links", widthDp = 990, heightDp = 700)
@Composable
private fun SettingsLinksPreview() = PreviewFrame { SettingsPreview(SettingsPage.Links) }

@Preview(name = "Settings - Hide / Lock apps", widthDp = 990, heightDp = 619)
@Composable
private fun SettingsAppsPreview() = PreviewFrame { SettingsPreview(SettingsPage.Apps) }

@Preview(name = "Settings - Wallpaper", widthDp = 990, heightDp = 1300)
@Composable
private fun SettingsWallpaperPreview() = PreviewFrame { SettingsPreview(SettingsPage.Wallpaper) }

@Preview(name = "Settings - Screensaver", widthDp = 990, heightDp = 619)
@Composable
private fun SettingsSaverPreview() = PreviewFrame { SettingsPreview(SettingsPage.Saver) }

@Preview(name = "Screensaver - clock + calendar", widthDp = 990, heightDp = 619)
@Composable
private fun SaverPreview() = PreviewFrame { Screensaver("clock") }

@Preview(name = "Wi-Fi badge - connected", widthDp = 400, heightDp = 60)
@Composable
private fun WifiOkPreview() = PreviewFrame {
    Box(Modifier.padding(10.dp)) { WifiBadge(net = NetState(true, "Home WiFi")) }
}

@Preview(name = "Wi-Fi badge - disconnected", widthDp = 400, heightDp = 60)
@Composable
private fun WifiOffPreview() = PreviewFrame {
    Box(Modifier.padding(10.dp)) { WifiBadge(net = NetState(false, "Disconnected")) }
}

@Preview(name = "PIN box", widthDp = 340, heightDp = 90)
@Composable
private fun PinBoxPreview() = PreviewFrame {
    Box(Modifier.padding(20.dp)) {
        PinBox(pin = "1234", onOk = {}, onCancel = {})
    }
}
