package com.raiabrar.tvhome

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Bluetooth
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SettingsInputHdmi
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

internal enum class QuickAction(val label: String, val icon: ImageVector) {
    OPTIMIZE("Optimize", Icons.Outlined.CleaningServices),
    // The WiFi row never shows this label: it shows the connected network name instead.
    WIFI("WiFi", Icons.Outlined.Wifi),
    BLUETOOTH("Bluetooth", Icons.Outlined.Bluetooth),
    INPUT("Input Source", Icons.Outlined.SettingsInputHdmi),
    ALL_APPS("All Apps List", Icons.Outlined.Apps),
    LAUNCHER("Launcher", Icons.Outlined.Home),
    SETTINGS("Settings", Icons.Outlined.Settings),
}

/** Width of a list column that shows icons only (reference px): icon + its side padding. */
internal const val ICON_COL = 82f

/**
 * The quick menu list. It sits next to the app list (apps move to the opposite side, their icons stay
 * visible) and the highlighter moves between the two lists with Left / Right. Same look and behaviour as
 * the app list, mirrored: the icon is on the right of its row and the highlighted item shows its name
 * on the left of the icon. The WiFi row shows the connected network name.
 *
 * [focusTick] changes whenever the list should take the highlighter.
 */
@Composable
internal fun QuickMenu(
    wifiLabel: String,
    focusTick: Int,
    onAction: (QuickAction) -> Unit,
    onFocused: () -> Unit,
    onRight: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val actions = remember { QuickAction.values().toList() }
    val requesters = remember { actions.map { FocusRequester() } }
    var lastIdx by remember { mutableIntStateOf(0) }
    LaunchedEffect(focusTick) {
        if (focusTick > 0) {
            delay(80)
            runCatching { requesters[lastIdx].requestFocus() }
        }
    }
    LazyColumn(
        modifier,
        verticalArrangement = Arrangement.spacedBy(11.u()),
        contentPadding = PaddingValues(vertical = 3.u()),
    ) {
        itemsIndexed(actions) { i, a ->
            QuickRow(
                a, if (a == QuickAction.WIFI) wifiLabel else a.label, requesters[i],
                onFocused = { lastIdx = i; onFocused() },
                onClick = { onAction(a) },
                onRight = onRight,
            )
        }
    }
}

@Composable
private fun QuickRow(
    a: QuickAction,
    label: String,
    requester: FocusRequester,
    onFocused: () -> Unit,
    onClick: () -> Unit,
    onRight: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(13.u())
    Row(
        Modifier
            .fillMaxWidth()
            .height(77.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color.Transparent)
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .focusRequester(requester)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocused() }
            .onPreviewKeyEvent { ev ->
                when (ev.key) {
                    Key.DirectionRight -> { if (ev.type == KeyEventType.KeyDown) onRight(); true }
                    Key.DirectionLeft -> true
                    else -> false
                }
            }
            .clickable(onClick = onClick)
            .padding(start = 12.u(), end = 19.5f.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (focused) {
            Text(
                label, color = TextPrimary, fontSize = 27.us(), fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End,
                style = TextStyle(lineHeight = 34.us(), lineHeightStyle = MidLine),
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(16.u()))
        } else {
            Spacer(Modifier.weight(1f))
        }
        Box(Modifier.size(50.u()), contentAlignment = Alignment.Center) {
            Icon(
                a.icon, contentDescription = label,
                tint = if (focused) TextPrimary else DateColor, modifier = Modifier.size(40.u()),
            )
        }
    }
}

// ---- Actions -------------------------------------------------------------------------------

/** Tries each system screen in turn; tells the user if the TV has none of them. */
internal fun openSystem(ctx: Context, vararg actions: String) {
    for (a in actions) {
        val ok = runCatching {
            ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        }.getOrDefault(false)
        if (ok) return
    }
    Toast.makeText(ctx, "Not available on this TV", Toast.LENGTH_SHORT).show()
}

/**
 * Frees RAM by ending the background processes of the apps in the app list. The live stream, the
 * weather and the launcher itself run inside this launcher, so they are never touched. Android only
 * lets an app end the background (not the foreground) processes of other apps, so this cannot
 * force-stop an app that is actively playing. Returns roughly how many MB became free.
 */
internal suspend fun optimizeMemory(ctx: Context, packages: List<String>): Long {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    fun avail(): Long = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
    val before = avail()
    withContext(Dispatchers.Default) {
        for (p in packages) {
            if (p == ctx.packageName) continue
            runCatching { am.killBackgroundProcesses(p) }
        }
    }
    delay(1200)
    return ((avail() - before) / (1024L * 1024L)).coerceAtLeast(0L)
}
