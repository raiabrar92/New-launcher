package com.raiabrar.tvhome

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Full-screen screensaver. Any remote key closes it (handled in MainActivity). */
@Composable
internal fun Screensaver(type: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(Color.Black)) {
        when (type) {
            "colors" -> ColorsSaver()
            "backdrop" -> BackdropSaver()
            else -> ClockCalendarSaver()
        }
    }
}

/** Slowly drifting solid colour, like the Google TV "Colors" screensaver. */
@Composable
private fun ColorsSaver() {
    val t = rememberInfiniteTransition(label = "colors")
    val hue by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(90_000, easing = LinearEasing), RepeatMode.Restart),
        label = "hue",
    )
    Box(Modifier.fillMaxSize().background(Color.hsv(hue, 0.55f, 0.42f)))
}

/** Slow slideshow of the weather scenes, like the Google TV "Backdrop" screensaver. */
@Composable
private fun BackdropSaver() {
    val scenes = remember { WallCond.values().toList() }
    var idx by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(12_000)
            idx = (idx + 1) % scenes.size
        }
    }
    Crossfade(targetState = idx, animationSpec = tween(2500), label = "backdrop") { i ->
        WallpaperLayer(scenes[i], "weather", 0, Modifier.fillMaxSize())
    }
}

/** Big digital clock with a calendar of the current month. Shifts a little every minute (burn-in safe). */
@Composable
private fun ClockCalendarSaver() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000)
        }
    }
    val slot = (now.time / 60_000L).toInt()
    val dx = listOf(-14, 0, 14, 0)[slot % 4]   // tiny shifts keep the screen burn-in safe
    val dy = listOf(-8, 8, 0, -4)[(slot / 4) % 4]
    val time = SimpleDateFormat("h:mm", Locale.getDefault()).format(now)
    val ampm = SimpleDateFormat("a", Locale.ENGLISH).format(now).uppercase(Locale.ENGLISH)
    val date = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.ENGLISH).format(now)

    // SpaceEvenly: the gap left of the clock, between clock and divider, between divider and calendar,
    // and right of the calendar are all the same.
    Row(
        Modifier.fillMaxSize().offset(dx.u(), dy.u()),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    time, color = TextPrimary, fontSize = 128.us(), fontWeight = FontWeight.Medium,
                    letterSpacing = (-4).us(), maxLines = 1, softWrap = false,
                    style = TextStyle(lineHeight = 140.us(), lineHeightStyle = CenterLine),
                )
                Spacer(Modifier.width(10.u()))
                Text(
                    ampm, color = DateColor, fontSize = 30.us(), maxLines = 1,
                    style = TextStyle(lineHeight = 36.us(), lineHeightStyle = CenterLine),
                    modifier = Modifier.offset(y = (-22).u()),
                )
            }
            Text(date, color = DateColor, fontSize = 26.us(), maxLines = 1)
        }
        Box(Modifier.width(2.u()).height(280.u()).background(LineColor))
        MonthCalendar(now)
    }
}

@Composable
private fun MonthCalendar(now: Date) {
    val cal = Calendar.getInstance().apply { time = now }
    val today = cal.get(Calendar.DAY_OF_MONTH)
    val first = cal.firstDayOfWeek // 1 = Sunday
    val firstOfMonth = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
    val offset = (firstOfMonth.get(Calendar.DAY_OF_WEEK) - first + 7) % 7
    val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val rows = (offset + days + 6) / 7
    val letters = listOf("S", "M", "T", "W", "T", "F", "S")
    val title = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(now)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = TextPrimary, fontSize = 30.us(), fontWeight = FontWeight.Medium, maxLines = 1)
        Spacer(Modifier.height(12.u()))
        Row {
            for (i in 0 until 7) {
                Box(Modifier.size(52.u(), 36.u()), contentAlignment = Alignment.Center) {
                    Text(letters[(first - 1 + i) % 7], color = TextDim, fontSize = 19.us())
                }
            }
        }
        for (r in 0 until rows) {
            Row {
                for (c in 0 until 7) {
                    val d = r * 7 + c - offset + 1
                    Box(Modifier.size(52.u(), 46.u()), contentAlignment = Alignment.Center) {
                        if (d in 1..days) {
                            val isToday = d == today
                            Box(
                                Modifier.size(40.u()).clip(CircleShape)
                                    .background(if (isToday) TextPrimary else Color.Transparent),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    "$d", color = if (isToday) BgColor else DateColor, fontSize = 22.us(),
                                    fontWeight = if (isToday) FontWeight.Medium else FontWeight.Normal,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
