package com.raiabrar.tvhome

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Pages of Launcher Settings. */
internal enum class SettingsPage { Main, Links, Apps, Wallpaper, Saver }

internal class AppEntry(val pkg: String, val name: String)

/** What the Hide / Lock page needs from the launcher. */
internal interface SettingsHost {
    val pin: String
    /** All apps in launcher order. */
    val apps: List<AppEntry>
    val hiddenSet: Set<String>
    val lockedSet: Set<String>
    fun setPin(v: String)
    fun hide(pkgs: Set<String>)
    fun unhide(pkgs: Set<String>)
    fun lock(pkgs: Set<String>)
    fun unlock(pkgs: Set<String>)
    fun resetOrder()
}

private val SAVER_MINUTES = listOf(1, 2, 5, 10, 15, 30)

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedBorderColor = TextPrimary,
    unfocusedBorderColor = LineColor,
    focusedLabelColor = TextPrimary,
    unfocusedLabelColor = TextDim,
    cursorColor = TextPrimary,
)

@Composable
internal fun LauncherSettings(
    page: SettingsPage,
    onPage: (SettingsPage) -> Unit,
    host: SettingsHost,
    prefs: Prefs,
    links: List<String>,
    onLinks: (List<String>) -> Unit,
    intervalMin: Int,
    onIntervalMin: (Int) -> Unit,
    muted: Boolean,
    onMuted: (Boolean) -> Unit,
    wallMode: String,
    onWallMode: (String) -> Unit,
    blurPct: Int,
    onBlurPct: (Int) -> Unit,
    saverType: String,
    onSaverType: (String) -> Unit,
    saverMin: Int,
    onSaverMin: (Int) -> Unit,
    onPreviewSaver: () -> Unit,
    onClose: () -> Unit,
) {
    val back = { onPage(SettingsPage.Main) }
    when (page) {
        SettingsPage.Main -> MainPage(
            host = host, linkCount = links.size, intervalMin = intervalMin, muted = muted,
            wallMode = wallMode, blurPct = blurPct, saverType = saverType, saverMin = saverMin,
            onPage = onPage, onClose = onClose,
        )
        SettingsPage.Links -> LinksPage(
            links, onLinks, intervalMin, onIntervalMin, muted, onMuted, onBack = back,
        )
        SettingsPage.Apps -> AppsPage(host, onBack = back)
        SettingsPage.Wallpaper -> WallpaperPage(prefs, wallMode, onWallMode, blurPct, onBlurPct, onBack = back)
        SettingsPage.Saver -> SaverPage(saverType, onSaverType, saverMin, onSaverMin, onPreviewSaver, onBack = back)
    }
}

// ---- Main menu -------------------------------------------------------------------------------

@Composable
private fun MainPage(
    host: SettingsHost,
    linkCount: Int,
    intervalMin: Int,
    muted: Boolean,
    wallMode: String,
    blurPct: Int,
    saverType: String,
    saverMin: Int,
    onPage: (SettingsPage) -> Unit,
    onClose: () -> Unit,
) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { first.requestFocus() }
    }
    val pkgs = host.apps.map { it.pkg }.toSet()
    val hiddenN = host.hiddenSet.count { it in pkgs }
    val lockedN = host.lockedSet.count { it in pkgs }
    PageList("Launcher Settings") {
        item {
            SettingsButton(
                "Live stream links", { onPage(SettingsPage.Links) }, Modifier.focusRequester(first),
                subtitle = "$linkCount link${if (linkCount == 1) "" else "s"}, next stream after $intervalMin min, " +
                    if (muted) "muted" else "sound on",
            )
        }
        item {
            SettingsButton(
                "Hide / Lock apps", { onPage(SettingsPage.Apps) },
                subtitle = "$hiddenN hidden, $lockedN locked" + if (host.pin.isEmpty()) ", no lock code set" else "",
            )
        }
        item {
            val src = when (wallMode) { "custom" -> "Custom image"; "none" -> "No wallpaper"; else -> "Weather (auto)" }
            SettingsButton("Wallpaper", { onPage(SettingsPage.Wallpaper) }, subtitle = "$src, blur $blurPct%")
        }
        item {
            val s = when (saverType) {
                "off" -> "Off"
                "colors" -> "Colors"
                "backdrop" -> "Backdrop"
                else -> "Digital clock + calendar"
            }
            SettingsButton(
                "Screensaver", { onPage(SettingsPage.Saver) },
                subtitle = if (saverType == "off") "Off" else "$s after $saverMin min",
            )
        }
        item { SettingsButton("Reset app order (A-Z)", onClick = { host.resetOrder() }) }
        item { SettingsButton("Done", onClose) }
    }
}

// ---- Live stream links -----------------------------------------------------------------------

@Composable
private fun LinksPage(
    links: List<String>,
    onLinks: (List<String>) -> Unit,
    intervalMin: Int,
    onIntervalMin: (Int) -> Unit,
    muted: Boolean,
    onMuted: (Boolean) -> Unit,
    onBack: () -> Unit,
) {
    // Unlimited links: the first is always there (prefilled), "Add link" appears once the
    // last one is filled in.
    val items = remember { mutableStateListOf<String>().also { it.addAll(links.ifEmpty { listOf("") }) } }
    var focusNew by remember { mutableIntStateOf(-1) }
    var minutesText by remember { mutableStateOf(intervalMin.toString()) }
    var mutedState by remember { mutableStateOf(muted) }

    PageList("Live stream links") {
        item {
            Text(
                "Add as many links as you like. With one link only that stream plays. With more, each plays " +
                    "for the time set below, then the next one loads (playlist).",
                color = TextDim, fontSize = 19.us(),
            )
        }
        itemsIndexed(items) { i, value ->
            val requester = remember { FocusRequester() }
            LaunchedEffect(Unit) {
                if (focusNew == i) {
                    focusNew = -1
                    runCatching { requester.requestFocus() }
                }
            }
            OutlinedTextField(
                value = value,
                onValueChange = { items[i] = it; onLinks(items.toList()) },
                label = { Text("Link ${i + 1}") },
                singleLine = true,
                textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth().focusRequester(requester),
            )
        }
        if (items.last().isNotBlank()) {
            item {
                SettingsButton("+  Add link", onClick = {
                    items.add("")
                    focusNew = items.lastIndex
                })
            }
        }
        // Time-to-next and muted-play side by side, below the links.
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.u()),
                verticalAlignment = Alignment.Top,
            ) {
                OutlinedTextField(
                    value = minutesText,
                    onValueChange = { v ->
                        val d = v.filter { it.isDigit() }.take(3)
                        minutesText = d
                        d.toIntOrNull()?.takeIf { it >= 1 }?.let(onIntervalMin)
                    },
                    label = { Text("Play next stream after (min)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                    colors = fieldColors(),
                    modifier = Modifier.weight(1f),
                )
                ToggleRow(
                    "Muted play", mutedState,
                    onToggle = { mutedState = !mutedState; onMuted(mutedState) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
        item { SettingsButton("Back", onBack) }
    }
}

// ---- Hide / Lock apps ------------------------------------------------------------------------

/**
 * One page for hiding and locking. Tick apps (one by one or Select all), then press Hide or Lock below
 * the list. Locked apps show a lock icon beside them, hidden apps show a darkened icon. Pressing the
 * button again on apps that are already hidden / locked undoes it (Unhide / Unlock; Unlock asks the PIN).
 */
@Composable
private fun AppsPage(host: SettingsHost, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val apps = host.apps
    val hidden = host.hiddenSet
    val locked = host.lockedSet
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var changePin by remember { mutableStateOf(false) }
    var lockAfterPin by remember { mutableStateOf<Set<String>?>(null) }
    var askUnlock by remember { mutableStateOf<Set<String>?>(null) }
    val allSelected = apps.isNotEmpty() && apps.all { it.pkg in selected }
    val allHidden = selected.isNotEmpty() && selected.all { it in hidden }
    val allLocked = selected.isNotEmpty() && selected.all { it in locked }
    val count = if (selected.isEmpty()) "" else " (${selected.size})"

    Column(
        Modifier.fillMaxSize().padding(horizontal = 60.u(), vertical = 28.u()),
        verticalArrangement = Arrangement.spacedBy(10.u()),
    ) {
        Text("Hide / Lock apps", color = TextPrimary, fontSize = 34.us(), fontWeight = FontWeight.Medium)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.u())) {
            item {
                Text(
                    "Tick apps, then press Hide or Lock. Locked apps show a lock icon, hidden apps go dark.",
                    color = TextDim, fontSize = 19.us(),
                )
            }
            item {
                // The code itself is never shown. Changing it needs the current code first.
                SettingsButton(
                    if (host.pin.isEmpty()) "Set lock code" else "Change lock code",
                    onClick = { changePin = true },
                    subtitle = if (host.pin.isEmpty()) "Not set" else "Hidden. Asks for the current code first",
                )
            }
            item {
                CheckRow(
                    "Select all", allSelected,
                    onToggle = { selected = if (allSelected) emptySet() else apps.map { it.pkg }.toSet() },
                )
            }
            items(apps, key = { it.pkg }) { a ->
                AppPickRow(
                    a.name, a.pkg, a.pkg in selected, a.pkg in hidden, a.pkg in locked,
                    onToggle = { selected = if (a.pkg in selected) selected - a.pkg else selected + a.pkg },
                )
            }
        }
        // [Hide] [Lock] side by side below the list.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.u())) {
            SettingsButton(
                (if (allHidden) "Unhide" else "Hide") + count,
                onClick = {
                    if (selected.isEmpty()) {
                        Toast.makeText(ctx, "Tick at least one app first", Toast.LENGTH_SHORT).show()
                    } else {
                        if (allHidden) host.unhide(selected) else host.hide(selected)
                        selected = emptySet()
                    }
                },
                modifier = Modifier.weight(1f),
            )
            SettingsButton(
                (if (allLocked) "Unlock" else "Lock") + count,
                onClick = {
                    if (selected.isEmpty()) {
                        Toast.makeText(ctx, "Tick at least one app first", Toast.LENGTH_SHORT).show()
                    } else if (allLocked) {
                        askUnlock = selected                 // unlocking needs the PIN
                    } else if (host.pin.isEmpty()) {
                        lockAfterPin = selected              // set a lock code first
                    } else {
                        host.lock(selected)
                        selected = emptySet()
                    }
                },
                modifier = Modifier.weight(1f),
            )
            SettingsButton("Back", onBack, modifier = Modifier.weight(1f))
        }
    }

    askUnlock?.let { pending ->
        PinPromptDialog(
            title = "Enter PIN to unlock", expected = host.pin,
            onOk = { host.unlock(pending); askUnlock = null; selected = emptySet() },
            onDismiss = { askUnlock = null },
        )
    }
    lockAfterPin?.let { pending ->
        ChangePinDialog(
            currentPin = "",
            onSave = {
                host.setPin(it)
                host.lock(pending)
                Toast.makeText(ctx, "Lock code set. Locked ${pending.size} app(s)", Toast.LENGTH_SHORT).show()
                selected = emptySet()
                lockAfterPin = null
            },
            onDismiss = { lockAfterPin = null },
        )
    }
    if (changePin) {
        ChangePinDialog(
            currentPin = host.pin,
            onSave = {
                host.setPin(it)
                changePin = false
                Toast.makeText(ctx, "Lock code saved", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { changePin = false },
        )
    }
}

/** App row with a tick box. Hidden apps show a darkened icon; locked apps show a lock icon beside them. */
@Composable
private fun AppPickRow(
    name: String, pkg: String, checked: Boolean, hidden: Boolean, locked: Boolean, onToggle: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        Modifier
            .fillMaxWidth()
            .height(62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onToggle)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = checked, onCheckedChange = null,
            colors = CheckboxDefaults.colors(
                checkedColor = TextPrimary, checkmarkColor = BgColor, uncheckedColor = TextDim,
            ),
        )
        Spacer(Modifier.width(10.u()))
        Box(Modifier.alpha(if (hidden) 0.22f else 1f)) { AppIcon(pkg, 40.u()) }
        Spacer(Modifier.width(14.u()))
        Text(
            name, color = if (focused) TextPrimary else if (hidden) TextDim else DateColor,
            fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
            modifier = Modifier.weight(1f),
        )
        if (locked) {
            Icon(
                Icons.Outlined.Lock, contentDescription = "Locked",
                tint = if (focused) TextPrimary else DateColor, modifier = Modifier.size(28.u()),
            )
        }
    }
}

// ---- Wallpaper -------------------------------------------------------------------------------

@Composable
private fun WallpaperPage(
    prefs: Prefs,
    wallMode: String,
    onWallMode: (String) -> Unit,
    blurPct: Int,
    onBlurPct: (Int) -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val first = remember { FocusRequester() }
    var links by remember { mutableStateOf(prefs.wallLinks) }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { first.requestFocus() }
    }

    PageList("Wallpaper") {
        item {
            Text(
                "Choose the home screen wallpaper. Weather (auto) switches picture with the current weather.",
                color = TextDim, fontSize = 19.us(),
            )
        }
        item {
            RadioRow(
                "Weather (auto)", wallMode == "weather", { onWallMode("weather") },
                Modifier.focusRequester(first),
            )
        }
        item { RadioRow("Custom image", wallMode == "custom", { onWallMode("custom") }) }
        item { RadioRow("None (plain background)", wallMode == "none", { onWallMode("none") }) }
        item {
            StepperRow(
                "Blur", "$blurPct%",
                onLeft = { onBlurPct((blurPct - 10).coerceAtLeast(0)) },
                onRight = { onBlurPct((blurPct + 10).coerceAtMost(100)) },
            )
        }
        item {
            Spacer(Modifier.height(6.u()))
            Text("Custom image link", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
        }
        item {
            OutlinedTextField(
                value = links["custom"] ?: "",
                onValueChange = { links = links + ("custom" to it); status = null },
                label = { Text("Image link (jpg / png)") },
                singleLine = true,
                textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            Spacer(Modifier.height(6.u()))
            Text("Weather photo links (optional)", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.u()))
            Text(
                "Paste a photo link for any weather. Empty ones use the built-in scene.",
                color = TextDim, fontSize = 19.us(),
            )
        }
        items(WallCond.values().toList()) { c ->
            OutlinedTextField(
                value = links[c.name] ?: "",
                onValueChange = { links = links + (c.name to it); status = null },
                label = { Text(c.label) },
                singleLine = true,
                textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            SettingsButton(if (busy) "Downloading..." else "Download images", onClick = {
                if (busy) return@SettingsButton
                scope.launch {
                    busy = true
                    prefs.wallLinks = links.filterValues { it.isNotBlank() }
                    var tried = 0
                    var ok = 0
                    for ((k, u) in links) {
                        if (u.isBlank()) continue
                        tried++
                        if (WallpaperStore.download(ctx.applicationContext, u, k)) ok++
                    }
                    WallpaperStore.bump()
                    status = if (tried == 0) "Enter at least one image link first." else "Downloaded $ok of $tried images."
                    busy = false
                }
            })
        }
        status?.let { s -> item { Text(s, color = TextDim, fontSize = 20.us()) } }
        item {
            SettingsButton("Remove downloaded images", onClick = {
                WallpaperStore.clear(ctx.applicationContext)
                status = "Downloaded images removed."
            })
        }
        item { SettingsButton("Back", onBack) }
    }
}

// ---- Screensaver -----------------------------------------------------------------------------

@Composable
private fun SaverPage(
    type: String,
    onType: (String) -> Unit,
    minutes: Int,
    onMinutes: (Int) -> Unit,
    onPreview: () -> Unit,
    onBack: () -> Unit,
) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { first.requestFocus() }
    }
    PageList("Screensaver") {
        item {
            Text(
                "Starts on the home screen after the remote has not been touched for the time below. " +
                    "Press any button to close it.",
                color = TextDim, fontSize = 19.us(),
            )
        }
        item { RadioRow("Digital clock + calendar", type == "clock", { onType("clock") }, Modifier.focusRequester(first)) }
        item { RadioRow("Colors", type == "colors", { onType("colors") }) }
        item { RadioRow("Backdrop (scenes)", type == "backdrop", { onType("backdrop") }) }
        item { RadioRow("Off", type == "off", { onType("off") }) }
        item {
            StepperRow(
                "Start after", "$minutes min",
                onLeft = { SAVER_MINUTES.lastOrNull { it < minutes }?.let(onMinutes) },
                onRight = { SAVER_MINUTES.firstOrNull { it > minutes }?.let(onMinutes) },
            )
        }
        item { SettingsButton("Preview now", onPreview) }
        item { SettingsButton("Back", onBack) }
    }
}

// ---- Shared pieces ---------------------------------------------------------------------------

@Composable
private fun PageList(title: String, content: LazyListScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 60.u(), vertical = 28.u()),
        verticalArrangement = Arrangement.spacedBy(10.u()),
    ) {
        item { Text(title, color = TextPrimary, fontSize = 34.us(), fontWeight = FontWeight.Medium) }
        content()
    }
}

/** Focusable tick box row, same height as a text field so it sits level beside one. */
@Composable
private fun ToggleRow(text: String, checked: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        modifier
            .height(56.dp)
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onToggle)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = checked, onCheckedChange = null,
            colors = CheckboxDefaults.colors(
                checkedColor = TextPrimary, checkmarkColor = BgColor, uncheckedColor = TextDim,
            ),
        )
        Spacer(Modifier.width(12.u()))
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 22.us(), maxLines = 1,
            style = TextStyle(lineHeight = 28.us(), lineHeightStyle = MidLine),
        )
    }
}

/** Tick row for lists of apps (and "Select all"). */
@Composable
private fun CheckRow(text: String, checked: Boolean, onToggle: () -> Unit, pkg: String? = null) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        Modifier
            .fillMaxWidth()
            .height(62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onToggle)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = checked, onCheckedChange = null,
            colors = CheckboxDefaults.colors(
                checkedColor = TextPrimary, checkmarkColor = BgColor, uncheckedColor = TextDim,
            ),
        )
        Spacer(Modifier.width(10.u()))
        if (pkg != null) {
            AppIcon(pkg, 40.u())
            Spacer(Modifier.width(14.u()))
        }
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
        )
    }
}

@Composable
private fun RadioRow(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        modifier
            .fillMaxWidth()
            .height(62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(
            selected = selected, onClick = null,
            colors = RadioButtonDefaults.colors(selectedColor = TextPrimary, unselectedColor = TextDim),
        )
        Spacer(Modifier.width(12.u()))
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
        )
    }
}

/** A value you change with Left / Right on the remote (or OK to step up). */
@Composable
private fun StepperRow(label: String, value: String, onLeft: () -> Unit, onRight: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        Modifier
            .fillMaxWidth()
            .height(62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .onPreviewKeyEvent { ev ->
                when {
                    ev.type != KeyEventType.KeyDown -> false
                    ev.key == Key.DirectionLeft -> { onLeft(); true }
                    ev.key == Key.DirectionRight -> { onRight(); true }
                    else -> false
                }
            }
            .clickable(onClick = onRight)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label, color = if (focused) TextPrimary else TextDim, fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
            modifier = Modifier.weight(1f),
        )
        Icon(Icons.Outlined.ChevronLeft, null, tint = TextDim, modifier = Modifier.size(30.u()))
        Text(
            value, color = TextPrimary, fontSize = 24.us(), fontWeight = FontWeight.Medium, maxLines = 1,
            modifier = Modifier.width(110.u()),
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
        )
        Icon(Icons.Outlined.ChevronRight, null, tint = TextDim, modifier = Modifier.size(30.u()))
    }
}

@Composable
private fun SettingsButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    pkg: String? = null,
    subtitle: String? = null,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        modifier
            .fillMaxWidth()
            .height(if (subtitle != null) 78.u() else 62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (pkg != null) {
            AppIcon(pkg, 40.u())
            Spacer(Modifier.width(14.u()))
        }
        Column(verticalArrangement = Arrangement.Center) {
            Text(
                text, color = if (focused) TextPrimary else DateColor, fontSize = 24.us(), maxLines = 1,
                style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
            )
            if (subtitle != null) {
                Text(
                    subtitle, color = TextDim, fontSize = 18.us(), maxLines = 1,
                    style = TextStyle(lineHeight = 24.us(), lineHeightStyle = MidLine),
                )
            }
        }
    }
}
