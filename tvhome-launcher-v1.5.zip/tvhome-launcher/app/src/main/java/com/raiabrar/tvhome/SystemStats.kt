package com.raiabrar.tvhome

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.StatFs
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

private data class Stats(val cpu: Int?, val ram: Int, val storage: Int)

/**
 * System-wide CPU load. Android 8+ blocks apps from reading /proc/stat on most
 * devices, so when it is unreadable we fall back to the average CPU clock speed
 * relative to its maximum (a good proxy for load); if neither is readable the
 * gauge shows "--".
 */
private class CpuSampler {
    private var lastTotal = 0L
    private var lastIdle = 0L

    fun sample(): Int? {
        readProcStat()?.let { (total, idle) ->
            val pt = lastTotal
            val pi = lastIdle
            lastTotal = total
            lastIdle = idle
            if (pt == 0L) return null
            val dt = total - pt
            val di = idle - pi
            return if (dt > 0) (((dt - di) * 100) / dt).toInt().coerceIn(0, 100) else null
        }
        return freqLoad()
    }

    private fun readProcStat(): Pair<Long, Long>? = runCatching {
        val line = File("/proc/stat").bufferedReader().use { it.readLine() } ?: return null
        val p = line.trim().split(Regex("\\s+")).drop(1).map { it.toLong() }
        if (p.size < 5) return null
        Pair(p.take(8).sum(), p[3] + p[4])
    }.getOrNull()

    private fun freqLoad(): Int? = runCatching {
        val cpus = File("/sys/devices/system/cpu").listFiles { f -> f.name.matches(Regex("cpu\\d+")) }
            ?: return null
        val ratios = cpus.mapNotNull { c ->
            val cur = File(c, "cpufreq/scaling_cur_freq").readText().trim().toDouble()
            val max = File(c, "cpufreq/cpuinfo_max_freq").readText().trim().toDouble()
            if (max > 0) cur / max else null
        }
        if (ratios.isEmpty()) null else (ratios.average() * 100).toInt().coerceIn(0, 100)
    }.getOrNull()
}

private fun ramPercent(ctx: Context): Int {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    if (mi.totalMem <= 0) return 0
    return (((mi.totalMem - mi.availMem) * 100) / mi.totalMem).toInt().coerceIn(0, 100)
}

private fun storagePercent(): Int = runCatching {
    val s = StatFs(Environment.getDataDirectory().path)
    val total = s.blockCountLong * s.blockSizeLong
    val free = s.availableBlocksLong * s.blockSizeLong
    if (total <= 0) 0 else (((total - free) * 100) / total).toInt().coerceIn(0, 100)
}.getOrDefault(0)

/** Always-visible CPU / RAM / Storage rings, refreshed every 2 seconds. */
@Composable
internal fun StatsBar(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var stats by remember { mutableStateOf(Stats(null, 0, 0)) }
    LaunchedEffect(Unit) {
        val sampler = CpuSampler()
        while (true) {
            val r = withContext(Dispatchers.IO) { Triple(sampler.sample(), ramPercent(ctx), storagePercent()) }
            stats = Stats(r.first ?: stats.cpu, r.second, r.third)
            delay(2000)
        }
    }
    // Three equal-width cells: each ring is centered over its own name.
    Row(
        modifier.fillMaxWidth().padding(top = 4.u(), bottom = 0.u()),
        verticalAlignment = Alignment.Top,
    ) {
        Gauge("CPU", stats.cpu, Color(0xFFF3E3B0), Modifier.weight(1f))
        Gauge("RAM", stats.ram, Color(0xFFB8D4F5), Modifier.weight(1f))
        Gauge("Storage", stats.storage, Color(0xFFB5E0B0), Modifier.weight(1f))
    }
}

@Composable
private fun Gauge(label: String, percent: Int?, color: Color, modifier: Modifier = Modifier) {
    val strokePx = with(LocalDensity.current) { 4.u().toPx() }
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(54.u()), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val inset = strokePx / 2f
                val arcSize = Size(size.width - strokePx, size.height - strokePx)
                drawArc(
                    color = color.copy(alpha = 0.18f), startAngle = 0f, sweepAngle = 360f,
                    useCenter = false, topLeft = Offset(inset, inset), size = arcSize,
                    style = Stroke(width = strokePx),
                )
                if (percent != null) {
                    drawArc(
                        color = color, startAngle = -90f, sweepAngle = 360f * percent / 100f,
                        useCenter = false, topLeft = Offset(inset, inset), size = arcSize,
                        style = Stroke(width = strokePx, cap = StrokeCap.Round),
                    )
                }
            }
            // Percentage only, sized to sit centered inside the ring.
            Text(
                if (percent == null) "--" else "$percent%", color = TextPrimary,
                fontSize = 14.us(), fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false,
                style = TextStyle(lineHeight = 17.us(), lineHeightStyle = MidLine),
            )
        }
        Spacer(Modifier.height(4.u()))
        Text(
            label, color = TextDim, fontSize = 14.us(), maxLines = 1,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
            style = TextStyle(lineHeight = 17.us(), lineHeightStyle = MidLine),
        )
    }
}
