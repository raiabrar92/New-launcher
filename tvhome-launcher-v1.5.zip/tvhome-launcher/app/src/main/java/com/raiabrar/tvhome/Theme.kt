package com.raiabrar.tvhome

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Colors sampled from the reference screenshot.
internal val BgColor = Color(0xFF0F1115)
internal val FocusFill = Color(0xFF2A2D34)
internal val FocusBorder = Color(0xFF5F6368)
internal val LineColor = Color(0xFF3C4043)
internal val TextPrimary = Color(0xFFF2F2F2)
internal val TextDim = Color(0xFF9AA0A6)
internal val DateColor = Color(0xFFCFD3D8)
internal val ThumbColor = Color(0xFF1C2B3A)

/**
 * Every size is in "reference pixels" measured from a 990 x 619 launcher panel.
 * The scale maps them to the real screen, so proportions stay identical on any TV.
 */
internal const val REF_W = 990f
internal const val REF_H = 619f
internal val LocalScale = compositionLocalOf { 1f }

@Composable
internal fun Number.u(): Dp = (this.toFloat() * LocalScale.current).dp

@Composable
internal fun Number.us(): TextUnit = (this.toFloat() * LocalScale.current).sp

internal val CenterLine = LineHeightStyle(LineHeightStyle.Alignment.Center, LineHeightStyle.Trim.None)

// Trims the extra space above/below the glyphs so a label is truly centered
// next to its icon (fixes names sitting lower than the icon).
internal val MidLine = LineHeightStyle(LineHeightStyle.Alignment.Center, LineHeightStyle.Trim.Both)

// Wi-Fi badge colours.
internal val WifiGreen = Color(0xFF4CAF50)
internal val WifiRed = Color(0xFFEF5350)
