package com.raiabrar.tvhome

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AcUnit
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.NightsStay
import androidx.compose.material.icons.outlined.Thunderstorm
import androidx.compose.material.icons.outlined.Umbrella
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// ---- Edit these for your location (used for the weather widget) -------------
internal const val LATITUDE = 24.8607    // Karachi
internal const val LONGITUDE = 67.0011
// -----------------------------------------------------------------------------

internal data class Weather(val tempC: Int, val code: Int, val isDay: Boolean)

/** Weather looks the launcher wallpaper can match. */
internal enum class WallCond(val label: String) {
    SUNNY("Sunny"), NIGHT("Clear night"), CLOUDY("Cloudy"), RAIN("Rain"), SNOW("Snow"), STORM("Storm"),
}

internal fun wallCond(w: Weather?): WallCond = when {
    w == null -> WallCond.CLOUDY
    w.code in 95..99 -> WallCond.STORM
    w.code in 71..77 || w.code == 85 || w.code == 86 -> WallCond.SNOW
    w.code in 51..67 || w.code in 80..82 -> WallCond.RAIN
    w.code <= 1 -> if (w.isDay) WallCond.SUNNY else WallCond.NIGHT
    else -> WallCond.CLOUDY
}

internal fun weatherIcon(w: Weather?): ImageVector = when (wallCond(w)) {
    WallCond.SUNNY -> Icons.Outlined.WbSunny
    WallCond.NIGHT -> Icons.Outlined.NightsStay
    WallCond.RAIN -> Icons.Outlined.Umbrella
    WallCond.SNOW -> Icons.Outlined.AcUnit
    WallCond.STORM -> Icons.Outlined.Thunderstorm
    WallCond.CLOUDY -> Icons.Outlined.Cloud
}

private suspend fun fetchWeather(): Weather? = withContext(Dispatchers.IO) {
    runCatching {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$LATITUDE&longitude=$LONGITUDE" +
                "&current=temperature_2m,weather_code,is_day"
        )
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val cur = JSONObject(body).getJSONObject("current")
            Weather(
                Math.round(cur.getDouble("temperature_2m")).toInt(),
                cur.getInt("weather_code"),
                cur.optInt("is_day", 1) == 1,
            )
        } finally {
            c.disconnect()
        }
    }.getOrNull()
}

/**
 * Current weather, refreshed whenever [refreshKey] changes (TV on / launcher resumes), then every
 * 15 minutes. If the network is not up yet right after power-on, retries every 10 seconds.
 */
@Composable
internal fun rememberWeather(refreshKey: Int): Weather? {
    var weather by remember { mutableStateOf<Weather?>(null) }
    LaunchedEffect(refreshKey) {
        while (true) {
            val w = fetchWeather()
            if (w != null) {
                weather = w
                delay(15 * 60 * 1000L)
            } else {
                delay(10_000L)
            }
        }
    }
    return weather
}
