# Changelog

## 1.3
- Launcher Settings: unlimited stream links (first prefilled, "+ Add link" after filling the last one); "Play next stream after (min)" and "Muted play" side by side below the links; new App lock code setting.
- App menu: Rename, Change Icon (online), Lock / Unlock (PIN box in the app row, auto-verifies), Move, Hide, Info / Uninstall, Launcher Settings.
- Old link0..link4 settings are migrated automatically.

