# TV Home launcher

Google TV / Android TV home screen: full app list on the left, CPU / RAM / Storage
rings below it, Wi-Fi badge, big clock + live weather + date, and a muted LIVE tile on the right, over a
blurred wallpaper that follows the weather.

## Preview
Open `preview/preview.html` in any browser for an HTML replica of every screen (home, quick menu, app menu,
all settings pages, screensaver), same reference-pixel sizes as the Kotlin code. Screenshots of the same pages are in `docs/screenshots-v1.10/` (older ones in `docs/screenshots-v1.3/`). Android Studio users can also open `Previews.kt` for live Compose previews.

## Remote control
- **Up / Down** scroll the app list. **OK** opens the app.
- **Left** moves the highlighter to the quick menu, which appears beside the app list (the app list moves to the opposite side, its icons stay visible). **Right** moves the highlighter back to the apps; **Back** closes the quick menu. The highlighted quick item shows its name on the left of its icon.
  - **Optimize**: ends background processes of the other apps in the list to free RAM. The live stream, weather and the launcher run inside this launcher and are never touched. Android only lets an app end *background* processes, so an app that is actively playing is not force-stopped.
  - **WiFi** (shows the connected network name), **Bluetooth**, **Input Source** (lists the TV's HDMI / external inputs), **All Apps List** (system app list), **Settings** (system settings). Launcher Settings is in the long-press app menu and on the remote's Settings key.
- **Long-press OK** on an app opens a menu:
  - **Rename**: give the app your own name (empty / "Original name" restores it).
  - **Change Icon**: pick an icon found online for that app (Play Store listing icon, website favicons) or paste an image link. "Default icon" restores the original.
  - **Lock / Unlock**: locked apps show a lock icon and ask for the PIN before opening. When you select one and press OK, a PIN box appears in place of the app name and opens the app by itself as soon as the right code is typed. The code is set in Launcher Settings > Hide / Lock apps. Unlock also asks for the PIN.
  - **Move**: press Up / Down (hold to keep going), OK (or Back) drops it. Order is saved.
  - **Hide**: bring it back from Launcher Settings > Hide / Lock apps.
  - **Info / Uninstall**: opens the system app details page (Uninstall / Disable are there).
  - **Launcher Settings**.

## When the TV turns on / launcher resumes
Live stream restarts muted, the first app is highlighted, weather is refreshed
(retries every 10 s until the network is up).

## Launcher Settings
A menu of pages: **Live stream links**, **Hide / Lock apps**, **Display Settings**, **Weather Settings**, **Make this the default launcher**, **Remote buttons** and **Backup & sync** (which also has *Reset all settings to default*).
- **Hide / Lock apps**: one list of all apps. Tick apps one by one or **Select all**, then press **Hide** or **Lock** (side by side below the list). Locked apps show a lock icon beside them; hidden apps show a dark icon. Pressing the button again on apps already hidden / locked shows **Unhide** / **Unlock** (Unlock asks the PIN). **Change lock code** is on the same page; the code is never shown and changing it needs the current PIN first.
- **Display Settings**: *Wallpaper*: pick one of the bundled wallpapers, *None*, or your own image link (**Download my image**); **Blur** (Left / Right, default 40 %). While the weather background is ticked (Weather Settings) the wallpaper follows the weather and these choices are hidden. *Screensaver*: *Digital clock + weather + calendar*, *Colors*, *Backdrop*, *Off*; **Start after** 1 to 30 min; **OLED TV** tick (off = the screensaver stays still, on = it moves a little every minute); **Preview screensaver**.
- **Weather Settings**: search a city / town to change the weather area; tick **Weather condition background** to make the wallpaper follow the weather (optional photo links per weather appear then).
- **Make this the default launcher** / **Change default launcher**: opens the system chooser. Some TVs hide this; then press Home on the remote and choose TV Home with *Always*.

## Live stream (Launcher Settings > Live stream links)
Unlimited links: the first is prefilled; once a link is filled in, **+ Add link** appears for the next one.
1 link = always plays that one. 2+ links = each plays for **Play next stream after (min)**
(default 1), then the next loads, looping. **Muted play** (default on) sits beside it.
The tile is not selectable and always fits the stream inside 16:9 (no cropping).
Ads and promotions are blocked (see CHANGELOG 1.4). This is best effort and untested against every YouTube change; ads stitched into the video stream itself cannot be removed.
Accepted links: YouTube (watch / live / youtu.be / embed / channel), direct
.m3u8 / .mp4 streams, or any web page.

## Wi-Fi badge
Top corner above the clock. Green icon + network name when connected; red icon + "Disconnected" for 10 s, then just the red icon. Android only gives the network name to apps with the location permission, so the launcher asks for it once on first start. If it is refused the badge shows "Wi-Fi".

## System status
RAM and Storage are exact. CPU: Android 8+ blocks apps from reading /proc/stat on
most devices, so the app falls back to average CPU clock vs max clock; if neither
is readable the CPU ring shows "--".

## Layout
Left: app list (or quick menu) + compact status rings. Right (540 ref px wide): Wi-Fi badge, clock, weather/date right under the clock, 16:9 muted live tile at the bottom. The stream is always
scaled to fit inside the tile (letterboxed, never cropped).

## Build
Push to GitHub; the **Build TV Home launcher** workflow produces the APK artifact.
Or locally: `gradle :app:assembleRelease`.

## Install
```
adb connect <tv-ip>:5555
adb install -r app-release.apk
```

## Customize
- Weather location: Launcher Settings > Weather Settings (default area in `Place.DEFAULT`, `Weather.kt`).
- Bundled wallpapers: drop `.jpg` files into `app/src/main/assets/wallpapers/`.


## Google Drive backup (one-time setup)
Settings > **Backup & sync (Google Drive)** saves every launcher setting and data to a
private, hidden folder in your own Google Drive and restores it on any TV.
It needs a free Google OAuth client, because Google requires every app that talks to Drive to have one:

1. Open https://console.cloud.google.com and create a project (any name).
2. **APIs & Services > Library**: search **Google Drive API** and click **Enable**.
3. **APIs & Services > OAuth consent screen**: choose **External**, fill in an app name and
   your email, save. Then click **Publish app** (status must be **In production**; the
   Drive app-data permission needs no Google review, and in "Testing" status the sign-in
   expires after 7 days).
4. **APIs & Services > Credentials > Create credentials > OAuth client ID**, application type
   **TVs and Limited Input devices**. Copy the **Client ID** and **Client secret**.
5. Paste both into `app/src/main/java/com/raiabrar/tvhome/DriveConfig.kt`, push to GitHub, install the new APK.
6. On the TV: Settings > Backup & sync > **Sign in**. Open google.com/device on your phone,
   enter the code, approve. Then tap **Back up now** once, and turn **Auto sync** on.

Restoring on a new TV: sign in, then **Restore from Google Drive**.
Auto sync only uploads, and only after you have done Back up now (or Restore) once on that TV,
so a fresh TV can never overwrite your saved copy by accident.

### Using the Google account already on the TV (optional)
Open Backup & sync: if a Google account is signed in on the TV (and Google Play Services is
present) the launcher connects to it by itself; Google may show a permission screen once.
If there is no account, use the phone-code sign-in above instead.

Google only allows this for an app it recognises by **package name + signing key**, and GitHub's
default debug key changes on every build, so set up a fixed key once:

1. On your computer: `keytool -genkeypair -v -keystore release.jks -alias tvhome -keyalg RSA -keysize 2048 -validity 10000`
2. `base64 -w0 release.jks` (macOS: `base64 -i release.jks`) and copy the output.
3. GitHub repo > Settings > Secrets and variables > Actions > add secrets:
   `KEYSTORE_BASE64` (that output), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (`tvhome`), `KEY_PASSWORD`.
4. Get the SHA-1: `keytool -list -v -keystore release.jks -alias tvhome` (the line "SHA1").
5. Google Cloud Console > Credentials > Create credentials > OAuth client ID > **Android**,
   package name `com.raiabrar.tvhome`, paste the SHA-1.
6. Re-run the build. Uninstall the old APK once on the TV (the signing key changed), then install the new one.
Keep `release.jks` safe: every future build must use the same file.

## Remote buttons
Launcher Settings > **Remote buttons**: press a remote button, then choose its action
(Launcher Settings, Quick menu, Input Source, system settings, optimize, screensaver, first app, or open any app).
The remote's Settings key opens Launcher Settings and Menu opens the Quick menu by default.
Keys the TV firmware handles before apps never reach the launcher; those can't be mapped.

## Credits
Glass highlighter and bundled wallpapers: [cleanyourtv](https://github.com/gathin23/cleanyourtv) (MIT, CC0 / Unsplash). Details in `THIRD_PARTY.md`.
