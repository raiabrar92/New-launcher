# TV Home launcher

Google TV / Android TV home screen: full app list on the left, CPU / RAM / Storage
rings below it, big clock + live weather + date, and a muted LIVE tile on the right.

## Screenshots
Rendered from `preview/preview.html` (an HTML replica of the layout, same reference-pixel sizes as the Kotlin code; open it in any browser).

| Home | App menu | Locked app: PIN box |
|---|---|---|
| ![Home](docs/screenshots/home.png) | ![Menu](docs/screenshots/app-menu.png) | ![PIN](docs/screenshots/pin-entry.png) |

| Rename | Change icon | Move mode |
|---|---|---|
| ![Rename](docs/screenshots/rename.png) | ![Icon](docs/screenshots/change-icon.png) | ![Move](docs/screenshots/move-mode.png) |

| Settings (first run) | Settings (full) | Menu on a locked app |
|---|---|---|
| ![S1](docs/screenshots/settings-first-run.png) | ![S2](docs/screenshots/settings-full.png) | ![Unlock](docs/screenshots/app-menu-locked.png) |

Android Studio users can also open `Previews.kt` for live Compose previews of the settings screens and PIN box.

## Remote control
- **Up / Down** scroll the app list. **OK** opens the app.
- **Long-press OK** on an app opens a menu:
  - **Rename**: give the app your own name (empty / "Original name" restores it).
  - **Change Icon**: pick an icon found online for that app (Play Store listing icon, website favicons) or paste an image link. "Default icon" restores the original.
  - **Lock / Unlock**: locked apps show a lock icon and ask for the PIN before opening. When you select one and press OK, a PIN box appears in place of the app name and opens the app by itself as soon as the right code is typed. The code is set in Launcher Settings. Unlock also asks for the PIN.
  - **Move**: press Up / Down (hold to keep going), OK (or Back) drops it. Order is saved.
  - **Hide**: bring it back from Launcher Settings > Hidden apps.
  - **Info / Uninstall**: opens the system app details page (Uninstall / Disable are there).
  - **Launcher Settings**.

## When the TV turns on / launcher resumes
Live stream restarts muted, the first app is highlighted, weather is refreshed
(retries every 10 s until the network is up).

## Live stream (Launcher Settings)
Unlimited links: the first is prefilled; once a link is filled in, **+ Add link** appears for the next one.
1 link = always plays that one. 2+ links = each plays for **Play next stream after (min)**
(default 1), then the next loads, looping. **Muted play** (default on) sits beside it.
The tile is not selectable and always fits the stream inside 16:9 (no cropping).
Accepted links: YouTube (watch / live / youtu.be / embed / channel), direct
.m3u8 / .mp4 streams, or any web page.

## System status
RAM and Storage are exact. CPU: Android 8+ blocks apps from reading /proc/stat on
most devices, so the app falls back to average CPU clock vs max clock; if neither
is readable the CPU ring shows "--".

## Layout
Left: app list + compact status rings. Right (540 ref px wide): clock, weather/date with
breathing room below the clock, 16:9 muted live tile at the bottom. The stream is always
scaled to fit inside the tile (letterboxed, never cropped).

## Build
Push to GitHub; the **Build TV Home launcher** workflow produces the APK artifact.
Or locally: `gradle :app:assembleRelease`.

## Install
```
adb connect <tv-ip>:5555
adb install -r app-release.apk
```

## Customize
- Weather location: `LATITUDE` / `LONGITUDE` at the top of `MainActivity.kt`.
