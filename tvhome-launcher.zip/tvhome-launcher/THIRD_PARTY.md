# Third-party material

## cleanyourtv (wallpapers and the "glass" highlighter) - MIT

The glass highlighter in `Glass.kt` is a Compose port of the look of `GlassView` from
<https://github.com/gathin23/cleanyourtv>. The wallpapers in `app/src/main/assets/wallpapers/` come from the
themes of the same project:

| Files | Theme folder | Licence |
|---|---|---|
| `ambient-*.jpg` (8 landscape photos) | `themes/ambient-glass` | CC0 1.0 / Unsplash License (credits below) |
| `midnight-*.jpg` (5 AI-generated backdrops) | `themes/midnight-glass` | CC0 1.0 (credits below) |
| `gradient-*.jpg` (3 abstract gradients) | `themes/glass-gallery` | CC0 1.0 (`themes/glass-gallery/CREDITS.md`) |
| `glass-classic.jpg`, `aurora.jpg` | `themes/glass`, `themes/aurora` | MIT, same as the project |

The project's licence text:

    MIT License
    
    Copyright (c) 2026 Gathin
    
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.
    
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.

## Credits: ambient-glass



Landscape wallpaper photographs sourced from Unsplash / Wikimedia Commons under free licences, cropped to 16:9 and resized for 1080p TV display:

- 01-alps-switzerland.jpg: "Swiss Alps" (Troistorrents, Switzerland) by Vladimir Nordmann
  https://unsplash.com/photos/YKCwwjkxjsQ
  https://commons.wikimedia.org/wiki/File:Swiss_Alps_(Unsplash).jpg
  Licence: CC0 1.0 / Unsplash License (free to use)

- 02-atacama-chile.jpg: "Atacama Desert" (San Pedro de Atacama, Chile) by Marcus Dall Col
  https://unsplash.com/photos/TR8rUQkPWLg
  https://commons.wikimedia.org/wiki/File:Atacama_Desert_(Unsplash).jpg
  Licence: CC0 1.0 / Unsplash License (free to use)

- 03-blue-horizons.jpg: "Drone view of coastal lagoon" by Dawid Zawiła
  https://unsplash.com/photos/n2tQUTQPGHQ
  https://commons.wikimedia.org/wiki/File:Drone_view_of_coastal_lagoon_(Unsplash).jpg
  Licence: CC0 1.0 / Unsplash License (free to use)

- 04-emerald-lake.jpg: "Where the mountains meet the sky" (Emerald Lake, Yoho National Park, Canada) by Linford Miles
  https://unsplash.com/photos/xVmhuV2MAeA
  https://commons.wikimedia.org/wiki/File:Where_the_mountains_meet_the_sky_(Unsplash).jpg
  Licence: CC0 1.0 / Unsplash License (free to use)

- 05-occitanie-france.jpg: "Taüll — Catalan Pyrenees" by Jan Phoenix
  https://unsplash.com/photos/SQYeNwwCYZ4
  https://commons.wikimedia.org/wiki/File:Ta%C3%BCll_%E2%80%94_Catalan_Pyrenees_(Unsplash).jpg
  Licence: CC0 1.0 / Unsplash License (free to use)

- 06-alpine-waterscape.jpg: "Passo Falzarego, Italy" (Lake Limedes, Dolomites) by Ales Krivec
  https://unsplash.com/photos/OmelL9tVVno
  https://commons.wikimedia.org/wiki/File:Passo_Falzarego,_Italy_(Unsplash).jpg
  Licence: CC0 1.0 / Unsplash License (free to use)

- 07-mount-baker.jpg: "White Mount Baker slope" (Washington, USA) by David Preston
  https://unsplash.com/photos/6fXbKCLBi58
  https://commons.wikimedia.org/wiki/File:White_Mount_Baker_slope_(Unsplash).jpg
  Licence: CC0 1.0 / Unsplash License (free to use)

- 08-shrine-pass-road.jpg: "Shrine Pass Road, Red Cliff, United States" by Joel Holland
  https://unsplash.com/photos/TRhGEGdw-YY
  https://commons.wikimedia.org/wiki/File:Shrine_Pass_Road,_Red_Cliff,_United_States_(Unsplash).jpg
  Licence: CC0 1.0 / Unsplash License (free to use)

All eight pictures are released under Creative Commons CC0 1.0 Universal (public domain) / Unsplash License, so the repository can redistribute them alongside its MIT licence:
https://creativecommons.org/publicdomain/zero/1.0/
https://unsplash.com/license

## Credits: midnight-glass



These five pictures are AI-generated (Higgsfield, GPT Image 2.5), not drawn or photographed.

- `wallpapers/01-midnight-cinema.jpg`
- `wallpapers/02-neon-arena.jpg`
- `wallpapers/03-night-orbit.jpg`
- `wallpapers/04-screen-galaxy.jpg`
- `wallpapers/05-concert-lights.jpg`

All five were generated from text prompts by [ruchira-edirisinghe](https://github.com/ruchira-edirisinghe) as
home-screen backdrops for their own TV: a home cinema at night, an esports arena, the Earth at night from orbit, a
wall of glowing screens and a concert crowd. The prompts asked for no text, logos, brand marks or existing
characters, and the pictures were only resized to 1920x1080 afterwards. They are released under CC0 1.0, as far as
the generated pictures carry any rights to release: https://creativecommons.org/publicdomain/zero/1.0/

## Credits: glass-gallery

# Wallpaper credits

All three images are original procedural artwork made for this theme by ADOCR with [make_wallpapers.py](make_wallpapers.py). No photographs, external art, fonts or personal wallpapers are included.

- `wallpapers/01-tidal.jpg`: teal light over navy.
- `wallpapers/02-violet.jpg`: violet and blue light.
- `wallpapers/03-amber.jpg`: amber and violet light.

The generated images are dedicated to the public domain under [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/). The generator and configuration follow the repository's MIT licence. The screenshot shows the theme on a real Kenwood K32M15G6; it is not a generated interface mock-up.

## Weather data

Weather and place search come from [Open-Meteo](https://open-meteo.com/) (free, no key; CC BY 4.0 data).
