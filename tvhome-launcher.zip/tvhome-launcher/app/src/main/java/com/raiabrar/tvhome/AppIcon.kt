package com.raiabrar.tvhome

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private val iconCache = HashMap<String, ImageBitmap>()

/** An icon found online, with a short name for where it came from. */
internal class IconCandidate(val source: String, val bitmap: Bitmap)

/** Custom (online) icons saved as PNG in the app's private storage. */
internal object IconStore {
    /** Bumped whenever a custom icon is saved / reset so every AppIcon reloads. */
    var tick by mutableIntStateOf(0)
        private set

    private const val UA =
        "Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

    /** After a restore: forget every cached icon and reload them all from storage. */
    fun bumpAll() {
        iconCache.clear()
        tick++
    }

    fun file(ctx: Context, pkg: String): File {
        val dir = File(ctx.filesDir, "icons").also { it.mkdirs() }
        return File(dir, pkg.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".png")
    }

    fun save(ctx: Context, pkg: String, bmp: Bitmap) {
        val scaled = Bitmap.createScaledBitmap(bmp, 192, 192, true)
        file(ctx, pkg).outputStream().use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
        tick++
    }

    fun reset(ctx: Context, pkg: String) {
        file(ctx, pkg).delete()
        iconCache.remove(pkg)
        tick++
    }

    private fun httpGet(url: String): ByteArray? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        try {
            if (c.responseCode != 200) null else c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }.getOrNull()

    suspend fun download(url: String): Bitmap? = withContext(Dispatchers.IO) {
        val u = url.trim().let { if (it.startsWith("http")) it else "https://$it" }
        httpGet(u)?.let { b -> runCatching { BitmapFactory.decodeByteArray(b, 0, b.size) }.getOrNull() }
    }

    /**
     * Looks for icons relevant to the app: its Play Store listing icon (by package name)
     * and website favicons guessed from the app name / package.
     */
    suspend fun findCandidates(pkg: String, label: String): List<IconCandidate> = withContext(Dispatchers.IO) {
        val out = mutableListOf<IconCandidate>()
        runCatching {
            val html = httpGet("https://play.google.com/store/apps/details?id=$pkg&hl=en&gl=us")
                ?.toString(Charsets.UTF_8)
            if (html != null) {
                val m = Regex("""<meta property="og:image" content="([^"]+)""").find(html)
                    ?: Regex("""(https://play-lh\.googleusercontent\.com/[A-Za-z0-9_\-]+)""").find(html)
                m?.let {
                    val base = it.groupValues[1].substringBefore('=')
                    download("$base=s256-rw")?.let { b -> out += IconCandidate("Play Store", b) }
                }
            }
        }
        val slug = label.lowercase().replace(Regex("[^a-z0-9]"), "")
        val domains = listOfNotNull(slug.takeIf { it.length > 1 }, pkg.split('.').getOrNull(1))
            .filter { it.length > 1 }.distinct()
        for (d in domains) {
            runCatching {
                download("https://www.google.com/s2/favicons?domain=$d.com&sz=128")
                    ?.let { b -> out += IconCandidate("$d.com", b) }
            }
        }
        out
    }
}

/** The app's icon: a saved custom (online) icon if there is one, else its own default icon. */
@Composable
internal fun AppIcon(pkg: String, size: Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val tick = IconStore.tick
    val bmp by produceState<ImageBitmap?>(iconCache[pkg], pkg, tick) {
        val loaded = withContext(Dispatchers.Default) {
            runCatching {
                val f = IconStore.file(ctx, pkg)
                if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
            }.getOrNull() ?: runCatching {
                ctx.packageManager.getApplicationIcon(pkg).toBitmap(160, 160).asImageBitmap()
            }.getOrNull()
        }
        if (loaded != null) {
            iconCache[pkg] = loaded
            value = loaded
        }
    }
    val custom = remember(pkg, tick) { IconStore.file(ctx, pkg).exists() }
    Box(modifier.size(size)) {
        bmp?.let {
            Image(
                it, contentDescription = null,
                modifier = Modifier.fillMaxSize().clip(if (custom) RoundedCornerShape(size * 0.22f) else RectangleShape),
            )
        }
    }
}
