package com.raiabrar.tvhome

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private val iconCache = HashMap<String, ImageBitmap>()

/** An icon found online, with a short name for where it came from. */
internal class IconCandidate(val source: String, val bitmap: Bitmap)

/** Custom (online) icons saved as PNG in the app's private storage. */
internal object IconStore {
    /** Bumped whenever a custom icon is saved / reset so every AppIcon reloads. */
    var tick by mutableIntStateOf(0)
        private set

    private const val UA =
        "Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

    /** After a restore: forget every cached icon and reload them all from storage. */
    fun bumpAll() {
        iconCache.clear()
        tick++
    }

    fun file(ctx: Context, pkg: String): File {
        val dir = File(ctx.filesDir, "icons").also { it.mkdirs() }
        return File(dir, pkg.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".png")
    }

    fun save(ctx: Context, pkg: String, bmp: Bitmap) {
        val scaled = Bitmap.createScaledBitmap(bmp, 192, 192, true)
        file(ctx, pkg).outputStream().use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
        tick++
    }

    fun reset(ctx: Context, pkg: String) {
        file(ctx, pkg).delete()
        iconCache.remove(pkg)
        tick++
    }

    private fun httpGet(url: String): ByteArray? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        try {
            if (c.responseCode != 200) null else c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }.getOrNull()

    suspend fun download(url: String): Bitmap? = withContext(Dispatchers.IO) {
        val u = url.trim().let { if (it.startsWith("http")) it else "https://$it" }
        httpGet(u)?.let { b -> runCatching { BitmapFactory.decodeByteArray(b, 0, b.size) }.getOrNull() }
    }

    private fun playIcon(id: String): Bitmap? {
        val html = httpGet("https://play.google.com/store/apps/details?id=$id&hl=en&gl=us")
            ?.toString(Charsets.UTF_8) ?: return null
        val m = Regex("""<meta property="og:image" content="([^"]+)""").find(html)
            ?: Regex("""(https://play-lh\.googleusercontent\.com/[A-Za-z0-9_\-]+)""").find(html) ?: return null
        val base = m.groupValues[1].substringBefore('=')
        return httpGet("$base=s256-rw")?.let { runCatching { BitmapFactory.decodeByteArray(it, 0, it.size) }.getOrNull() }
    }

    /**
     * Looks for icons that match the NAME shown in the launcher (so a renamed app is searched by its new
     * name): Play Store apps found by that name, logos from Wikipedia, and website icons guessed from the
     * name. The app's original Play Store icon (by package name) comes last.
     */
    suspend fun findCandidates(pkg: String, label: String): List<IconCandidate> = withContext(Dispatchers.IO) {
        val out = mutableListOf<IconCandidate>()
        val name = label.trim()
        val seen = HashSet<Int>()
        fun add(src: String, b: Bitmap?) {
            if (b == null || b.width < 24) return
            // Skip exact duplicates (same pixels at a small size).
            val key = Bitmap.createScaledBitmap(b, 4, 4, true).let { t -> (0 until 16).fold(7) { h, i -> h * 31 + t.getPixel(i % 4, i / 4) } }
            if (seen.add(key)) out += IconCandidate(src, b)
        }
        if (name.isNotEmpty()) {
            // 1. Play Store apps whose name matches.
            runCatching {
                val q = java.net.URLEncoder.encode(name, "UTF-8")
                val html = httpGet("https://play.google.com/store/search?q=$q&c=apps&hl=en&gl=us")?.toString(Charsets.UTF_8)
                val ids = Regex("""/store/apps/details\?id=([A-Za-z0-9._]+)""").findAll(html ?: "")
                    .map { it.groupValues[1] }.distinct().take(4).toList()
                for (id in ids) runCatching { add("Play Store", playIcon(id)) }
            }
            // 2. Wikipedia logos for the name.
            runCatching {
                val q = java.net.URLEncoder.encode("$name logo", "UTF-8")
                val body = httpGet(
                    "https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=$q&gsrlimit=4" +
                        "&prop=pageimages&piprop=thumbnail&pithumbsize=256&format=json"
                )?.toString(Charsets.UTF_8)
                val pages = org.json.JSONObject(body ?: "{}").optJSONObject("query")?.optJSONObject("pages")
                pages?.keys()?.forEach { k ->
                    pages.optJSONObject(k)?.optJSONObject("thumbnail")?.optString("source")?.takeIf { it.isNotBlank() }
                        ?.let { u -> runCatching { add("Wikipedia", httpGet(u)?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }) } }
                }
            }
            // 3. Website icons guessed from the name (whole name, first word) on common endings.
            val slugs = listOf(name, name.substringBefore(' ')).map { it.lowercase().replace(Regex("[^a-z0-9]"), "") }
                .filter { it.length > 1 }.distinct()
            for (sl in slugs) for (tld in listOf("com", "tv", "net", "org")) {
                runCatching {
                    add("$sl.$tld", httpGet("https://www.google.com/s2/favicons?domain=$sl.$tld&sz=128")
                        ?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }?.takeIf { it.width >= 48 })
                }
            }
        }
        // 4. The app's own Play Store listing (by package name).
        runCatching { add("Original", playIcon(pkg)) }
        out
    }
}

/** The app's icon: a saved custom (online) icon if there is one, else its own default icon. */
@Composable
internal fun AppIcon(pkg: String, size: Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val tick = IconStore.tick
    val bmp by produceState<ImageBitmap?>(iconCache[pkg], pkg, tick) {
        val loaded = withContext(Dispatchers.Default) {
            runCatching {
                val f = IconStore.file(ctx, pkg)
                if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
            }.getOrNull() ?: runCatching {
                ctx.packageManager.getApplicationIcon(pkg).toBitmap(160, 160).asImageBitmap()
            }.getOrNull()
        }
        if (loaded != null) {
            iconCache[pkg] = loaded
            value = loaded
        }
    }
    val custom = remember(pkg, tick) { IconStore.file(ctx, pkg).exists() }
    Box(modifier.size(size)) {
        bmp?.let {
            Image(
                it, contentDescription = null,
                modifier = Modifier.fillMaxSize().clip(if (custom) RoundedCornerShape(size * 0.22f) else RectangleShape),
            )
        }
    }
}
