package com.raiabrar.tvhome

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch

private val DialogBg = Color(0xFF1B1E24)

@Composable
private fun dialogFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary,
    focusedBorderColor = TextPrimary, unfocusedBorderColor = LineColor,
    focusedLabelColor = TextPrimary, unfocusedLabelColor = TextDim, cursorColor = TextPrimary,
)

@Composable
internal fun DialogButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Box(
        modifier
            .height(52.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 22.u()),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 22.us(), maxLines = 1,
            style = TextStyle(lineHeight = 28.us(), lineHeightStyle = MidLine),
        )
    }
}

/** Rename an app. Saving an empty name restores the original name. */
@Composable
internal fun RenameDialog(current: String, original: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(current.ifBlank { original }) }
    val shape = RoundedCornerShape(16.u())
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.width(520.u()).clip(shape).background(DialogBg).border(2.u(), FocusBorder, shape).padding(20.u()),
            verticalArrangement = Arrangement.spacedBy(14.u()),
        ) {
            Text("Rename app", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                label = { Text("Name") },
                textStyle = TextStyle(fontSize = 22.us(), color = TextPrimary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onSave(text) }),
                colors = dialogFieldColors(), modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.u())) {
                DialogButton("Save") { onSave(text) }
                DialogButton("Original name") { text = original }
                DialogButton("Cancel", onClick = onDismiss)
            }
        }
    }
}

/**
 * Pick a new icon from online sources relevant to the app (Play Store listing icon, website
 * favicons) or paste any image link. "Default icon" restores the app's own icon.
 */
@Composable
internal fun ChangeIconDialog(pkg: String, label: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var cands by remember { mutableStateOf<List<IconCandidate>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf<String?>(null) }
    var url by remember { mutableStateOf("") }
    val shape = RoundedCornerShape(16.u())

    LaunchedEffect(pkg) {
        cands = IconStore.findCandidates(pkg, label)
        loading = false
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.width(620.u()).clip(shape).background(DialogBg).border(2.u(), FocusBorder, shape).padding(20.u()),
            verticalArrangement = Arrangement.spacedBy(14.u()),
        ) {
            Text(
                "Change icon  -  $label", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Box(Modifier.fillMaxWidth().height(86.u()), contentAlignment = Alignment.CenterStart) {
                when {
                    loading -> Text("Searching online...", color = TextDim, fontSize = 20.us())
                    cands.isEmpty() -> Text(
                        "No icon found online for this app. Paste an image link below.",
                        color = TextDim, fontSize = 20.us(),
                    )
                    else -> LazyRow(horizontalArrangement = Arrangement.spacedBy(14.u())) {
                        itemsIndexed(cands) { _, c ->
                            IconTile(c) {
                                IconStore.save(ctx, pkg, c.bitmap)
                                onDismiss()
                            }
                        }
                    }
                }
            }
            OutlinedTextField(
                value = url, onValueChange = { url = it; status = null }, singleLine = true,
                label = { Text("Or paste an image link") },
                textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                colors = dialogFieldColors(), modifier = Modifier.fillMaxWidth(),
            )
            status?.let { Text(it, color = TextDim, fontSize = 18.us()) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.u())) {
                DialogButton("Use link") {
                    if (url.isBlank()) {
                        status = "Enter an image link first."
                    } else {
                        status = "Downloading..."
                        scope.launch {
                            val b = IconStore.download(url)
                            if (b == null) {
                                status = "Could not load an image from that link."
                            } else {
                                IconStore.save(ctx, pkg, b)
                                onDismiss()
                            }
                        }
                    }
                }
                DialogButton("Default icon") {
                    IconStore.reset(ctx, pkg)
                    onDismiss()
                }
                DialogButton("Cancel", onClick = onDismiss)
            }
        }
    }
}

@Composable
private fun IconTile(c: IconCandidate, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.u())
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(64.u())
                .clip(shape)
                .background(if (focused) FocusFill else Color(0xFF181A1F))
                .border(2.u(), if (focused) TextPrimary else Color.Transparent, shape)
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick)
                .padding(6.u()),
        ) {
            Image(c.bitmap.asImageBitmap(), contentDescription = c.source, modifier = Modifier.size(52.u()))
        }
        Spacer(Modifier.height(4.u()))
        Text(c.source, color = TextDim, fontSize = 14.us(), maxLines = 1)
    }
}
