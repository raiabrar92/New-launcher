package com.raiabrar.tvhome

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch
import android.content.Context
import android.content.Intent
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.delay

private val DialogBg = Color(0xFF1B1E24)

@Composable
private fun dialogFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary,
    focusedBorderColor = TextPrimary, unfocusedBorderColor = LineColor,
    focusedLabelColor = TextPrimary, unfocusedLabelColor = TextDim, cursorColor = TextPrimary,
)

@Composable
internal fun DialogButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Box(
        modifier
            .height(52.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 22.u()),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 22.us(), maxLines = 1,
            style = TextStyle(lineHeight = 28.us(), lineHeightStyle = MidLine),
        )
    }
}

/** Rename an app. Saving an empty name restores the original name. */
@Composable
internal fun RenameDialog(current: String, original: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(current.ifBlank { original }) }
    val shape = RoundedCornerShape(16.u())
    KeyboardDialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.width(520.u()).clip(shape).background(DialogBg).border(2.u(), FocusBorder, shape).padding(20.u()),
            verticalArrangement = Arrangement.spacedBy(14.u()),
        ) {
            Text("Rename app", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                label = { Text("Name") },
                textStyle = TextStyle(fontSize = 22.us(), color = TextPrimary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onSave(text) }),
                colors = dialogFieldColors(), modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.u())) {
                DialogButton("Save") { onSave(text) }
                DialogButton("Original name") { text = original }
                DialogButton("Cancel", onClick = onDismiss)
            }
        }
    }
}

/**
 * Pick a new icon from online sources relevant to the app (Play Store listing icon, website
 * favicons) or paste any image link. "Default icon" restores the app's own icon.
 */
@Composable
internal fun ChangeIconDialog(pkg: String, label: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var cands by remember { mutableStateOf<List<IconCandidate>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf<String?>(null) }
    var url by remember { mutableStateOf("") }
    val shape = RoundedCornerShape(16.u())

    LaunchedEffect(pkg) {
        cands = IconStore.findCandidates(pkg, label)
        loading = false
    }

    KeyboardDialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.width(620.u()).clip(shape).background(DialogBg).border(2.u(), FocusBorder, shape).padding(20.u()),
            verticalArrangement = Arrangement.spacedBy(14.u()),
        ) {
            Text(
                "Change icon  -  $label", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Box(Modifier.fillMaxWidth().height(86.u()), contentAlignment = Alignment.CenterStart) {
                when {
                    loading -> Text("Searching online...", color = TextDim, fontSize = 20.us())
                    cands.isEmpty() -> Text(
                        "No icon found online for this app. Paste an image link below.",
                        color = TextDim, fontSize = 20.us(),
                    )
                    else -> LazyRow(horizontalArrangement = Arrangement.spacedBy(14.u())) {
                        itemsIndexed(cands) { _, c ->
                            IconTile(c) {
                                IconStore.save(ctx, pkg, c.bitmap)
                                onDismiss()
                            }
                        }
                    }
                }
            }
            OutlinedTextField(
                value = url, onValueChange = { url = it; status = null }, singleLine = true,
                label = { Text("Or paste an image link") },
                textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                colors = dialogFieldColors(), modifier = Modifier.fillMaxWidth(),
            )
            status?.let { Text(it, color = TextDim, fontSize = 18.us()) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.u())) {
                DialogButton("Use link") {
                    if (url.isBlank()) {
                        status = "Enter an image link first."
                    } else {
                        status = "Downloading..."
                        scope.launch {
                            val b = IconStore.download(url)
                            if (b == null) {
                                status = "Could not load an image from that link."
                            } else {
                                IconStore.save(ctx, pkg, b)
                                onDismiss()
                            }
                        }
                    }
                }
                DialogButton("Default icon") {
                    IconStore.reset(ctx, pkg)
                    onDismiss()
                }
                DialogButton("Cancel", onClick = onDismiss)
            }
        }
    }
}

@Composable
private fun IconTile(c: IconCandidate, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.u())
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(64.u())
                .clip(shape)
                .background(if (focused) FocusFill else Color(0xFF181A1F))
                .border(2.u(), if (focused) TextPrimary else Color.Transparent, shape)
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick)
                .padding(6.u()),
        ) {
            Image(c.bitmap.asImageBitmap(), contentDescription = c.source, modifier = Modifier.size(52.u()))
        }
        Spacer(Modifier.height(4.u()))
        Text(c.source, color = TextDim, fontSize = 14.us(), maxLines = 1)
    }
}

/** Asks for the lock code (masked). Calls [onOk] as soon as the right code is typed. */
@Composable
internal fun PinPromptDialog(title: String, expected: String, onOk: () -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    val requester = remember { FocusRequester() }
    val shape = RoundedCornerShape(16.u())
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { requester.requestFocus() }
    }
    KeyboardDialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.width(480.u()).clip(shape).background(DialogBg).border(2.u(), FocusBorder, shape).padding(20.u()),
            verticalArrangement = Arrangement.spacedBy(14.u()),
        ) {
            Text(title, color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            OutlinedTextField(
                value = text,
                onValueChange = { v ->
                    val d = v.filter { it.isDigit() }.take(8)
                    wrong = false
                    text = d
                    if (d.isNotEmpty() && d == expected) {
                        onOk()
                    } else if (d.length >= expected.length) {
                        text = ""
                        wrong = true
                    }
                },
                singleLine = true,
                isError = wrong,
                label = { Text(if (wrong) "Wrong PIN" else "PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                textStyle = TextStyle(fontSize = 24.us(), color = TextPrimary, letterSpacing = 4.us()),
                colors = dialogFieldColors(),
                modifier = Modifier.fillMaxWidth().focusRequester(requester),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.u())) {
                DialogButton("Cancel", onClick = onDismiss)
            }
        }
    }
}

/**
 * Set or change the lock code. When a code already exists, the current one must be entered
 * correctly first. Every field is masked, so the code is never shown on screen.
 */
@Composable
internal fun ChangePinDialog(currentPin: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var stage by remember { mutableIntStateOf(if (currentPin.isEmpty()) 1 else 0) } // 0 current, 1 new, 2 confirm
    var text by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    val requester = remember { FocusRequester() }
    val shape = RoundedCornerShape(16.u())

    LaunchedEffect(stage) {
        delay(120)
        runCatching { requester.requestFocus() }
    }

    fun submit() {
        when (stage) {
            0 -> if (text == currentPin) {
                stage = 1; text = ""; msg = null
            } else {
                msg = "Wrong PIN"; text = ""
            }
            1 -> if (text.length >= 4) {
                first = text; text = ""; stage = 2; msg = null
            } else {
                msg = "Use 4 to 8 digits"
            }
            else -> if (text == first) {
                onSave(text)
            } else {
                msg = "The two codes do not match. Try again."; text = ""; first = ""; stage = 1
            }
        }
    }

    val title = when (stage) {
        0 -> "Enter current PIN"
        1 -> if (currentPin.isEmpty()) "Set lock code" else "Enter new PIN"
        else -> "Confirm new PIN"
    }
    val label = when (stage) {
        0 -> "Current PIN"
        1 -> "New PIN (4 to 8 digits)"
        else -> "Repeat new PIN"
    }

    KeyboardDialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.width(520.u()).clip(shape).background(DialogBg).border(2.u(), FocusBorder, shape).padding(20.u()),
            verticalArrangement = Arrangement.spacedBy(14.u()),
        ) {
            Text(title, color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            OutlinedTextField(
                value = text,
                onValueChange = { v ->
                    val d = v.filter { it.isDigit() }.take(8)
                    msg = null
                    text = d
                    if (stage == 0) {
                        if (d == currentPin) {
                            submit()
                        } else if (d.length >= currentPin.length) {
                            text = ""
                            msg = "Wrong PIN"
                        }
                    }
                },
                singleLine = true,
                isError = msg != null,
                label = { Text(label) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                textStyle = TextStyle(fontSize = 24.us(), color = TextPrimary, letterSpacing = 4.us()),
                colors = dialogFieldColors(),
                modifier = Modifier.fillMaxWidth().focusRequester(requester),
            )
            msg?.let { Text(it, color = Color(0xFFE57373), fontSize = 18.us()) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.u())) {
                if (stage != 0) DialogButton(if (stage == 2) "Save" else "Next") { submit() }
                DialogButton("Cancel", onClick = onDismiss)
            }
        }
    }
}

private fun findInputs(ctx: Context): List<Pair<String, String>> = runCatching {
    val tm = ctx.getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
    tm.tvInputList.filter { it.isPassthroughInput }.map { info ->
        info.id to (info.loadLabel(ctx)?.toString()?.takeIf { it.isNotBlank() } ?: info.id)
    }
}.getOrDefault(emptyList())

/** Lists the TV's HDMI / external inputs and switches to the one you pick. */
@Composable
internal fun InputSourceDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val inputs = remember { findInputs(ctx) }
    val shape = RoundedCornerShape(16.u())
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.width(480.u()).clip(shape).background(DialogBg).border(2.u(), FocusBorder, shape).padding(20.u()),
            verticalArrangement = Arrangement.spacedBy(10.u()),
        ) {
            Text("Input Source", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            if (inputs.isEmpty()) {
                Text("No input sources were found on this TV.", color = TextDim, fontSize = 20.us())
                DialogButton("Open TV settings", Modifier.fillMaxWidth()) {
                    onDismiss()
                    openSystem(ctx, Settings.ACTION_SETTINGS)
                }
            } else {
                inputs.forEach { (id, label) ->
                    DialogButton(label, Modifier.fillMaxWidth()) {
                        onDismiss()
                        runCatching {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(id))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }.onFailure {
                            Toast.makeText(ctx, "Could not switch to $label", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            DialogButton("Close", Modifier.fillMaxWidth(), onClick = onDismiss)
        }
    }
}

/**
 * Dialog for screens with a text box. The on-screen keyboard must not squeeze it: the window keeps
 * its size when the keyboard opens (no resize) and sits near the top, so the text box stays the same
 * size and is not hidden behind the keyboard.
 */
@Composable
internal fun KeyboardDialog(onDismissRequest: () -> Unit, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onDismissRequest, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val view = androidx.compose.ui.platform.LocalView.current
        androidx.compose.runtime.SideEffect {
            (view.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window?.let { w ->
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
                w.setGravity(android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL)
                val lp = w.attributes
                lp.y = (view.resources.displayMetrics.density * 24f).toInt()
                w.attributes = lp
            }
        }
        content()
    }
}
