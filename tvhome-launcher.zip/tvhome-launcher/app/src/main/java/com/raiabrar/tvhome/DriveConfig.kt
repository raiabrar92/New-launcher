package com.raiabrar.tvhome

/**
 * Google Drive backup needs an OAuth client of type "TVs and Limited Input devices".
 * Create one (free) in Google Cloud Console, paste the two values below, then rebuild.
 * Step by step: see "Google Drive backup" in README.md.
 *
 * These are not user secrets: Google's device-code flow is designed for apps that ship
 * the client id/secret inside the APK. Each user still signs in with their own account.
 */
internal object DriveConfig {
    val CLIENT_ID: String = ""
    val CLIENT_SECRET: String = ""
}
