package com.raiabrar.tvhome

import android.accounts.Account
import android.accounts.AccountManager
import android.accounts.AccountManagerCallback
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import kotlin.coroutines.resume

/** What the user must do on their phone to approve the sign-in. */
internal class DeviceCode(
    val deviceCode: String,
    val userCode: String,
    val url: String,
    val expiresIn: Int,
    val interval: Int,
)

/**
 * Backup of all launcher settings and data (app order, hidden / locked apps, lock code, custom
 * names, custom icons, links, wallpaper and screensaver settings, wallpapers) to the user's own
 * Google Drive, in the hidden app-data folder that only this app can see.
 *
 * Sign-in uses Google's device-code flow (works on any TV, no Play Services needed).
 * The Drive tokens live in a separate preferences file that is never part of the backup.
 */
internal object DriveSync {
    private const val SCOPE = "https://www.googleapis.com/auth/drive.appdata"
    private const val GOOGLE = "com.google"
    private const val AUTH_TYPE = "oauth2:$SCOPE"
    private const val TOKEN_URL = "https://oauth2.googleapis.com/token"
    private const val FILE_NAME = "tvhome-backup.json.gz"
    private const val FILE_DIRS_MAX_BYTES = 20_000_000L

    private lateinit var app: Context
    private lateinit var dp: SharedPreferences        // Drive tokens + sync state (never backed up)
    private lateinit var launcherPrefs: SharedPreferences
    private var listener: SharedPreferences.OnSharedPreferenceChangeListener? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private var debounce: Job? = null
    @Volatile private var restoring = false

    var signedIn by mutableStateOf(false)
        private set
    var autoSync by mutableStateOf(false)
        private set
    var lastBackup by mutableStateOf(0L)
        private set
    var message by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
        private set
    /** Google account of the TV that is connected (empty when connected with a phone code). */
    var accountName by mutableStateOf("")
        private set
    /** The automatic connect with the TV's own Google account is tried once per app run. */
    var autoAttachTried = false

    val configured: Boolean
        get() = DriveConfig.CLIENT_ID.isNotBlank() && DriveConfig.CLIENT_SECRET.isNotBlank()

    fun init(ctx: Context) {
        if (::app.isInitialized) return
        app = ctx.applicationContext
        dp = app.getSharedPreferences("tvhome_drive", Context.MODE_PRIVATE)
        launcherPrefs = app.getSharedPreferences("tvhome", Context.MODE_PRIVATE)
        accountName = dp.getString("account", "") ?: ""
        signedIn = accountName.isNotEmpty() || (dp.getString("refresh", "") ?: "").isNotEmpty()
        autoSync = dp.getBoolean("auto", false)
        lastBackup = dp.getLong("last", 0L)
        // Auto sync: any change to the launcher settings is uploaded after a short quiet period.
        // (Kept in a field: SharedPreferences only holds listeners weakly.)
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> scheduleAuto() }
        listener = l
        launcherPrefs.registerOnSharedPreferenceChangeListener(l)
    }

    fun enableAutoSync(on: Boolean) {
        autoSync = on
        dp.edit().putBoolean("auto", on).apply()
        if (on) {
            if (lastBackup == 0L) {
                message = "Auto sync is on. Use Back up now (or Restore) once first so a new device cannot overwrite your backup."
            } else {
                scheduleAuto()
            }
        }
    }

    private fun scheduleAuto() {
        if (!autoSync || !signedIn || restoring || lastBackup == 0L) return
        debounce?.cancel()
        debounce = scope.launch {
            delay(30_000)
            backup(manual = false)
        }
    }

    // ---- Sign-in (device code flow) ----------------------------------------------------------

    suspend fun beginSignIn(): DeviceCode? = withContext(Dispatchers.IO) {
        try {
            val (code, body) = form(
                "https://oauth2.googleapis.com/device/code",
                mapOf("client_id" to DriveConfig.CLIENT_ID, "scope" to SCOPE),
            )
            if (code != 200) {
                message = "Sign-in failed: " + errorText(code, body)
                return@withContext null
            }
            val j = JSONObject(String(body))
            DeviceCode(
                j.getString("device_code"), j.getString("user_code"),
                j.optString("verification_url", "https://www.google.com/device"),
                j.optInt("expires_in", 1800), j.optInt("interval", 5),
            )
        } catch (e: Exception) {
            message = "Sign-in failed: ${e.message}"
            null
        }
    }

    /** Waits until the code is approved on the phone. Returns true when signed in. */
    suspend fun finishSignIn(dc: DeviceCode): Boolean {
        var interval = maxOf(dc.interval, 3)
        val end = System.currentTimeMillis() + dc.expiresIn * 1000L
        while (System.currentTimeMillis() < end) {
            delay(interval * 1000L)
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    form(
                        TOKEN_URL,
                        mapOf(
                            "client_id" to DriveConfig.CLIENT_ID,
                            "client_secret" to DriveConfig.CLIENT_SECRET,
                            "device_code" to dc.deviceCode,
                            "grant_type" to "urn:ietf:params:oauth:grant-type:device_code",
                        ),
                    )
                }.getOrNull()
            } ?: continue
            val j = runCatching { JSONObject(String(r.second)) }.getOrNull() ?: continue
            if (r.first == 200) {
                saveTokens(j)
                signedIn = true
                message = "Signed in to Google Drive"
                return true
            }
            when (j.optString("error")) {
                "authorization_pending" -> {}
                "slow_down" -> interval += 5
                else -> {
                    message = "Sign-in failed: " + j.optString("error_description", j.optString("error"))
                    return false
                }
            }
        }
        message = "Sign-in code expired. Try again."
        return false
    }

    fun signOut() {
        debounce?.cancel()
        if (accountName.isNotEmpty()) {
            val t = dp.getString("access", "") ?: ""
            if (t.isNotEmpty()) runCatching { AccountManager.get(app).invalidateAuthToken(GOOGLE, t) }
        }
        dp.edit().clear().apply()
        accountName = ""
        signedIn = false
        autoSync = false
        lastBackup = 0L
        message = "Signed out"
    }

    // ---- Sign-in with the Google account already on the TV ----------------------------------

    /** Google accounts of this TV (needs the Accounts permission). */
    fun googleAccounts(): List<String> =
        runCatching { AccountManager.get(app).getAccountsByType(GOOGLE).map { it.name } }.getOrDefault(emptyList())

    fun playServicesPresent(): Boolean =
        runCatching { app.packageManager.getPackageInfo("com.google.android.gms", 0); true }.getOrDefault(false)

    /** Connects Drive to a Google account already on this TV; Google may show a permission screen once. */
    suspend fun attachDeviceAccount(activity: Activity, name: String): Boolean {
        busy = true
        val result: Bundle? = suspendCancellableCoroutine { cont ->
            try {
                AccountManager.get(activity).getAuthToken(
                    Account(name, GOOGLE), AUTH_TYPE, null, activity,
                    AccountManagerCallback<Bundle> { fut -> cont.resume(runCatching { fut.result }.getOrNull()) },
                    null,
                )
            } catch (e: Exception) {
                cont.resume(null)
            }
        }
        busy = false
        val tok = result?.getString(AccountManager.KEY_AUTHTOKEN)
        if (tok.isNullOrEmpty()) {
            message = "Could not use the Google account $name on this TV."
            return false
        }
        debounce?.cancel()
        dp.edit().clear()
            .putString("account", name)
            .putString("access", tok)
            .putLong("exp", System.currentTimeMillis() + 50 * 60_000L)
            .apply()
        accountName = name
        signedIn = true
        autoSync = false
        lastBackup = 0L
        message = "Connected to Google Drive with $name"
        return true
    }

    /** Fresh access token for the TV's Google account. Blocking: call off the main thread. */
    private fun accountToken(): String? {
        val acc = dp.getString("access", "") ?: ""
        if (acc.isNotEmpty() && System.currentTimeMillis() < dp.getLong("exp", 0L) - 60_000) return acc
        val am = AccountManager.get(app)
        if (acc.isNotEmpty()) runCatching { am.invalidateAuthToken(GOOGLE, acc) }
        val b = runCatching {
            am.getAuthToken(Account(accountName, GOOGLE), AUTH_TYPE, null, false, null, null).result
        }.getOrNull()
        val t = b?.getString(AccountManager.KEY_AUTHTOKEN)
        if (t.isNullOrEmpty()) {
            dp.edit().remove("access").apply()
            accountName = ""
            signedIn = false
            message = "Google needs your permission again. Connect again in Backup & sync."
            return null
        }
        dp.edit().putString("access", t).putLong("exp", System.currentTimeMillis() + 50 * 60_000L).apply()
        return t
    }

    private fun saveTokens(j: JSONObject) {
        val e = dp.edit()
        e.putString("access", j.optString("access_token"))
        e.putLong("exp", System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L)
        if (j.has("refresh_token")) e.putString("refresh", j.getString("refresh_token"))
        e.apply()
    }

    /** A valid access token (refreshed when needed), or null when sign-in is gone. Blocking. */
    private fun token(): String? {
        if (accountName.isNotEmpty()) return accountToken()
        val acc = dp.getString("access", "") ?: ""
        if (acc.isNotEmpty() && System.currentTimeMillis() < dp.getLong("exp", 0L) - 60_000) return acc
        val refresh = dp.getString("refresh", "") ?: ""
        if (refresh.isEmpty()) return null
        val (code, body) = form(
            TOKEN_URL,
            mapOf(
                "client_id" to DriveConfig.CLIENT_ID,
                "client_secret" to DriveConfig.CLIENT_SECRET,
                "refresh_token" to refresh,
                "grant_type" to "refresh_token",
            ),
        )
        val j = runCatching { JSONObject(String(body)) }.getOrNull()
        if (code == 200 && j != null) {
            saveTokens(j)
            return j.optString("access_token")
        }
        if (j?.optString("error") == "invalid_grant") {
            dp.edit().remove("refresh").remove("access").apply()
            signedIn = false
        }
        return null
    }

    /**
     * Back to a fresh launcher: every launcher setting, custom icon and wallpaper is deleted.
     * The Google Drive sign-in stays, but auto sync is switched off so the Drive copy is not
     * overwritten by the empty settings.
     */
    fun resetAllSettings() {
        debounce?.cancel()
        restoring = true
        try {
            for (dir in listOf("icons", "wallpapers")) {
                File(app.filesDir, dir).listFiles()?.forEach { it.delete() }
            }
            launcherPrefs.edit().clear().commit()
        } finally {
            restoring = false
        }
        autoSync = false
        dp.edit().putBoolean("auto", false).remove("hash").apply()
        IconStore.bumpAll()
        WallpaperStore.bump()
        message = "All settings reset to default"
    }

    // ---- Backup / restore --------------------------------------------------------------------

    suspend fun backup(manual: Boolean): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (!signedIn) {
                if (manual) message = "Sign in to Google Drive first"
                return@withLock false
            }
            if (!manual && lastBackup == 0L) return@withLock false
            busy = true
            try {
                val access = token() ?: throw IOException("sign-in expired, please sign in again")
                val json = buildJson()
                val hash = sha256(json)
                if (!manual && hash == dp.getString("hash", "")) return@withLock true
                val gz = gzip(json.toByteArray())
                val id = findFileId(access)
                val (code, body) = if (id == null) {
                    val boundary = "tvhome" + System.nanoTime()
                    val meta = JSONObject().put("name", FILE_NAME).put("parents", JSONArray().put("appDataFolder"))
                    val out = ByteArrayOutputStream()
                    out.write(("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n").toByteArray())
                    out.write(("--$boundary\r\nContent-Type: application/octet-stream\r\n\r\n").toByteArray())
                    out.write(gz)
                    out.write("\r\n--$boundary--".toByteArray())
                    http(
                        "POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
                        access, out.toByteArray(), "multipart/related; boundary=$boundary",
                    )
                } else {
                    http(
                        "POST", "https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media",
                        access, gz, "application/octet-stream", override = "PATCH",
                    )
                }
                if (code !in 200..299) throw IOException(errorText(code, body))
                val now = System.currentTimeMillis()
                dp.edit().putString("hash", hash).putLong("last", now).apply()
                lastBackup = now
                message = "Backed up to Google Drive"
                true
            } catch (e: Exception) {
                if (manual) message = "Backup failed: ${e.message}"
                false
            } finally {
                busy = false
            }
        }
    }

    /** Replaces all launcher settings and data with the copy stored in Drive. */
    suspend fun restore(): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (!signedIn) {
                message = "Sign in to Google Drive first"
                return@withLock false
            }
            busy = true
            try {
                val access = token() ?: throw IOException("sign-in expired, please sign in again")
                val id = findFileId(access)
                if (id == null) {
                    message = "No backup found in your Google Drive yet"
                    return@withLock false
                }
                val (code, bytes) = http("GET", "https://www.googleapis.com/drive/v3/files/$id?alt=media", access)
                if (code != 200) throw IOException(errorText(code, bytes))
                val json = JSONObject(String(gunzip(bytes)))
                if (json.optString("app") != "tvhome") throw IOException("this is not a launcher backup")
                restoring = true
                try {
                    applyJson(json)
                } finally {
                    restoring = false
                }
                val now = System.currentTimeMillis()
                dp.edit().putString("hash", sha256(buildJson())).putLong("last", now).apply()
                lastBackup = now
                IconStore.bumpAll()
                WallpaperStore.bump()
                message = "Restored from Google Drive"
                true
            } catch (e: Exception) {
                message = "Restore failed: ${e.message}"
                false
            } finally {
                busy = false
            }
        }
    }

    private fun findFileId(access: String): String? {
        val q = URLEncoder.encode("name='$FILE_NAME'", "UTF-8")
        val (code, body) = http(
            "GET",
            "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=$q&fields=files(id)",
            access,
        )
        if (code != 200) throw IOException(errorText(code, body))
        val arr = JSONObject(String(body)).getJSONArray("files")
        return if (arr.length() > 0) arr.getJSONObject(0).getString("id") else null
    }

    private fun buildJson(): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("app", "tvhome")
        val prefs = JSONObject()
        for ((k, v) in launcherPrefs.all) {
            val o = JSONObject()
            when (v) {
                is Boolean -> o.put("t", "b").put("v", v)
                is Int -> o.put("t", "i").put("v", v)
                is Long -> o.put("t", "l").put("v", v)
                is Float -> o.put("t", "f").put("v", v.toDouble())
                is String -> o.put("t", "s").put("v", v)
                is Set<*> -> o.put("t", "ss").put("v", JSONArray(v.map { it.toString() }.sorted()))
                else -> continue
            }
            prefs.put(k, o)
        }
        root.put("prefs", prefs)
        val files = JSONObject()
        var total = 0L
        for (dir in listOf("icons", "wallpapers")) {
            File(app.filesDir, dir).listFiles()?.sortedBy { it.name }?.forEach { f ->
                if (f.isFile && total + f.length() <= FILE_DIRS_MAX_BYTES) {
                    total += f.length()
                    files.put("$dir/${f.name}", Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))
                }
            }
        }
        root.put("files", files)
        return root.toString()
    }

    private fun applyJson(json: JSONObject) {
        val base = app.filesDir.canonicalPath
        for (dir in listOf("icons", "wallpapers")) {
            File(app.filesDir, dir).listFiles()?.forEach { it.delete() }
        }
        json.optJSONObject("files")?.let { files ->
            for (name in files.keys()) {
                if (!(name.startsWith("icons/") || name.startsWith("wallpapers/"))) continue
                val f = File(app.filesDir, name)
                if (!f.canonicalPath.startsWith("$base/")) continue
                f.parentFile?.mkdirs()
                f.writeBytes(Base64.decode(files.getString(name), Base64.NO_WRAP))
            }
        }
        val ed = launcherPrefs.edit().clear()
        json.optJSONObject("prefs")?.let { prefs ->
            for (k in prefs.keys()) {
                val o = prefs.getJSONObject(k)
                when (o.optString("t")) {
                    "b" -> ed.putBoolean(k, o.getBoolean("v"))
                    "i" -> ed.putInt(k, o.getInt("v"))
                    "l" -> ed.putLong(k, o.getLong("v"))
                    "f" -> ed.putFloat(k, o.getDouble("v").toFloat())
                    "s" -> ed.putString(k, o.getString("v"))
                    "ss" -> {
                        val a = o.getJSONArray("v")
                        ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet())
                    }
                }
            }
        }
        ed.commit()
    }

    // ---- HTTP helpers ------------------------------------------------------------------------

    private fun form(url: String, params: Map<String, String>): Pair<Int, ByteArray> {
        val body = params.entries.joinToString("&") {
            URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
        }
        return http("POST", url, null, body.toByteArray(), "application/x-www-form-urlencoded")
    }

    private fun http(
        method: String,
        url: String,
        token: String?,
        body: ByteArray? = null,
        contentType: String? = null,
        override: String? = null,
    ): Pair<Int, ByteArray> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000
            c.readTimeout = 60_000
            c.requestMethod = method
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            if (override != null) c.setRequestProperty("X-HTTP-Method-Override", override)
            if (contentType != null) c.setRequestProperty("Content-Type", contentType)
            if (body != null) {
                c.doOutput = true
                c.setFixedLengthStreamingMode(body.size)
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            return Pair(code, stream?.use { it.readBytes() } ?: ByteArray(0))
        } finally {
            c.disconnect()
        }
    }

    private fun errorText(code: Int, body: ByteArray): String {
        val j = runCatching { JSONObject(String(body)) }.getOrNull()
        val msg = j?.optJSONObject("error")?.optString("message")?.takeIf { it.isNotEmpty() }
            ?: j?.optString("error_description")?.takeIf { it.isNotEmpty() }
            ?: j?.optString("error")?.takeIf { it.isNotEmpty() }
        return msg ?: "HTTP $code"
    }

    private fun gzip(b: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        GZIPOutputStream(o).use { it.write(b) }
        return o.toByteArray()
    }

    private fun gunzip(b: ByteArray): ByteArray = GZIPInputStream(b.inputStream()).use { it.readBytes() }

    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
