package com.raiabrar.tvhome

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * "Glass" highlighter: a translucent slab with a soft top reflection, a bright rim and a faint glow.
 * Ported from the GlassView of github.com/gathin23/cleanyourtv (MIT), see THIRD_PARTY.md.
 *
 * The slab is drawn [inset] inside the row so its glow stays inside the row bounds (a LazyColumn clips
 * anything outside the rows). [strong] = brighter rim (used while an app is being moved).
 */
internal fun Modifier.glassHighlight(radius: Dp, inset: Dp, strong: Boolean = false): Modifier = drawBehind {
    val ins = inset.toPx()
    val r = radius.toPx()
    val slab = Rect(Offset(ins, ins), Size(size.width - 2 * ins, size.height - 2 * ins))
    if (slab.width <= 0f || slab.height <= 0f) return@drawBehind
    val shape = Path().apply { addRoundRect(RoundRect(slab, CornerRadius(r, r))) }

    // Glow: thin white rings fading outwards.
    val rings = 12
    for (i in 1..rings) {
        val grow = ins * i / rings
        val a = 0x30 * (1f - i / (rings + 1f)) / 255f
        drawRoundRect(
            color = Color.White.copy(alpha = a),
            topLeft = Offset(slab.left - grow, slab.top - grow),
            size = Size(slab.width + 2 * grow, slab.height + 2 * grow),
            cornerRadius = CornerRadius(r + grow, r + grow),
            style = Stroke(width = 1.dp.toPx()),
        )
    }
    // Body of the glass.
    drawPath(shape, Brush.verticalGradient(listOf(Color(0x3DFFFFFF), Color(0x12FFFFFF)), slab.top, slab.bottom))
    // Specular highlight over the top 45 %.
    clipPath(shape) {
        drawRect(
            Brush.verticalGradient(listOf(Color(0x66FFFFFF), Color(0x00FFFFFF)), slab.top, slab.top + slab.height * 0.45f),
            topLeft = slab.topLeft,
            size = Size(slab.width, slab.height * 0.45f),
        )
    }
    // Rim.
    drawPath(
        shape,
        if (strong) Color.White else Color(0xCCFFFFFF),
        style = Stroke(width = (if (strong) 2.5f else 1.5f).dp.toPx()),
    )
}
