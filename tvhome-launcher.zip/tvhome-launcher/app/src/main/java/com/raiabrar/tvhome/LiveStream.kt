package com.raiabrar.tvhome

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.delay

/** Live preview tile: not focusable and not clickable. Muted unless turned off in settings. */
@Composable
internal fun LiveCard(
    links: List<String>, intervalMin: Int, muted: Boolean, refreshKey: Int, modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(12.u())
    Box(
        modifier
            .clip(shape)
            .background(ThumbColor)
            // Border is drawn over the content, so the stream area stays exactly 16:9.
            .border(2.u(), LineColor, shape)
    ) {
        LivePreview(links, intervalMin, muted, refreshKey)
    }
}

// controls=0 / iv_load_policy=3 / rel=0 already remove controls, annotations and suggestions;
// AdBlock removes the ads themselves.
private fun ytParams(muted: Boolean) =
    "autoplay=1&mute=${if (muted) 1 else 0}&controls=0&fs=0&disablekb=1&cc_load_policy=0&iv_load_policy=3&playsinline=1&rel=0&modestbranding=1"

// Videos on any page: always "contain" (whole picture visible, no crop); muted when asked.
internal fun mediaJs(muted: Boolean): String =
    (if (muted) "document.querySelectorAll('video,audio').forEach(function(v){v.muted=true;v.volume=0;});" else "") +
        "document.querySelectorAll('video').forEach(function(v){v.style.objectFit='contain';});"

private fun youTubeSrc(u: String, muted: Boolean): String? {
    val params = ytParams(muted)
    Regex("""(?:youtu\.be/|youtube(?:-nocookie)?\.com/(?:watch\?(?:[^#]*&)?v=|embed/|live/|shorts/|v/))([A-Za-z0-9_-]{11})""")
        .find(u)?.let { return "https://www.youtube.com/embed/${it.groupValues[1]}?$params" }
    Regex("""youtube\.com/channel/(UC[A-Za-z0-9_-]{22})""")
        .find(u)?.let { return "https://www.youtube.com/embed/live_stream?channel=${it.groupValues[1]}&$params" }
    if (Regex("^[A-Za-z0-9_-]{11}$").matches(u)) return "https://www.youtube.com/embed/$u?$params"
    return null
}

/** Plain 11-character YouTube video id, or null (channel links and other pages). */
private fun youTubeVideoId(u: String): String? {
    Regex("""(?:youtu\.be/|youtube(?:-nocookie)?\.com/(?:watch\?(?:[^#]*&)?v=|embed/|live/|shorts/|v/))([A-Za-z0-9_-]{11})""")
        .find(u)?.let { return it.groupValues[1] }
    if (Regex("^[A-Za-z0-9_-]{11}$").matches(u)) return u
    return null
}

/**
 * YouTube page built on the IFrame Player API, so the tile can say WHY a video does not play
 * (error codes) instead of staying black. Old-WebView friendly: no modern CSS, no ES6.
 */
private fun ytApiHtml(id: String, muted: Boolean): String = """
    <html><body style="margin:0;background:#000;overflow:hidden">
    <div id="p" style="position:absolute;top:0;left:0;width:100%;height:100%"></div>
    <script>
    function say(s){try{window.TvHome.report(s);}catch(e){}}
    window.onerror=function(m){say('error:js '+m);};
    function onYouTubeIframeAPIReady(){
      new YT.Player('p',{width:'100%',height:'100%',videoId:'$id',
        playerVars:{autoplay:1,mute:${if (muted) 1 else 0},controls:0,fs:0,disablekb:1,cc_load_policy:0,
          iv_load_policy:3,playsinline:1,rel:0,modestbranding:1,origin:'https://www.youtube.com'},
        events:{
          onReady:function(e){e.target.playVideo();say('ready');},
          onStateChange:function(e){if(e.data===1){say('playing');}},
          onError:function(e){say('error:'+e.data);}
        }});
    }
    var t=document.createElement('script');t.src='https://www.youtube.com/iframe_api';
    t.onerror=function(){say('error:api');};document.head.appendChild(t);
    </script></body></html>
""".trimIndent()

/** Lets the page tell the app what is happening (playing / error code). */
internal class LiveBridge(private val onStatus: (String) -> Unit) {
    private val h = Handler(Looper.getMainLooper())
    @JavascriptInterface
    fun report(s: String) { h.post { onStatus(s) } }
}

private fun liveMessage(status: String, webView: String): String? {
    val why = when {
        status.startsWith("error:") -> when (val c = status.removePrefix("error:")) {
            "2" -> "This YouTube link is not valid."
            "5" -> "The video player failed on this TV."
            "100" -> "This video was not found or was removed."
            "101", "150" -> "The video owner does not allow playing it outside YouTube."
            "153" -> "YouTube refused the player (error 153)."
            "api" -> "Could not reach YouTube. Check the internet."
            "media" -> "This stream could not be played."
            else -> "Stream error: $c"
        }
        status.startsWith("net:") -> "Cannot load the stream: " + status.removePrefix("net:")
        status == "timeout" -> "The stream did not start."
        else -> null
    } ?: return null
    return "$why\nCheck the link in Launcher Settings.\nWebView $webView"
}

private fun isMediaFile(u: String): Boolean {
    val path = u.substringBefore('?').lowercase()
    return path.endsWith(".m3u8") || path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".ts")
}

private fun loadLive(wv: WebView, raw: String, muted: Boolean, client: AdBlockClient) {
    val url = raw.trim()
    val yt = youTubeSrc(url, muted)
    when {
        youTubeVideoId(url) != null -> {
            client.strict = true
            client.generic = false
            // Base URL youtube.com: the player sees a normal YouTube page (avoids "error 153").
            wv.loadDataWithBaseURL("https://www.youtube.com/", ytApiHtml(youTubeVideoId(url)!!, muted), "text/html", "utf-8", null)
        }
        yt != null -> {
            client.strict = true
            client.generic = false
            val html = """
                <html><body style="margin:0;background:#000;overflow:hidden">
                <iframe style="border:0;pointer-events:none;position:absolute;top:0;left:0;width:100%;height:100%"
                  allow="autoplay; encrypted-media" src="$yt"></iframe></body></html>
            """.trimIndent()
            wv.loadDataWithBaseURL("https://www.youtube.com/", html, "text/html", "utf-8", null)
        }
        isMediaFile(url) -> {
            client.strict = true
            client.generic = false
            val safe = url.replace("\"", "%22")
            val html = """
                <html><body style="margin:0;background:#000;overflow:hidden">
                <video src="$safe" autoplay ${if (muted) "muted" else ""} loop playsinline
                  onplaying="try{window.TvHome.report('playing')}catch(e){}"
                  onerror="try{window.TvHome.report('error:media')}catch(e){}"
                  style="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:contain"></video>
                </body></html>
            """.trimIndent()
            wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "utf-8", null)
        }
        else -> {
            client.strict = false
            client.generic = true
            wv.loadUrl(if (url.startsWith("http")) url else "https://$url")
        }
    }
}

@Composable
private fun LivePreview(links: List<String>, intervalMin: Int, muted: Boolean, refreshKey: Int) {
    val ctx = LocalContext.current
    val clean = links.map { it.trim() }.filter { it.isNotEmpty() }
    var index by remember { mutableIntStateOf(0) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var reloadTick by remember { mutableIntStateOf(0) }
    val status = remember { mutableStateOf("") }
    val adScript = remember { arrayOfNulls<ScriptHandler>(1) }
    val mutedNow by rememberUpdatedState(muted)
    val client = remember { AdBlockClient { mutedNow }.also { c -> c.onProblem = { status.value = it } } }
    val webViewName = remember {
        runCatching { WebViewCompat.getCurrentWebViewPackage(ctx)?.versionName }.getOrNull() ?: "unknown"
    }

    // 1 link: always that one. 2+ links: intervalMin minutes each, then the next (playlist).
    LaunchedEffect(clean, refreshKey, intervalMin) {
        index = 0
        if (clean.size > 1) {
            while (true) {
                delay(intervalMin.coerceAtLeast(1) * 60_000L)
                index = (index + 1) % clean.size
            }
        }
    }
    // Keep media muted (if enabled) and fitted (covers generic web pages with their own <video>).
    LaunchedEffect(webView, muted) {
        while (true) {
            webView?.evaluateJavascript(mediaJs(muted) + if (client.generic) AdBlock.GENERIC_JS else "", null)
            delay(2000)
        }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { webView?.onPause() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { webView?.onResume() }

    if (clean.isEmpty()) return
    val url = clean[index % clean.size]

    // A YouTube video that has not started after 30 s: first retry once without the ad-block
    // script (it can upset some player versions), then say that it did not start.
    LaunchedEffect(url, refreshKey, reloadTick) {
        status.value = ""
        if (youTubeVideoId(url) == null) return@LaunchedEffect
        delay(30_000)
        val s = status.value
        if (s != "playing" && !s.startsWith("error:") && !s.startsWith("net:")) {
            val h = adScript[0]
            if (h != null) {
                runCatching { h.remove() }
                adScript[0] = null
                reloadTick++
            } else {
                status.value = "timeout"
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                WebView(c).apply {
                    // Not selectable: the tile never takes focus or clicks.
                    isFocusable = false
                    isFocusableInTouchMode = false
                    isClickable = false
                    setOnTouchListener { _, _ -> true }
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    // No pop-up windows: ads cannot open new pages.
                    settings.setSupportMultipleWindows(false)
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    // Generic web pages: shrink the page to fit the tile instead of cropping it.
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    addJavascriptInterface(LiveBridge { status.value = it }, "TvHome")
                    adScript[0] = AdBlock.install(this)
                    webViewClient = client
                }
            },
            update = { w ->
                if (webView !== w) webView = w
                val key = "$url|$refreshKey|$muted|$reloadTick"
                if (w.tag != key) {
                    w.tag = key
                    loadLive(w, url, muted, client)
                }
            },
            onRelease = { it.destroy() },
        )
        val msg = liveMessage(status.value, webViewName)
        if (msg != null) {
            Box(Modifier.fillMaxSize().background(Color(0xCC000000)), contentAlignment = Alignment.Center) {
                Text(
                    msg, color = Color.White, fontSize = 17.us(), textAlign = TextAlign.Center,
                    modifier = Modifier.padding(14.u()),
                )
            }
        }
    }
}
