@file:OptIn(ExperimentalFoundationApi::class)

package com.raiabrar.tvhome

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AcUnit
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Thunderstorm
import androidx.compose.material.icons.outlined.UnfoldMore
import androidx.compose.material.icons.outlined.Umbrella
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---- Edit these for your location (used for the weather widget) -------------
private const val LATITUDE = 24.8607    // Karachi
private const val LONGITUDE = 67.0011
// -----------------------------------------------------------------------------

class MainActivity : ComponentActivity() {
    private val newIntentTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HomeScreen(newIntentTick.intValue) }
    }

    // Pressing HOME while the launcher is already open.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        newIntentTick.intValue++
    }
}

private fun launchPackage(ctx: Context, vararg packages: String): Boolean {
    for (p in packages) {
        val i = ctx.packageManager.getLeanbackLaunchIntentForPackage(p)
            ?: ctx.packageManager.getLaunchIntentForPackage(p)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            return true
        }
    }
    return false
}

/** All launchable apps, user order, hidden set. Persisted in SharedPreferences. */
private class AppsModel(ctx: Context) {
    private val pm = ctx.packageManager
    private val self = ctx.packageName
    val prefs = Prefs(ctx)

    var labels by mutableStateOf<Map<String, String>>(emptyMap())
    val order = mutableStateListOf<String>()
    var hidden by mutableStateOf(prefs.hidden)
    var locked by mutableStateOf(prefs.locked)
    var names by mutableStateOf(prefs.names)
    var pin by mutableStateOf(prefs.pin)

    init { refresh() }

    val visible: List<String> get() = order.filter { it !in hidden }

    fun refresh() {
        val found = LinkedHashMap<String, String>()
        for (category in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(q, PackageManager.MATCH_ALL)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == self || pkg in found) continue
                found[pkg] = ri.loadLabel(pm).toString()
            }
        }
        val saved = prefs.order.filter { it in found }
        val fresh = found.keys.filter { it !in saved }.sortedBy { found[it]!!.lowercase() }
        labels = found
        order.clear()
        order.addAll(saved + fresh)
        prefs.order = order.toList()
        hidden = prefs.hidden
        locked = prefs.locked
        names = prefs.names
        pin = prefs.pin
    }

    /** Custom name if the user renamed the app, else its own label. */
    fun displayName(pkg: String): String = names[pkg]?.takeIf { it.isNotBlank() } ?: labels[pkg] ?: pkg

    fun rename(pkg: String, name: String) {
        val n = name.trim()
        names = if (n.isEmpty() || n == labels[pkg]) names - pkg else names + (pkg to n)
        prefs.names = names
    }

    fun lock(pkg: String) { locked = locked + pkg; prefs.locked = locked }
    fun unlock(pkg: String) { locked = locked - pkg; prefs.locked = locked }
    fun setPin(v: String) { pin = v; prefs.pin = v }

    /** Swap with the nearest visible neighbour up (-1) or down (+1). */
    fun move(pkg: String, delta: Int): Boolean {
        val i = order.indexOf(pkg)
        if (i < 0) return false
        var j = i + delta
        while (j in order.indices && order[j] in hidden) j += delta
        if (j !in order.indices) return false
        val t = order[i]
        order[i] = order[j]
        order[j] = t
        prefs.order = order.toList()
        return true
    }

    fun hide(pkg: String) { hidden = hidden + pkg; prefs.hidden = hidden }
    fun unhide(pkg: String) { hidden = hidden - pkg; prefs.hidden = hidden }

    fun resetOrder() {
        val sorted = order.sortedBy { displayName(it).lowercase() }
        order.clear()
        order.addAll(sorted)
        prefs.order = order.toList()
    }
}

private data class FocusTarget(val pkg: String, val n: Long)

/** PIN box open on an app row: to launch it, or (unlock = true) to remove its lock. */
private data class PinReq(val pkg: String, val unlock: Boolean)

@Composable
private fun HomeScreen(newIntentTick: Int) {
    val ctx = LocalContext.current
    val model = remember { AppsModel(ctx.applicationContext) }
    var links by remember { mutableStateOf(model.prefs.links()) }
    var intervalMin by remember { mutableIntStateOf(model.prefs.intervalMin) }
    var muted by remember { mutableStateOf(model.prefs.muted) }
    var wakeTick by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }

    // Back in the launcher (resume) = refresh apps, weather, stream, focus first app.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        model.refresh()
        wakeTick++
    }
    // TV / screen switched ON (or screensaver ended).
    DisposableEffect(ctx) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { wakeTick++ }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction("android.intent.action.DREAMING_STOPPED")
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { runCatching { ctx.unregisterReceiver(receiver) } }
    }
    BackHandler(enabled = showSettings) { showSettings = false }

    BoxWithConstraints(Modifier.fillMaxSize().background(BgColor)) {
        val scale = minOf(maxWidth.value / REF_W, maxHeight.value / REF_H)
        CompositionLocalProvider(LocalScale provides scale) {
            if (showSettings) {
                LauncherSettings(
                    links = links,
                    onLinks = { v ->
                        model.prefs.setLinks(v)
                        links = v.map { it.trim() }.filter { it.isNotEmpty() }
                    },
                    intervalMin = intervalMin,
                    onIntervalMin = { intervalMin = it; model.prefs.intervalMin = it },
                    muted = muted,
                    onMuted = { muted = it; model.prefs.muted = it },
                    pin = model.pin,
                    onPin = { model.setPin(it) },
                    hiddenApps = model.hidden
                        .mapNotNull { p -> model.labels[p]?.let { p to model.displayName(p) } }
                        .sortedBy { it.second.lowercase() },
                    onUnhide = { model.unhide(it) },
                    onResetOrder = { model.resetOrder() },
                    onClose = { showSettings = false },
                )
            } else {
                Home(
                    model = model,
                    links = links,
                    intervalMin = intervalMin,
                    muted = muted,
                    wakeTick = wakeTick,
                    focusKey = wakeTick + newIntentTick,
                    onSettings = { showSettings = true },
                )
            }
        }
    }
}

@Composable
private fun Home(
    model: AppsModel,
    links: List<String>,
    intervalMin: Int,
    muted: Boolean,
    wakeTick: Int,
    focusKey: Int,
    onSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    val apps = model.visible
    val listState = rememberLazyListState()
    val requesters = remember { HashMap<String, FocusRequester>() }
    var focusTarget by remember { mutableStateOf<FocusTarget?>(null) }
    var menuPkg by remember { mutableStateOf<String?>(null) }
    var movingPkg by remember { mutableStateOf<String?>(null) }
    var moveTick by remember { mutableIntStateOf(0) }
    var pinReq by remember { mutableStateOf<PinReq?>(null) }
    var renamePkg by remember { mutableStateOf<String?>(null) }
    var iconPkg by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = movingPkg != null) { movingPkg = null }
    BackHandler(enabled = pinReq != null) {
        pinReq?.let { focusTarget = FocusTarget(it.pkg, System.nanoTime()) }
        pinReq = null
    }

    // TV on / back home: scroll to top and highlight the first app.
    LaunchedEffect(focusKey) {
        movingPkg = null
        listState.scrollToItem(0)
        model.visible.firstOrNull()?.let { focusTarget = FocusTarget(it, System.nanoTime()) }
    }

    // While moving: keep the moved app on screen and focused.
    LaunchedEffect(moveTick) {
        val p = movingPkg ?: return@LaunchedEffect
        val idx = model.visible.indexOf(p)
        if (idx < 0) return@LaunchedEffect
        val vis = listState.layoutInfo.visibleItemsInfo
        if (vis.isNotEmpty()) {
            val first = vis.first().index
            val last = vis.last().index
            if (idx <= first) listState.scrollToItem((idx - 1).coerceAtLeast(0))
            else if (idx >= last) listState.scrollToItem((idx - (last - first) + 1).coerceAtLeast(0))
        }
        delay(40)
        runCatching { requesters[p]?.requestFocus() }
    }

    Row(
        Modifier.fillMaxSize().padding(start = 27.u(), end = 26.u(), top = 20.u(), bottom = 22.u())
    ) {
        Column(Modifier.width(300.u()).fillMaxHeight()) {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(11.u()),
                contentPadding = PaddingValues(vertical = 3.u()),
            ) {
                items(apps, key = { it }) { pkg ->
                    val requester = requesters.getOrPut(pkg) { FocusRequester() }
                    AppRow(
                        pkg = pkg,
                        label = model.displayName(pkg),
                        requester = requester,
                        moving = movingPkg == pkg,
                        locked = pkg in model.locked,
                        pinEntry = pinReq?.pkg == pkg,
                        pin = model.pin,
                        focusTarget = focusTarget,
                        onFocusConsumed = { focusTarget = null },
                        onLaunch = {
                            if (pkg in model.locked && model.pin.isNotEmpty()) pinReq = PinReq(pkg, false)
                            else launchPackage(ctx, pkg)
                        },
                        onPinOk = {
                            val r = pinReq
                            pinReq = null
                            if (r?.unlock == true) {
                                model.unlock(pkg)
                                focusTarget = FocusTarget(pkg, System.nanoTime())
                            } else {
                                launchPackage(ctx, pkg)
                            }
                        },
                        onPinCancel = {
                            if (pinReq?.pkg == pkg) {
                                pinReq = null
                                focusTarget = FocusTarget(pkg, System.nanoTime())
                            }
                        },
                        onMenu = { menuPkg = pkg },
                        onMove = { delta -> if (model.move(pkg, delta)) moveTick++ },
                        onDone = { movingPkg = null },
                    )
                }
            }
            Spacer(Modifier.height(8.u()))
            // Always-visible system status bar below the app list.
            StatsBar()
        }
        Spacer(Modifier.weight(1f))
        RightPane(links, intervalMin, muted, wakeTick)
    }

    menuPkg?.let { pkg ->
        val isLocked = pkg in model.locked
        fun back() { focusTarget = FocusTarget(pkg, System.nanoTime()) }
        AppMenu(
            title = model.displayName(pkg),
            locked = isLocked,
            onDismiss = { menuPkg = null; back() },
            onRename = { menuPkg = null; renamePkg = pkg },
            onIcon = { menuPkg = null; iconPkg = pkg },
            onLock = {
                menuPkg = null
                if (isLocked) {
                    pinReq = PinReq(pkg, true)
                } else if (model.pin.isEmpty()) {
                    Toast.makeText(ctx, "Set an app lock code in Launcher Settings first", Toast.LENGTH_LONG).show()
                    onSettings()
                } else {
                    model.lock(pkg)
                    back()
                }
            },
            onMove = { menuPkg = null; movingPkg = pkg },
            onHide = {
                val vis = model.visible
                val i = vis.indexOf(pkg)
                val next = vis.getOrNull(i + 1) ?: vis.getOrNull(i - 1)
                menuPkg = null
                model.hide(pkg)
                next?.let { focusTarget = FocusTarget(it, System.nanoTime()) }
            },
            // App details page: shows app info and the Uninstall / Disable buttons.
            onInfo = {
                menuPkg = null
                runCatching {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            },
            onSettings = { menuPkg = null; onSettings() },
        )
    }

    renamePkg?.let { pkg ->
        RenameDialog(
            current = model.names[pkg] ?: "",
            original = model.labels[pkg] ?: pkg,
            onSave = {
                model.rename(pkg, it)
                renamePkg = null
                focusTarget = FocusTarget(pkg, System.nanoTime())
            },
            onDismiss = { renamePkg = null; focusTarget = FocusTarget(pkg, System.nanoTime()) },
        )
    }
    iconPkg?.let { pkg ->
        ChangeIconDialog(
            pkg = pkg,
            label = model.displayName(pkg),
            onDismiss = { iconPkg = null; focusTarget = FocusTarget(pkg, System.nanoTime()) },
        )
    }
}

@Composable
private fun AppRow(
    pkg: String,
    label: String,
    requester: FocusRequester,
    moving: Boolean,
    locked: Boolean,
    pinEntry: Boolean,
    pin: String,
    focusTarget: FocusTarget?,
    onFocusConsumed: () -> Unit,
    onLaunch: () -> Unit,
    onPinOk: () -> Unit,
    onPinCancel: () -> Unit,
    onMenu: () -> Unit,
    onMove: (Int) -> Unit,
    onDone: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    // [0] = OK is held down, [1] = long press already fired
    val press = remember { booleanArrayOf(false, false) }
    val shape = RoundedCornerShape(13.u())

    LaunchedEffect(focusTarget) {
        val t = focusTarget
        if (t != null && t.pkg == pkg) {
            delay(100)
            runCatching { requester.requestFocus() }
            onFocusConsumed()
        }
    }
    LaunchedEffect(moving) {
        if (moving) {
            delay(120)
            runCatching { requester.requestFocus() }
        }
    }

    val highlighted = focused || moving || pinEntry
    Row(
        Modifier
            .fillMaxWidth()
            .height(77.u())
            .clip(shape)
            .background(if (highlighted) FocusFill else Color.Transparent)
            .border(2.u(), if (moving) TextPrimary else if (focused) FocusBorder else Color.Transparent, shape)
            .focusRequester(requester)
            .onFocusChanged { focused = it.isFocused }
            .onPreviewKeyEvent { ev ->
                val isOk = ev.key == Key.DirectionCenter || ev.key == Key.Enter || ev.key == Key.NumPadEnter
                if (pinEntry) {
                    // The PIN box owns the keyboard while it is open.
                    false
                } else if (moving) {
                    // MOVE mode: UP / DOWN carry the app through the list, OK finishes.
                    when (ev.key) {
                        Key.DirectionUp -> { if (ev.type == KeyEventType.KeyDown) onMove(-1); true }
                        Key.DirectionDown -> { if (ev.type == KeyEventType.KeyDown) onMove(1); true }
                        Key.DirectionLeft, Key.DirectionRight -> true
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                            if (ev.type == KeyEventType.KeyUp) onDone()
                            true
                        }
                        else -> false
                    }
                } else if (!isOk) {
                    false
                } else {
                    when (ev.type) {
                        KeyEventType.KeyDown -> {
                            if (ev.nativeKeyEvent.repeatCount == 0) {
                                press[0] = true
                                press[1] = false
                            } else if (press[0] && !press[1]) {
                                // OK held down: long press -> open menu.
                                press[1] = true
                                onMenu()
                            }
                            true
                        }
                        KeyEventType.KeyUp -> {
                            if (press[0] && !press[1]) onLaunch()
                            press[0] = false
                            press[1] = false
                            true
                        }
                        else -> false
                    }
                }
            }
            // Touch / mouse still works.
            .combinedClickable(enabled = !pinEntry, onClick = onLaunch, onLongClick = onMenu)
            .padding(start = 19.5f.u(), end = 12.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(pkg, 50.u())
        if (highlighted) {
            Spacer(Modifier.width(16.u()))
            if (pinEntry) {
                // PIN box takes the place of the app name, same height as the icon.
                PinBox(pin = pin, onOk = onPinOk, onCancel = onPinCancel, modifier = Modifier.weight(1f))
            } else {
                // Fixed line height + trimmed padding = name is vertically centered on the icon.
                Text(
                    label, color = TextPrimary, fontSize = 27.us(), fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = TextStyle(lineHeight = 34.us(), lineHeightStyle = MidLine),
                    modifier = Modifier.weight(1f),
                )
                if (locked) {
                    Icon(Icons.Outlined.Lock, null, tint = TextDim, modifier = Modifier.size(26.u()))
                }
            }
            if (moving) {
                Icon(Icons.Outlined.UnfoldMore, null, tint = TextPrimary, modifier = Modifier.size(30.u()))
            }
        }
    }
}

@Composable
private fun AppMenu(
    title: String,
    locked: Boolean,
    onDismiss: () -> Unit,
    onRename: () -> Unit,
    onIcon: () -> Unit,
    onLock: () -> Unit,
    onMove: () -> Unit,
    onHide: () -> Unit,
    onInfo: () -> Unit,
    onSettings: () -> Unit,
) {
    val first = remember { FocusRequester() }
    val opened = remember { System.currentTimeMillis() }
    val armed = remember { booleanArrayOf(false) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        LaunchedEffect(Unit) {
            delay(60)
            runCatching { first.requestFocus() }
        }
        val shape = RoundedCornerShape(16.u())
        Column(
            Modifier
                // Swallow the still-held OK press that opened this menu so it can't
                // accidentally select the first item when released.
                .onPreviewKeyEvent { ev ->
                    val isOk = ev.key == Key.DirectionCenter || ev.key == Key.Enter || ev.key == Key.NumPadEnter
                    if (!isOk) {
                        false
                    } else {
                        if (!armed[0] && System.currentTimeMillis() - opened > 800) armed[0] = true
                        if (armed[0]) {
                            false
                        } else {
                            if (ev.type == KeyEventType.KeyUp) armed[0] = true
                            true
                        }
                    }
                }
                .width(340.u())
                .clip(shape)
                .background(Color(0xFF1B1E24))
                .border(2.u(), FocusBorder, shape)
                .padding(14.u()),
            verticalArrangement = Arrangement.spacedBy(6.u()),
        ) {
            Text(
                title, color = TextDim, fontSize = 22.us(), maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 18.u(), top = 4.u(), bottom = 6.u()),
            )
            MenuItem("Rename", Modifier.focusRequester(first), onRename)
            MenuItem("Change Icon", Modifier, onIcon)
            MenuItem(if (locked) "Unlock" else "Lock", Modifier, onLock)
            MenuItem("Move", Modifier, onMove)
            MenuItem("Hide", Modifier, onHide)
            MenuItem("Info / Uninstall", Modifier, onInfo)
            MenuItem("Launcher Settings", Modifier, onSettings)
        }
    }
}

@Composable
private fun MenuItem(text: String, modifier: Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Box(
        modifier
            .fillMaxWidth()
            .height(52.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color.Transparent)
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 18.u()),
        contentAlignment = Alignment.CenterStart,
    ) {
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
        )
    }
}

@Composable
private fun RightPane(links: List<String>, intervalMin: Int, muted: Boolean, wakeTick: Int) {
    // Top to bottom: clock slot, weather/date centered in the space left between the
    // clock and the stream, then the 16:9 stream pinned to the bottom. Fixed-height
    // pieces mean the stream can never overlap the temperature or day name.
    Column(Modifier.width(540.u()).fillMaxHeight()) {
        Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            // Fixed-height slot for the clock; the (taller) text line box may extend
            // past it without changing the layout, and is pulled up so the digits'
            // top edge lines up with the top of the first app row.
            Box(Modifier.fillMaxWidth().height(122.u()), contentAlignment = Alignment.TopCenter) {
                Box(Modifier.wrapContentHeight(Alignment.Top, unbounded = true).offset(y = (-19).u())) {
                    ClockBlock()
                }
            }
            // Extra top padding pushes the weather/date block away from the clock digits.
            Box(Modifier.fillMaxWidth().weight(1f).padding(top = 36.u()), contentAlignment = Alignment.Center) {
                WeatherDateBlock(wakeTick)
            }
        }
        Spacer(Modifier.height(14.u()))
        LiveCard(links, intervalMin, muted, wakeTick, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
    }
}

@Composable
private fun ClockBlock() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000)
        }
    }
    val time = SimpleDateFormat("h:mm", Locale.getDefault()).format(now)
    val ampm = SimpleDateFormat("a", Locale.ENGLISH).format(now).uppercase(Locale.ENGLISH)
    Row(horizontalArrangement = Arrangement.Center) {
        Text(
            time, color = TextPrimary, fontSize = 144.us(), fontWeight = FontWeight.Medium,
            letterSpacing = (-5).us(), maxLines = 1, softWrap = false,
            style = TextStyle(lineHeight = 144.us(), lineHeightStyle = CenterLine),
            modifier = Modifier.alignByBaseline(),
        )
        Spacer(Modifier.width(16.u()))
        Text(
            ampm, color = TextPrimary, fontSize = 36.us(), maxLines = 1,
            style = TextStyle(lineHeight = 36.us(), lineHeightStyle = CenterLine),
            modifier = Modifier.alignByBaseline(),
        )
    }
}

private data class Weather(val tempC: Int, val code: Int)

private suspend fun fetchWeather(): Weather? = withContext(Dispatchers.IO) {
    runCatching {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$LATITUDE&longitude=$LONGITUDE" +
                "&current=temperature_2m,weather_code"
        )
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val cur = JSONObject(body).getJSONObject("current")
            Weather(Math.round(cur.getDouble("temperature_2m")).toInt(), cur.getInt("weather_code"))
        } finally {
            c.disconnect()
        }
    }.getOrNull()
}

private fun weatherIcon(code: Int): ImageVector = when (code) {
    0 -> Icons.Outlined.WbSunny
    in 51..67, in 80..82 -> Icons.Outlined.Umbrella
    in 71..77, 85, 86 -> Icons.Outlined.AcUnit
    in 95..99 -> Icons.Outlined.Thunderstorm
    else -> Icons.Outlined.Cloud
}

@Composable
private fun WeatherDateBlock(refreshKey: Int) {
    var weather by remember { mutableStateOf<Weather?>(null) }
    var now by remember { mutableStateOf(Date()) }
    // Refresh whenever the TV turns on / launcher resumes, then every 15 minutes.
    // If the network isn't up yet right after power-on, retry every 10 seconds.
    LaunchedEffect(refreshKey) {
        while (true) {
            val w = fetchWeather()
            if (w != null) {
                weather = w
                delay(15 * 60 * 1000L)
            } else {
                delay(10_000L)
            }
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(30_000)
        }
    }
    val date = SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH).format(now)
    val day = SimpleDateFormat("EEEE", Locale.ENGLISH).format(now)

    Row(Modifier.height(76.u()), verticalAlignment = Alignment.CenterVertically) {
        Column(
            Modifier.width(100.u()).fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(weatherIcon(weather?.code ?: 3), null, tint = TextPrimary, modifier = Modifier.size(40.u()))
            Text(
                "${weather?.tempC?.toString() ?: "--"}°c", color = TextPrimary, fontSize = 34.us(),
                fontWeight = FontWeight.Medium, maxLines = 1,
                style = TextStyle(lineHeight = 36.us(), lineHeightStyle = CenterLine),
            )
        }
        Spacer(Modifier.width(25.u()))
        Box(Modifier.width(2.u()).height(76.u()).background(LineColor))
        Spacer(Modifier.width(25.u()))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                date, color = DateColor, fontSize = 28.us(), maxLines = 1,
                style = TextStyle(lineHeight = 38.us(), lineHeightStyle = CenterLine),
            )
            Text(
                day, color = DateColor, fontSize = 28.us(), maxLines = 1,
                style = TextStyle(lineHeight = 38.us(), lineHeightStyle = CenterLine),
            )
        }
    }
}

/** Live preview tile: not focusable and not clickable. Muted unless turned off in settings. */
@Composable
private fun LiveCard(
    links: List<String>, intervalMin: Int, muted: Boolean, refreshKey: Int, modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(12.u())
    Box(
        modifier
            .clip(shape)
            .background(ThumbColor)
            // Border is drawn over the content, so the stream area stays exactly 16:9.
            .border(2.u(), LineColor, shape)
    ) {
        LivePreview(links, intervalMin, muted, refreshKey)
    }
}

private const val LIVE_PAGE = "https://live.geo.tv/"
private fun ytParams(muted: Boolean) =
    "autoplay=1&mute=${if (muted) 1 else 0}&controls=0&fs=0&disablekb=1&cc_load_policy=0&iv_load_policy=3&playsinline=1&rel=0&modestbranding=1"

// Videos on any page: always "contain" (whole picture visible, no crop); muted when asked.
private fun mediaJs(muted: Boolean): String =
    (if (muted) "document.querySelectorAll('video,audio').forEach(function(v){v.muted=true;v.volume=0;});" else "") +
        "document.querySelectorAll('video').forEach(function(v){v.style.objectFit='contain';});"

private fun youTubeSrc(u: String, muted: Boolean): String? {
    val params = ytParams(muted)
    Regex("""(?:youtu\.be/|youtube(?:-nocookie)?\.com/(?:watch\?(?:[^#]*&)?v=|embed/|live/|shorts/|v/))([A-Za-z0-9_-]{11})""")
        .find(u)?.let { return "https://www.youtube.com/embed/${it.groupValues[1]}?$params" }
    Regex("""youtube\.com/channel/(UC[A-Za-z0-9_-]{22})""")
        .find(u)?.let { return "https://www.youtube.com/embed/live_stream?channel=${it.groupValues[1]}&$params" }
    if (Regex("^[A-Za-z0-9_-]{11}$").matches(u)) return "https://www.youtube.com/embed/$u?$params"
    return null
}

private fun isMediaFile(u: String): Boolean {
    val path = u.substringBefore('?').lowercase()
    return path.endsWith(".m3u8") || path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".ts")
}

private fun loadLive(wv: WebView, raw: String, muted: Boolean) {
    val url = raw.trim()
    val yt = youTubeSrc(url, muted)
    when {
        yt != null -> {
            // Best fit: the largest 16:9 frame that fits inside the tile, centered, never cropped.
            val html = """
                <html><body style="margin:0;background:#000;overflow:hidden">
                <div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center">
                <iframe style="border:0;pointer-events:none;
                  width:min(100vw,calc(100vh*1.7778));height:min(100vh,calc(100vw*0.5625))"
                  allow="autoplay; encrypted-media" src="$yt">
                </iframe></div></body></html>
            """.trimIndent()
            wv.loadDataWithBaseURL(LIVE_PAGE, html, "text/html", "utf-8", null)
        }
        isMediaFile(url) -> {
            val safe = url.replace("\"", "%22")
            val html = """
                <html><body style="margin:0;background:#000;overflow:hidden">
                <video src="$safe" autoplay ${if (muted) "muted" else ""} loop playsinline
                  style="position:fixed;inset:0;width:100%;height:100%;object-fit:contain"></video>
                </body></html>
            """.trimIndent()
            wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "utf-8", null)
        }
        else -> wv.loadUrl(if (url.startsWith("http")) url else "https://$url")
    }
}

@Composable
private fun LivePreview(links: List<String>, intervalMin: Int, muted: Boolean, refreshKey: Int) {
    val clean = links.map { it.trim() }.filter { it.isNotEmpty() }
    var index by remember { mutableIntStateOf(0) }
    var webView by remember { mutableStateOf<WebView?>(null) }

    // 1 link: always that one. 2+ links: intervalMin minutes each, then the next (playlist).
    LaunchedEffect(clean, refreshKey, intervalMin) {
        index = 0
        if (clean.size > 1) {
            while (true) {
                delay(intervalMin.coerceAtLeast(1) * 60_000L)
                index = (index + 1) % clean.size
            }
        }
    }
    // Keep media muted (if enabled) and fitted (covers generic web pages with their own <video>).
    LaunchedEffect(webView, muted) {
        while (true) {
            webView?.evaluateJavascript(mediaJs(muted), null)
            delay(2000)
        }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { webView?.onPause() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { webView?.onResume() }

    if (clean.isEmpty()) return
    val url = clean[index % clean.size]

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            WebView(c).apply {
                // Not selectable: the tile never takes focus or clicks.
                isFocusable = false
                isFocusableInTouchMode = false
                isClickable = false
                setOnTouchListener { _, _ -> true }
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                // Generic web pages: shrink the page to fit the tile instead of cropping it.
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        view?.evaluateJavascript(mediaJs(muted), null)
                    }
                }
            }
        },
        update = { w ->
            if (webView !== w) webView = w
            val key = "$url|$refreshKey|$muted"
            if (w.tag != key) {
                w.tag = key
                loadLive(w, url, muted)
            }
        },
        onRelease = { it.destroy() },
    )
}
