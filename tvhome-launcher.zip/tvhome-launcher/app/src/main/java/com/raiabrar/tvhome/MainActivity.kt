@file:OptIn(ExperimentalFoundationApi::class)

package com.raiabrar.tvhome

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.UnfoldMore
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableLongState
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val newIntentTick = mutableIntStateOf(0)
    private val saverActive = mutableStateOf(false)
    private val lastInput = mutableLongStateOf(0L)
    private val remoteReq = mutableStateOf<RemoteReq?>(null)
    private val prefs by lazy { Prefs(this) }
    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lastInput.longValue = SystemClock.elapsedRealtime()
        DriveSync.init(applicationContext)
        askForWifiNamePermission()
        setContent { HomeScreen(newIntentTick.intValue, saverActive, lastInput, remoteReq.value) }
    }

    // Pressing HOME while the launcher is already open.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        newIntentTick.intValue++
    }

    // Any remote key counts as activity; while the screensaver plays, the key only closes it.
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        lastInput.longValue = SystemClock.elapsedRealtime()
        if (saverActive.value) {
            if (event.action == KeyEvent.ACTION_DOWN) saverActive.value = false
            return true
        }
        // Settings > Remote buttons: "press a button" takes the next key press.
        RemoteKeys.capture?.let { capture ->
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) capture(event)
            return true
        }
        // A remote button with an assigned action runs it (the up event is swallowed too).
        if (event.keyCode !in RemoteKeys.PROTECTED) {
            val action = RemoteKeys.actionFor(prefs, event)
            if (action != null) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    remoteReq.value = RemoteReq(action, System.nanoTime())
                }
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        lastInput.longValue = SystemClock.elapsedRealtime()
        if (saverActive.value) {
            if (ev.action == MotionEvent.ACTION_DOWN) saverActive.value = false
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    // Android only reveals the Wi-Fi network name to apps that have the location permission.
    private fun askForWifiNamePermission() {
        val prefs = Prefs(this)
        if (prefs.askedLocation) return
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) return
        prefs.askedLocation = true
        runCatching { locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
    }
}

private fun launchPackage(ctx: Context, vararg packages: String): Boolean {
    for (p in packages) {
        val i = ctx.packageManager.getLeanbackLaunchIntentForPackage(p)
            ?: ctx.packageManager.getLaunchIntentForPackage(p)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            return true
        }
    }
    return false
}

private data class FocusTarget(val pkg: String, val n: Long)

/** PIN box open on an app row: to launch it, or (unlock = true) to remove its lock. */
private data class PinReq(val pkg: String, val unlock: Boolean)

@Composable
private fun HomeScreen(
    newIntentTick: Int,
    saverActive: MutableState<Boolean>,
    lastInput: MutableLongState,
    remoteReq: RemoteReq?,
) {
    val ctx = LocalContext.current
    val model = remember { AppsModel(ctx.applicationContext) }
    val prefs = model.prefs
    var links by remember { mutableStateOf(prefs.links()) }
    var intervalMin by remember { mutableIntStateOf(prefs.intervalMin) }
    var muted by remember { mutableStateOf(prefs.muted) }
    var wallMode by remember { mutableStateOf(prefs.wallMode) }
    var blurPct by remember { mutableIntStateOf(prefs.blurPct) }
    var saverType by remember { mutableStateOf(prefs.saverType) }
    var saverMin by remember { mutableIntStateOf(prefs.saverMin) }
    var wakeTick by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var settingsPage by remember { mutableStateOf(SettingsPage.Main) }
    var dialogOpen by remember { mutableStateOf(false) }
    val weather = rememberWeather(wakeTick)

    // Back in the launcher (resume) = refresh apps, weather, stream, focus first app.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        model.refresh()
        wakeTick++
        saverActive.value = false
        lastInput.longValue = SystemClock.elapsedRealtime()
    }
    // TV / screen switched ON (or screensaver ended).
    DisposableEffect(ctx) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { wakeTick++ }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction("android.intent.action.DREAMING_STOPPED")
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { runCatching { ctx.unregisterReceiver(receiver) } }
    }
    BackHandler(enabled = showSettings) {
        if (settingsPage != SettingsPage.Main) settingsPage = SettingsPage.Main else showSettings = false
    }

    // Screensaver: starts on the home screen after saverMin minutes without any remote input.
    val idleAllowed = saverType != "off" && !showSettings && !dialogOpen && !saverActive.value
    LaunchedEffect(idleAllowed, saverMin) {
        if (!idleAllowed) return@LaunchedEffect
        while (true) {
            delay(1000)
            if (SystemClock.elapsedRealtime() - lastInput.longValue >= saverMin * 60_000L) {
                saverActive.value = true
                break
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(BgColor)) {
        val scale = minOf(maxWidth.value / REF_W, maxHeight.value / REF_H)
        CompositionLocalProvider(LocalScale provides scale) {
            if (showSettings) {
                LauncherSettings(
                    page = settingsPage,
                    onPage = { settingsPage = it },
                    host = model,
                    prefs = prefs,
                    links = links,
                    onLinks = { v ->
                        prefs.setLinks(v)
                        links = v.map { it.trim() }.filter { it.isNotEmpty() }
                    },
                    intervalMin = intervalMin,
                    onIntervalMin = { intervalMin = it; prefs.intervalMin = it },
                    muted = muted,
                    onMuted = { muted = it; prefs.muted = it },
                    wallMode = wallMode,
                    onWallMode = { wallMode = it; prefs.wallMode = it },
                    blurPct = blurPct,
                    onBlurPct = { blurPct = it; prefs.blurPct = it },
                    saverType = saverType,
                    onSaverType = { saverType = it; prefs.saverType = it },
                    saverMin = saverMin,
                    onSaverMin = { saverMin = it; prefs.saverMin = it },
                    onPreviewSaver = { saverActive.value = true },
                    onClose = { showSettings = false },
                )
            } else {
                // Wallpaper behind everything on the home screen; it follows the current weather.
                WallpaperLayer(wallCond(weather), wallMode, blurPct, Modifier.fillMaxSize())
                Home(
                    model = model,
                    links = links,
                    intervalMin = intervalMin,
                    muted = muted,
                    weather = weather,
                    wakeTick = wakeTick,
                    focusKey = wakeTick + newIntentTick,
                    onDialogOpen = { dialogOpen = it },
                    onSettings = { settingsPage = SettingsPage.Main; showSettings = true },
                    remoteReq = remoteReq,
                    onSaver = { saverActive.value = true },
                )
            }
            if (saverActive.value) {
                Screensaver(if (saverType == "off") "clock" else saverType)
            }
        }
    }
}

@Composable
private fun Home(
    model: AppsModel,
    links: List<String>,
    intervalMin: Int,
    muted: Boolean,
    weather: Weather?,
    wakeTick: Int,
    focusKey: Int,
    onDialogOpen: (Boolean) -> Unit,
    onSettings: () -> Unit,
    remoteReq: RemoteReq?,
    onSaver: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val apps = model.visible
    val listState = rememberLazyListState()
    val requesters = remember { HashMap<String, FocusRequester>() }
    var focusTarget by remember { mutableStateOf<FocusTarget?>(null) }
    var menuPkg by remember { mutableStateOf<String?>(null) }
    var movingPkg by remember { mutableStateOf<String?>(null) }
    var moveTick by remember { mutableIntStateOf(0) }
    var pinReq by remember { mutableStateOf<PinReq?>(null) }
    var renamePkg by remember { mutableStateOf<String?>(null) }
    var iconPkg by remember { mutableStateOf<String?>(null) }
    var quickVisible by remember { mutableStateOf(false) }   // quick menu list shown beside the app list
    var quickFocused by remember { mutableStateOf(false) }   // the highlighter is in the quick menu
    var quickTick by remember { mutableIntStateOf(0) }
    var inputDialog by remember { mutableStateOf(false) }
    val net = rememberNetState()
    var lastPkg by remember { mutableStateOf<String?>(null) }

    // Tell the screensaver timer when a dialog is on screen (it must not start then).
    SideEffect {
        onDialogOpen(
            menuPkg != null || renamePkg != null || iconPkg != null || pinReq != null || inputDialog
        )
    }

    // Highlighter back to the app list (the quick menu stays beside it, icons only).
    fun focusApps() {
        val p = lastPkg ?: model.visible.firstOrNull()
        if (p != null) focusTarget = FocusTarget(p, System.nanoTime())
    }
    // Hide the quick menu: the app list goes back to its normal place.
    fun closeQuick() {
        quickVisible = false
        quickFocused = false
        focusApps()
    }

    fun runOptimize() {
        scope.launch {
            Toast.makeText(ctx, "Optimizing...", Toast.LENGTH_SHORT).show()
            val mb = optimizeMemory(ctx, model.labels.keys.toList())
            Toast.makeText(
                ctx,
                if (mb > 0) "Optimized: freed about $mb MB" else "Optimized: memory was already clean",
                Toast.LENGTH_LONG,
            ).show()
        }
    }

    BackHandler(enabled = movingPkg != null) { movingPkg = null }
    BackHandler(enabled = pinReq != null) {
        pinReq?.let { focusTarget = FocusTarget(it.pkg, System.nanoTime()) }
        pinReq = null
    }
    BackHandler(enabled = quickVisible && !inputDialog) { closeQuick() }

    // TV on / back home: scroll to top and highlight the first app.
    LaunchedEffect(focusKey) {
        movingPkg = null
        quickVisible = false
        quickFocused = false
        listState.scrollToItem(0)
        model.visible.firstOrNull()?.let { focusTarget = FocusTarget(it, System.nanoTime()) }
    }

    // A remote button with an assigned action (Settings > Remote buttons) was pressed.
    LaunchedEffect(remoteReq?.n) {
        val r = remoteReq ?: return@LaunchedEffect
        if (System.nanoTime() - r.n > 1_500_000_000L) return@LaunchedEffect   // old request, ignore
        movingPkg = null
        when {
            r.action == "launcher" -> onSettings()
            r.action == "quick" -> { quickVisible = true; quickFocused = true; quickTick++ }
            r.action == "input" -> inputDialog = true
            r.action == "system" -> openSystem(ctx, Settings.ACTION_SETTINGS)
            r.action == "wifi" -> openSystem(ctx, Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_SETTINGS)
            r.action == "bluetooth" -> openSystem(ctx, Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_SETTINGS)
            r.action == "allapps" -> openSystem(
                ctx, "android.settings.MANAGE_ALL_APPLICATIONS_SETTINGS",
                Settings.ACTION_APPLICATION_SETTINGS, Settings.ACTION_SETTINGS,
            )
            r.action == "optimize" -> runOptimize()
            r.action == "saver" -> onSaver()
            r.action == "first" -> {
                quickVisible = false
                quickFocused = false
                listState.scrollToItem(0)
                model.visible.firstOrNull()?.let { focusTarget = FocusTarget(it, System.nanoTime()) }
            }
            r.action.startsWith("app:") -> {
                val pkg = r.action.removePrefix("app:")
                val idx = model.visible.indexOf(pkg)
                if (pkg in model.locked && model.pin.isNotEmpty()) {
                    // Locked: the code is asked on the app's own row, so bring that row on screen.
                    if (idx >= 0) {
                        listState.scrollToItem(idx)
                        pinReq = PinReq(pkg, false)
                    } else {
                        Toast.makeText(ctx, "That app is locked and hidden", Toast.LENGTH_SHORT).show()
                    }
                } else if (!launchPackage(ctx, pkg)) {
                    Toast.makeText(ctx, "That app is not installed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // While moving: keep the moved app on screen and focused.
    LaunchedEffect(moveTick) {
        val p = movingPkg ?: return@LaunchedEffect
        val idx = model.visible.indexOf(p)
        if (idx < 0) return@LaunchedEffect
        val vis = listState.layoutInfo.visibleItemsInfo
        if (vis.isNotEmpty()) {
            val first = vis.first().index
            val last = vis.last().index
            if (idx <= first) listState.scrollToItem((idx - 1).coerceAtLeast(0))
            else if (idx >= last) listState.scrollToItem((idx - (last - first) + 1).coerceAtLeast(0))
        }
        delay(40)
        runCatching { requesters[p]?.requestFocus() }
    }

    Row(
        Modifier.fillMaxSize().padding(start = 27.u(), end = 26.u(), top = 20.u(), bottom = 22.u())
    ) {
        // Normal: the app list alone (300 wide). With the quick menu: two vertical lists side by side,
        // quick menu on one side, apps on the opposite side. The list holding the highlighter is wide
        // (icon + name), the other shows icons only, so the app icons never disappear.
        val leftW = if (quickVisible) 380f else 300f
        val quickW = if (quickFocused) leftW - ICON_COL else ICON_COL
        val appsW = if (!quickVisible) 300f else if (quickFocused) ICON_COL else leftW - ICON_COL
        Column(Modifier.width(leftW.u()).fillMaxHeight()) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                if (quickVisible) {
                    QuickMenu(
                        wifiLabel = if (net.connected) net.name else "Not connected",
                        focusTick = quickTick,
                        onAction = { a ->
                            when (a) {
                                QuickAction.OPTIMIZE -> runOptimize()
                                QuickAction.WIFI -> openSystem(ctx, Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_SETTINGS)
                                QuickAction.BLUETOOTH -> openSystem(ctx, Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_SETTINGS)
                                QuickAction.INPUT -> inputDialog = true
                                QuickAction.ALL_APPS -> openSystem(
                                    ctx, "android.settings.MANAGE_ALL_APPLICATIONS_SETTINGS",
                                    Settings.ACTION_APPLICATION_SETTINGS, Settings.ACTION_SETTINGS,
                                )
                                QuickAction.LAUNCHER -> { quickVisible = false; quickFocused = false; onSettings() }
                                QuickAction.SETTINGS -> openSystem(ctx, Settings.ACTION_SETTINGS)
                            }
                        },
                        onFocused = { quickFocused = true },
                        onRight = { focusApps() },
                        modifier = Modifier.width(quickW.u()).fillMaxHeight(),
                    )
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.width(appsW.u()).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(11.u()),
                    contentPadding = PaddingValues(vertical = 3.u()),
                ) {
                    items(apps, key = { it }) { pkg ->
                        val requester = requesters.getOrPut(pkg) { FocusRequester() }
                        AppRow(
                            pkg = pkg,
                            label = model.displayName(pkg),
                            requester = requester,
                            moving = movingPkg == pkg,
                            locked = pkg in model.locked,
                            pinEntry = pinReq?.pkg == pkg,
                            pin = model.pin,
                            focusTarget = focusTarget,
                            onFocusConsumed = { focusTarget = null },
                            onFocus = { lastPkg = pkg; quickFocused = false },
                            // Left: the highlighter moves to the quick menu (shown beside the apps).
                            onLeft = { quickVisible = true; quickFocused = true; quickTick++ },
                            onLaunch = {
                                if (pkg in model.locked && model.pin.isNotEmpty()) pinReq = PinReq(pkg, false)
                                else launchPackage(ctx, pkg)
                            },
                            onPinOk = {
                                val r = pinReq
                                pinReq = null
                                if (r?.unlock == true) {
                                    model.unlock(pkg)
                                    focusTarget = FocusTarget(pkg, System.nanoTime())
                                } else {
                                    launchPackage(ctx, pkg)
                                }
                            },
                            onPinCancel = {
                                if (pinReq?.pkg == pkg) {
                                    pinReq = null
                                    focusTarget = FocusTarget(pkg, System.nanoTime())
                                }
                            },
                            onMenu = { menuPkg = pkg },
                            onMove = { delta -> if (model.move(pkg, delta)) moveTick++ },
                            onDone = { movingPkg = null },
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.u()))
            // Always-visible system status bar below the app list.
            StatsBar()
        }
        Spacer(Modifier.weight(1f))
        RightPane(links, intervalMin, muted, weather, net, wakeTick)
    }

    menuPkg?.let { pkg ->
        val isLocked = pkg in model.locked
        fun back() { focusTarget = FocusTarget(pkg, System.nanoTime()) }
        AppMenu(
            locked = isLocked,
            onDismiss = { menuPkg = null; back() },
            onRename = { menuPkg = null; renamePkg = pkg },
            onIcon = { menuPkg = null; iconPkg = pkg },
            onLock = {
                menuPkg = null
                if (isLocked) {
                    pinReq = PinReq(pkg, true)
                } else if (model.pin.isEmpty()) {
                    Toast.makeText(ctx, "Set an app lock code in Launcher Settings > App Lock first", Toast.LENGTH_LONG).show()
                    onSettings()
                } else {
                    model.lock(pkg)
                    back()
                }
            },
            onMove = { menuPkg = null; movingPkg = pkg },
            onHide = {
                val vis = model.visible
                val i = vis.indexOf(pkg)
                val next = vis.getOrNull(i + 1) ?: vis.getOrNull(i - 1)
                menuPkg = null
                model.hide(pkg)
                next?.let { focusTarget = FocusTarget(it, System.nanoTime()) }
            },
            // App details page: shows app info and the Uninstall / Disable buttons.
            onInfo = {
                menuPkg = null
                runCatching {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            },
            onSettings = { menuPkg = null; onSettings() },
        )
    }

    renamePkg?.let { pkg ->
        RenameDialog(
            current = model.names[pkg] ?: "",
            original = model.labels[pkg] ?: pkg,
            onSave = {
                model.rename(pkg, it)
                renamePkg = null
                focusTarget = FocusTarget(pkg, System.nanoTime())
            },
            onDismiss = { renamePkg = null; focusTarget = FocusTarget(pkg, System.nanoTime()) },
        )
    }
    iconPkg?.let { pkg ->
        ChangeIconDialog(
            pkg = pkg,
            label = model.displayName(pkg),
            onDismiss = { iconPkg = null; focusTarget = FocusTarget(pkg, System.nanoTime()) },
        )
    }
    if (inputDialog) {
        InputSourceDialog(onDismiss = { inputDialog = false })
    }
}

@Composable
private fun AppRow(
    pkg: String,
    label: String,
    requester: FocusRequester,
    moving: Boolean,
    locked: Boolean,
    pinEntry: Boolean,
    pin: String,
    focusTarget: FocusTarget?,
    onFocusConsumed: () -> Unit,
    onFocus: () -> Unit,
    onLeft: () -> Unit,
    onLaunch: () -> Unit,
    onPinOk: () -> Unit,
    onPinCancel: () -> Unit,
    onMenu: () -> Unit,
    onMove: (Int) -> Unit,
    onDone: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    // [0] = OK is held down, [1] = long press already fired
    val press = remember { booleanArrayOf(false, false) }
    val shape = RoundedCornerShape(13.u())

    LaunchedEffect(focusTarget) {
        val t = focusTarget
        if (t != null && t.pkg == pkg) {
            delay(100)
            runCatching { requester.requestFocus() }
            onFocusConsumed()
        }
    }
    LaunchedEffect(moving) {
        if (moving) {
            delay(120)
            runCatching { requester.requestFocus() }
        }
    }

    val highlighted = focused || moving || pinEntry
    Row(
        Modifier
            .fillMaxWidth()
            .height(77.u())
            .clip(shape)
            .background(if (highlighted) FocusFill else Color.Transparent)
            .border(2.u(), if (moving) TextPrimary else if (focused) FocusBorder else Color.Transparent, shape)
            .focusRequester(requester)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocus() }
            .onPreviewKeyEvent { ev ->
                val isOk = ev.key == Key.DirectionCenter || ev.key == Key.Enter || ev.key == Key.NumPadEnter
                if (pinEntry) {
                    // The PIN box owns the keyboard while it is open.
                    false
                } else if (moving) {
                    // MOVE mode: UP / DOWN carry the app through the list, OK finishes.
                    when (ev.key) {
                        Key.DirectionUp -> { if (ev.type == KeyEventType.KeyDown) onMove(-1); true }
                        Key.DirectionDown -> { if (ev.type == KeyEventType.KeyDown) onMove(1); true }
                        Key.DirectionLeft, Key.DirectionRight -> true
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                            if (ev.type == KeyEventType.KeyUp) onDone()
                            true
                        }
                        else -> false
                    }
                } else if (ev.key == Key.DirectionLeft) {
                    // Left: open the quick menu in place of the app list.
                    if (ev.type == KeyEventType.KeyDown) onLeft()
                    true
                } else if (!isOk) {
                    false
                } else {
                    when (ev.type) {
                        KeyEventType.KeyDown -> {
                            if (ev.nativeKeyEvent.repeatCount == 0) {
                                press[0] = true
                                press[1] = false
                            } else if (press[0] && !press[1]) {
                                // OK held down: long press -> open menu.
                                press[1] = true
                                onMenu()
                            }
                            true
                        }
                        KeyEventType.KeyUp -> {
                            if (press[0] && !press[1]) onLaunch()
                            press[0] = false
                            press[1] = false
                            true
                        }
                        else -> false
                    }
                }
            }
            // Touch / mouse still works.
            .combinedClickable(enabled = !pinEntry, onClick = onLaunch, onLongClick = onMenu)
            .padding(start = 19.5f.u(), end = 12.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(pkg, 50.u())
        if (highlighted) {
            Spacer(Modifier.width(16.u()))
            if (pinEntry) {
                // PIN box takes the place of the app name, same height as the icon.
                PinBox(pin = pin, onOk = onPinOk, onCancel = onPinCancel, modifier = Modifier.weight(1f))
            } else {
                // Fixed line height + trimmed padding = name is vertically centered on the icon.
                Text(
                    label, color = TextPrimary, fontSize = 27.us(), fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = TextStyle(lineHeight = 34.us(), lineHeightStyle = MidLine),
                    modifier = Modifier.weight(1f),
                )
                if (locked) {
                    Icon(Icons.Outlined.Lock, null, tint = TextDim, modifier = Modifier.size(26.u()))
                }
            }
            if (moving) {
                Icon(Icons.Outlined.UnfoldMore, null, tint = TextPrimary, modifier = Modifier.size(30.u()))
            }
        }
    }
}

/** Long-press menu. No title: the app name is not shown at the top. */
@Composable
private fun AppMenu(
    locked: Boolean,
    onDismiss: () -> Unit,
    onRename: () -> Unit,
    onIcon: () -> Unit,
    onLock: () -> Unit,
    onMove: () -> Unit,
    onHide: () -> Unit,
    onInfo: () -> Unit,
    onSettings: () -> Unit,
) {
    val first = remember { FocusRequester() }
    val opened = remember { System.currentTimeMillis() }
    val armed = remember { booleanArrayOf(false) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        LaunchedEffect(Unit) {
            delay(60)
            runCatching { first.requestFocus() }
        }
        val shape = RoundedCornerShape(16.u())
        Column(
            Modifier
                // Swallow the still-held OK press that opened this menu so it can't
                // accidentally select the first item when released.
                .onPreviewKeyEvent { ev ->
                    val isOk = ev.key == Key.DirectionCenter || ev.key == Key.Enter || ev.key == Key.NumPadEnter
                    if (!isOk) {
                        false
                    } else {
                        if (!armed[0] && System.currentTimeMillis() - opened > 800) armed[0] = true
                        if (armed[0]) {
                            false
                        } else {
                            if (ev.type == KeyEventType.KeyUp) armed[0] = true
                            true
                        }
                    }
                }
                .width(340.u())
                .clip(shape)
                .background(Color(0xFF1B1E24))
                .border(2.u(), FocusBorder, shape)
                .padding(14.u()),
            verticalArrangement = Arrangement.spacedBy(6.u()),
        ) {
            MenuItem("Rename", Modifier.focusRequester(first), onRename)
            MenuItem("Change Icon", Modifier, onIcon)
            MenuItem(if (locked) "Unlock" else "Lock", Modifier, onLock)
            MenuItem("Move", Modifier, onMove)
            MenuItem("Hide", Modifier, onHide)
            MenuItem("Info / Uninstall", Modifier, onInfo)
            MenuItem("Launcher Settings", Modifier, onSettings)
        }
    }
}

@Composable
private fun MenuItem(text: String, modifier: Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Box(
        modifier
            .fillMaxWidth()
            .height(52.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color.Transparent)
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 18.u()),
        contentAlignment = Alignment.CenterStart,
    ) {
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
        )
    }
}

@Composable
private fun RightPane(links: List<String>, intervalMin: Int, muted: Boolean, weather: Weather?, net: NetState, wakeTick: Int) {
    // Top to bottom: Wi-Fi badge in the top corner, clock, weather/date right under the clock,
    // then the 16:9 stream pinned to the bottom. Fixed-height pieces mean the stream can never
    // overlap the temperature or day name.
    Column(Modifier.width(540.u()).fillMaxHeight()) {
        WifiBadge(Modifier.fillMaxWidth(), net)
        // Fixed-height slot for the clock; the (taller) text line box may extend past it
        // without changing the layout, and is pulled up so the digits sit at the top of the slot.
        Box(Modifier.fillMaxWidth().height(108.u()), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.wrapContentHeight(Alignment.Top, unbounded = true).offset(y = (-19).u())) {
                ClockBlock()
            }
        }
        Spacer(Modifier.height(22.u()))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            WeatherDateBlock(weather)
        }
        Spacer(Modifier.weight(1f))
        LiveCard(links, intervalMin, muted, wakeTick, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
    }
}

@Composable
private fun ClockBlock() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000)
        }
    }
    val time = SimpleDateFormat("h:mm", Locale.getDefault()).format(now)
    val ampm = SimpleDateFormat("a", Locale.ENGLISH).format(now).uppercase(Locale.ENGLISH)
    Row(horizontalArrangement = Arrangement.Center) {
        Text(
            time, color = TextPrimary, fontSize = 144.us(), fontWeight = FontWeight.Medium,
            letterSpacing = (-5).us(), maxLines = 1, softWrap = false,
            style = TextStyle(lineHeight = 144.us(), lineHeightStyle = CenterLine),
            modifier = Modifier.alignByBaseline(),
        )
        Spacer(Modifier.width(16.u()))
        Text(
            ampm, color = TextPrimary, fontSize = 36.us(), maxLines = 1,
            style = TextStyle(lineHeight = 36.us(), lineHeightStyle = CenterLine),
            modifier = Modifier.alignByBaseline(),
        )
    }
}

@Composable
private fun WeatherDateBlock(weather: Weather?) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(30_000)
        }
    }
    val date = SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH).format(now)
    val day = SimpleDateFormat("EEEE", Locale.ENGLISH).format(now)

    Row(Modifier.height(76.u()), verticalAlignment = Alignment.CenterVertically) {
        Column(
            Modifier.width(100.u()).fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            // Weather condition on top, temperature below it ("C" in a smaller size).
            Icon(weatherIcon(weather), null, tint = TextPrimary, modifier = Modifier.size(40.u()))
            Text(
                buildAnnotatedString {
                    append(weather?.tempC?.toString() ?: "--")
                    withStyle(SpanStyle(fontSize = 18.us(), fontWeight = FontWeight.Normal)) { append("°C") }
                },
                color = TextPrimary, fontSize = 34.us(),
                fontWeight = FontWeight.Medium, maxLines = 1,
                style = TextStyle(lineHeight = 36.us(), lineHeightStyle = CenterLine),
            )
        }
        Spacer(Modifier.width(25.u()))
        Box(Modifier.width(2.u()).height(76.u()).background(LineColor))
        Spacer(Modifier.width(25.u()))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                date, color = DateColor, fontSize = 28.us(), maxLines = 1,
                style = TextStyle(lineHeight = 38.us(), lineHeightStyle = CenterLine),
            )
            Text(
                day, color = DateColor, fontSize = 28.us(), maxLines = 1,
                style = TextStyle(lineHeight = 38.us(), lineHeightStyle = CenterLine),
            )
        }
    }
}
