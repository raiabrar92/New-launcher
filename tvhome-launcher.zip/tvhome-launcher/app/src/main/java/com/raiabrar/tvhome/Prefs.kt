package com.raiabrar.tvhome

import android.content.Context

internal const val DEFAULT_LINK = "https://www.youtube.com/watch?v=t3fvgmDDmdc" // Geo News live

internal class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("tvhome", Context.MODE_PRIVATE)

    init {
        // v1.9 stored "custom" / "none" in wall_mode; since v1.10 wall_mode is "weather" or "static".
        val m = sp.getString("wall_mode", null)
        if (m == "custom" || m == "none") sp.edit().putString("static_wall", m).putString("wall_mode", "static").apply()
    }

    var order: List<String>
        get() = (sp.getString("order", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("order", v.joinToString("\n")).apply() }

    var hidden: Set<String>
        get() = (sp.getStringSet("hidden", emptySet()) ?: emptySet()).toSet()
        set(v) { sp.edit().putStringSet("hidden", HashSet(v)).apply() }

    /** Apps protected by the lock code. */
    var locked: Set<String>
        get() = (sp.getStringSet("locked", emptySet()) ?: emptySet()).toSet()
        set(v) { sp.edit().putStringSet("locked", HashSet(v)).apply() }

    /** Lock code (digits only). Empty = not set yet. */
    var pin: String
        get() = sp.getString("pin", "") ?: ""
        set(v) { sp.edit().putString("pin", v).apply() }

    /** Remote button mapping: button id ("k176") -> action ("launcher", "quick", "app:<package>", "none", ...). */
    var keymap: Map<String, String>
        get() = readMap("keymap")
        set(v) = writeMap("keymap", v)

    /** Custom app names (package -> name). */
    var names: Map<String, String>
        get() = readMap("names")
        set(v) = writeMap("names", v)

    /** Minutes each stream plays before the next link loads (playlist mode). */
    var intervalMin: Int
        get() = sp.getInt("interval_min", 1).coerceAtLeast(1)
        set(v) { sp.edit().putInt("interval_min", v.coerceAtLeast(1)).apply() }

    var muted: Boolean
        get() = sp.getBoolean("muted", true)
        set(v) { sp.edit().putBoolean("muted", v).apply() }

    /** "weather" = weather condition background is ticked; "static" = the wallpaper from [staticWall]. */
    var wallMode: String
        get() = sp.getString("wall_mode", "weather") ?: "weather"
        set(v) { sp.edit().putString("wall_mode", v).apply() }

    /** Wallpaper blur strength in percent (0 to 100). Default 40. */
    var blurPct: Int
        get() = sp.getInt("blur_pct", 40).coerceIn(0, 100)
        set(v) { sp.edit().putInt("blur_pct", v.coerceIn(0, 100)).apply() }

    /** Image links for wallpapers. Key "custom" or a weather condition name (SUNNY, RAIN, ...). */
    var wallLinks: Map<String, String>
        get() = readMap("wall_links")
        set(v) = writeMap("wall_links", v)

    /** Weather place (name + coordinates). Default Karachi. */
    var place: Place
        get() = Place(
            sp.getString("place_name", Place.DEFAULT.name) ?: Place.DEFAULT.name,
            sp.getFloat("place_lat", Place.DEFAULT.lat.toFloat()).toDouble(),
            sp.getFloat("place_lon", Place.DEFAULT.lon.toFloat()).toDouble(),
        )
        set(v) { sp.edit().putString("place_name", v.name).putFloat("place_lat", v.lat.toFloat()).putFloat("place_lon", v.lon.toFloat()).apply() }

    /** The wallpaper you chose yourself ("none", "custom" or "pic:<file>"), used when the weather background is off. */
    var staticWall: String
        get() = sp.getString("static_wall", "none") ?: "none"
        set(v) { sp.edit().putString("static_wall", v).apply() }

    /** OLED TV: the screensaver drifts a little so no pixel stays lit. Off (default) = it stays still. */
    var oled: Boolean
        get() = sp.getBoolean("oled", false)
        set(v) { sp.edit().putBoolean("oled", v).apply() }

    /** Screensaver: "off", "clock" (digital clock + calendar), "colors" or "backdrop". */
    var saverType: String
        get() = sp.getString("saver_type", "clock") ?: "clock"
        set(v) { sp.edit().putString("saver_type", v).apply() }

    /** Minutes of no remote input on the home screen before the screensaver starts. */
    var saverMin: Int
        get() = sp.getInt("saver_min", 5).coerceAtLeast(1)
        set(v) { sp.edit().putInt("saver_min", v.coerceAtLeast(1)).apply() }

    /** The Wi-Fi name permission is asked only once. */
    var askedLocation: Boolean
        get() = sp.getBoolean("asked_location", false)
        set(v) { sp.edit().putBoolean("asked_location", v).apply() }

    /** Unlimited stream links. First run: the default link only. Old link0..link4 are migrated. */
    fun links(): List<String> {
        sp.getString("links_v2", null)?.let { s -> return s.split("\n").filter { it.isNotBlank() } }
        return (0 until 5).map { i ->
            val def = if (i == 0 && !sp.contains("link0")) DEFAULT_LINK else ""
            sp.getString("link$i", def) ?: ""
        }.filter { it.isNotBlank() }
    }

    fun setLinks(v: List<String>) {
        sp.edit().putString("links_v2", v.map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")).apply()
    }

    private fun readMap(key: String): Map<String, String> =
        (sp.getString(key, "") ?: "").split("\n").mapNotNull {
            val i = it.indexOf('=')
            if (i > 0) it.substring(0, i) to it.substring(i + 1) else null
        }.toMap()

    private fun writeMap(key: String, v: Map<String, String>) {
        sp.edit().putString(key, v.entries.joinToString("\n") { "${it.key}=${it.value.replace('\n', ' ')}" }).apply()
    }
}
