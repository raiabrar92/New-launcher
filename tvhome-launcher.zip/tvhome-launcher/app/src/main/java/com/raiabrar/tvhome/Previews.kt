package com.raiabrar.tvhome

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

// Android Studio previews (open this file and use the Split / Design view).
// Panel is the 990 x 619 reference size, so LocalScale = 1.

@Composable
private fun PreviewFrame(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalScale provides 1f) {
        Box(Modifier.fillMaxSize().background(BgColor)) { content() }
    }
}

@Composable
private fun SettingsPreview(links: List<String>, hidden: List<Pair<String, String>>, pin: String) {
    LauncherSettings(
        links = links, onLinks = {},
        intervalMin = 1, onIntervalMin = {},
        muted = true, onMuted = {},
        pin = pin, onPin = {},
        hiddenApps = hidden,
        onUnhide = {}, onResetOrder = {}, onClose = {},
    )
}

@Preview(name = "Settings - first run (one prefilled link)", widthDp = 990, heightDp = 619)
@Composable
private fun SettingsFirstRunPreview() = PreviewFrame {
    SettingsPreview(listOf(DEFAULT_LINK), emptyList(), "")
}

@Preview(name = "Settings - several links, hidden apps", widthDp = 990, heightDp = 1300)
@Composable
private fun SettingsFullPreview() = PreviewFrame {
    SettingsPreview(
        listOf(DEFAULT_LINK, "https://example.com/live.m3u8", "https://www.youtube.com/watch?v=abcdefghijk"),
        listOf("a.b.one" to "Play Store", "a.b.two" to "Settings"),
        "1234",
    )
}

@Preview(name = "PIN box", widthDp = 340, heightDp = 90)
@Composable
private fun PinBoxPreview() = PreviewFrame {
    Box(Modifier.padding(20.dp)) {
        PinBox(pin = "1234", onOk = {}, onCancel = {})
    }
}
