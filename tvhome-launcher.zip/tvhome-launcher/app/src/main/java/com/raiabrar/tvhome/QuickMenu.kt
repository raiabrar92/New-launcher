package com.raiabrar.tvhome

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Bluetooth
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SettingsInputHdmi
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

internal enum class QuickAction(val label: String, val icon: ImageVector) {
    OPTIMIZE("Optimize", Icons.Outlined.CleaningServices),
    // The WiFi row never shows this label: it shows the connected network name instead.
    WIFI("WiFi", Icons.Outlined.Wifi),
    BLUETOOTH("Bluetooth", Icons.Outlined.Bluetooth),
    INPUT("Input Source", Icons.Outlined.SettingsInputHdmi),
    ALL_APPS("All Apps List", Icons.Outlined.Apps),
    LAUNCHER("Launcher", Icons.Outlined.Home),
    SETTINGS("Settings", Icons.Outlined.Settings),
}

/** Width of a list column that shows icons only (reference px): icon + its side padding. */
internal const val ICON_COL = 82f

/**
 * The quick menu list. It sits next to the app list (apps move to the opposite side, their icons stay
 * visible) and the highlighter moves between the two lists with Left / Right. Same look and behaviour as
 * the app list, mirrored: the icon is on the right of its row and the highlighted item shows its name
 * on the left of the icon. The WiFi row shows the connected network name.
 *
 * [focusTick] changes whenever the list should take the highlighter.
 */
@Composable
internal fun QuickMenu(
    wifiLabel: String,
    focusTick: Int,
    onAction: (QuickAction) -> Unit,
    onFocused: () -> Unit,
    onRight: () -> Unit,
    rowH: Dp,
    modifier: Modifier = Modifier,
) {
    val actions = remember { QuickAction.values().toList() }
    val requesters = remember { actions.map { FocusRequester() } }
    var lastIdx by remember { mutableIntStateOf(0) }
    LaunchedEffect(focusTick) {
        if (focusTick > 0) {
            delay(80)
            runCatching { requesters[lastIdx].requestFocus() }
        }
    }
    LazyColumn(modifier) {
        itemsIndexed(actions) { i, a ->
            QuickRow(
                a, if (a == QuickAction.WIFI) wifiLabel else a.label, requesters[i], rowH,
                onFocused = { lastIdx = i; onFocused() },
                onClick = { onAction(a) },
                onRight = onRight,
            )
        }
    }
}

@Composable
private fun QuickRow(
    a: QuickAction,
    label: String,
    requester: FocusRequester,
    rowH: Dp,
    onFocused: () -> Unit,
    onClick: () -> Unit,
    onRight: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .height(rowH)
            .then(if (focused) Modifier.glassHighlight(18.u(), 6.u()) else Modifier)
            .focusRequester(requester)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocused() }
            .onPreviewKeyEvent { ev ->
                when (ev.key) {
                    Key.DirectionRight -> { if (ev.type == KeyEventType.KeyDown) onRight(); true }
                    Key.DirectionLeft -> true
                    else -> false
                }
            }
            .clickable(onClick = onClick)
            .padding(start = 16.u(), end = 16.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (focused) {
            Text(
                label, color = TextPrimary, fontSize = 27.us(), fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End,
                style = TextStyle(lineHeight = 34.us(), lineHeightStyle = MidLine),
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(16.u()))
        } else {
            Spacer(Modifier.weight(1f))
        }
        Box(Modifier.size(50.u()), contentAlignment = Alignment.Center) {
            Icon(
                a.icon, contentDescription = label,
                tint = if (focused) TextPrimary else DateColor, modifier = Modifier.size(40.u()),
            )
        }
    }
}

// ---- Actions -------------------------------------------------------------------------------

/** Tries each system screen in turn; tells the user if the TV has none of them. */
internal fun openSystem(ctx: Context, vararg actions: String) {
    for (a in actions) {
        val ok = runCatching {
            ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        }.getOrDefault(false)
        if (ok) return
    }
    Toast.makeText(ctx, "Not available on this TV", Toast.LENGTH_SHORT).show()
}

/**
 * Frees RAM by ending the background processes of the apps in the app list. The live stream, the
 * weather and the launcher itself run inside this launcher, so they are never touched. Android only
 * lets an app end the background (not the foreground) processes of other apps, so this cannot
 * force-stop an app that is actively playing. Returns roughly how many MB became free.
 */
internal suspend fun optimizeMemory(ctx: Context, packages: List<String>): Long {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    fun avail(): Long = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
    val before = avail()
    withContext(Dispatchers.Default) {
        for (p in packages) {
            if (p == ctx.packageName) continue
            runCatching { am.killBackgroundProcesses(p) }
        }
    }
    delay(1200)
    return ((avail() - before) / (1024L * 1024L)).coerceAtLeast(0L)
}

// ---- Top indicator (not selectable) -----------------------------------------------------------------

/**
 * `[Settings] [Home]` above the lists, same icon size as the Wi-Fi icon in the opposite corner.
 * The Home icon is circled while the app list is active, the Settings icon while the quick menu is.
 */
@Composable
internal fun ModeIndicator(appsActive: Boolean, modifier: Modifier = Modifier) {
    Row(
        modifier.height(30.u()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(20.u()),
    ) {
        IndicatorIcon(Icons.Outlined.Settings, circled = !appsActive)
        IndicatorIcon(Icons.Outlined.Home, circled = appsActive)
    }
}

@Composable
private fun IndicatorIcon(icon: ImageVector, circled: Boolean) {
    val pad = 4.u()
    val stroke = 2.u()
    Box(
        Modifier.size(28.u()).drawBehind {
            if (circled) {
                drawCircle(TextPrimary, radius = size.minDimension / 2 + pad.toPx(), style = Stroke(stroke.toPx()))
            }
        },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = if (circled) TextPrimary else DateColor, modifier = Modifier.size(28.u()))
    }
}

/** Remote & Accessories page of the TV settings. TV makers name it differently, so several are tried. */
internal fun openRemoteAccessories(ctx: Context) {
    val tvs = listOf("com.android.tv.settings", "com.google.android.tvsettings")
    val classes = listOf(
        "com.android.tv.settings.accessories.AccessoriesActivity",
        "com.android.tv.settings.accessories.BluetoothAccessoryActivity",
        "com.android.tv.settings.accessories.AddAccessoryActivity",
    )
    val intents = buildList {
        for (pkg in tvs) for (cls in classes) add(Intent().setClassName(pkg, cls))
        add(Intent("com.android.tv.settings.action.ACCESSORIES"))
        add(Intent("android.settings.BLUETOOTH_SETTINGS"))
        add(Intent(android.provider.Settings.ACTION_SETTINGS))
    }
    for (i in intents) {
        val ok = runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }.getOrDefault(false)
        if (ok) return
    }
    Toast.makeText(ctx, "Not available on this TV", Toast.LENGTH_SHORT).show()
}

/** True when this launcher is the TV's default Home app. */
internal fun isDefaultLauncher(ctx: Context): Boolean = runCatching {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    ctx.packageManager.resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
        ?.activityInfo?.packageName == ctx.packageName
}.getOrDefault(false)

/**
 * Make this launcher the default, or change it. Android 10+: asks for the Home role. Otherwise (or if the
 * TV has no such dialog) the system "Home app" / "Default apps" screen opens; last fallback is Settings.
 */
internal fun openDefaultLauncherSettings(ctx: Context) {
    if (android.os.Build.VERSION.SDK_INT >= 29) {
        val ok = runCatching {
            val rm = ctx.getSystemService(android.app.role.RoleManager::class.java)
            if (rm.isRoleAvailable(android.app.role.RoleManager.ROLE_HOME) &&
                !rm.isRoleHeld(android.app.role.RoleManager.ROLE_HOME)
            ) {
                ctx.startActivity(
                    rm.createRequestRoleIntent(android.app.role.RoleManager.ROLE_HOME)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                true
            } else false
        }.getOrDefault(false)
        if (ok) return
    }
    openSystem(
        ctx, "android.settings.HOME_SETTINGS", android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS,
        android.provider.Settings.ACTION_SETTINGS,
    )
}
