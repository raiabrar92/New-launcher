package com.raiabrar.tvhome

import android.view.KeyEvent

/** A remote button was pressed that is assigned to [action]. [n] is a unique time stamp. */
internal data class RemoteReq(val action: String, val n: Long)

internal class RemoteActionDef(val id: String, val label: String)

/**
 * Remote button mapping. A button is identified by its Android key code ("k176"); buttons that
 * send no key code are identified by their hardware scan code ("s312").
 */
internal object RemoteKeys {
    /** While set, every key press goes here (used by the "press a button" step in settings). */
    @Volatile var capture: ((KeyEvent) -> Unit)? = null

    /** Needed to move around the launcher, so they can never be reassigned. */
    val PROTECTED = setOf(
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_HOME,
        KeyEvent.KEYCODE_POWER,
    )

    val ACTIONS = listOf(
        RemoteActionDef("launcher", "Launcher Settings"),
        RemoteActionDef("quick", "Quick menu"),
        RemoteActionDef("input", "Input Source"),
        RemoteActionDef("system", "Android Settings"),
        RemoteActionDef("wifi", "Wi-Fi Settings"),
        RemoteActionDef("bluetooth", "Bluetooth Settings"),
        RemoteActionDef("allapps", "All Apps List"),
        RemoteActionDef("optimize", "Optimize memory"),
        RemoteActionDef("saver", "Start screensaver"),
        RemoteActionDef("first", "Go to first app"),
    )

    /** Built-in buttons. Anything you set yourself replaces them; "Do nothing" switches one off. */
    val DEFAULTS = mapOf(
        "k${KeyEvent.KEYCODE_SETTINGS}" to "launcher",
        "k${KeyEvent.KEYCODE_MENU}" to "quick",
    )

    fun idOf(e: KeyEvent): String =
        if (e.keyCode != KeyEvent.KEYCODE_UNKNOWN) "k${e.keyCode}" else "s${e.scanCode}"

    /** Built-ins plus the user's own, in a stable order. */
    fun all(prefs: Prefs): Map<String, String> =
        (DEFAULTS + prefs.keymap).entries.sortedBy { nameOf(it.key) }.associate { it.key to it.value }

    /** The action for this key press, or null when the button is not assigned. */
    fun actionFor(prefs: Prefs, e: KeyEvent): String? =
        (DEFAULTS + prefs.keymap)[idOf(e)]?.takeIf { it != "none" }

    fun nameOf(id: String): String {
        val n = id.drop(1).toIntOrNull() ?: return id
        if (id.startsWith("s")) return "Button (scan code $n)"
        return KeyEvent.keyCodeToString(n).removePrefix("KEYCODE_").replace('_', ' ')
            .lowercase().replaceFirstChar { it.uppercase() }
    }

    fun labelOf(action: String, appName: (String) -> String?): String = when {
        action == "none" -> "Do nothing"
        action.startsWith("app:") -> "Open " + (action.removePrefix("app:").let { appName(it) ?: it })
        else -> ACTIONS.firstOrNull { it.id == action }?.label ?: action
    }

    /** Sets [action] for a button; null removes it (a built-in button is switched off instead). */
    fun set(prefs: Prefs, key: String, action: String?) {
        val m = prefs.keymap.toMutableMap()
        if (action != null) m[key] = action
        else if (key in DEFAULTS) m[key] = "none"
        else m.remove(key)
        prefs.keymap = m
    }
}
