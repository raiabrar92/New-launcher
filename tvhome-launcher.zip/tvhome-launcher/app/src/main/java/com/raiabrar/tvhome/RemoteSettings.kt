package com.raiabrar.tvhome

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay

private val RemoteSheetBg = Color(0xFF1B1E24)

/** Launcher Settings > Remote buttons: choose what each remote button does. */
@Composable
internal fun RemotePage(host: SettingsHost, prefs: Prefs, onBack: () -> Unit) {
    var map by remember { mutableStateOf(RemoteKeys.all(prefs)) }
    var capturing by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }
    var editKey by remember { mutableStateOf<String?>(null) }
    var pickApp by remember { mutableStateOf(false) }
    val first = remember { FocusRequester() }
    val names = host.apps.associate { it.pkg to it.name }

    fun save(key: String, action: String?) {
        RemoteKeys.set(prefs, key, action)
        map = RemoteKeys.all(prefs)
        editKey = null
        pickApp = false
    }

    // While "press a button" is showing, the next key press is taken from the activity.
    DisposableEffect(capturing) {
        if (capturing) {
            RemoteKeys.capture = { e ->
                when {
                    e.keyCode == KeyEvent.KEYCODE_BACK -> capturing = false
                    e.keyCode in RemoteKeys.PROTECTED ->
                        info = "That button is needed to move around the launcher. Press another one."
                    else -> {
                        capturing = false
                        editKey = RemoteKeys.idOf(e)
                    }
                }
            }
        }
        onDispose { RemoteKeys.capture = null }
    }
    LaunchedEffect(capturing) {
        if (!capturing) {
            delay(80)
            runCatching { first.requestFocus() }
        }
    }

    if (capturing) {
        PageList("Remote buttons") {
            item {
                Text("Press the remote button you want to assign now.", color = TextPrimary, fontSize = 28.us())
            }
            item { Text(info, color = Color(0xFFE8A87C), fontSize = 20.us()) }
            item { Text("Press Back to cancel.", color = TextDim, fontSize = 20.us()) }
        }
        return
    }

    PageList("Remote buttons") {
        item {
            Text(
                "Choose what a remote button does. Buttons the TV itself handles first (for example some " +
                    "Home, Power or system Settings keys) never reach the launcher and cannot be assigned.",
                color = TextDim, fontSize = 19.us(),
            )
        }
        itemsIndexed(map.entries.toList(), key = { _, e -> e.key }) { i, e ->
            SettingsButton(
                RemoteKeys.nameOf(e.key),
                { editKey = e.key },
                if (i == 0) Modifier.focusRequester(first) else Modifier,
                subtitle = RemoteKeys.labelOf(e.value) { names[it] },
            )
        }
        item { SettingsButton("Add a button", { info = ""; capturing = true }) }
        item { SettingsButton("Back", onBack) }
    }

    val key = editKey
    if (key != null && !pickApp) {
        PickerDialog(
            title = RemoteKeys.nameOf(key) + " button does:",
            onDismiss = { editKey = null },
        ) {
            items(RemoteKeys.ACTIONS) { a ->
                SettingsButton(
                    (if (map[key] == a.id) "✓ " else "") + a.label,
                    { save(key, a.id) },
                )
            }
            item { SettingsButton("Open an app...", { pickApp = true }) }
            item { SettingsButton("Do nothing", { save(key, "none") }) }
            item { SettingsButton("Remove this button", { save(key, null) }) }
        }
    }
    if (key != null && pickApp) {
        PickerDialog(
            title = "Open which app?",
            onDismiss = { pickApp = false },
        ) {
            items(host.apps, key = { it.pkg }) { app ->
                SettingsButton(app.name, { save(key, "app:" + app.pkg) }, pkg = app.pkg)
            }
        }
    }
}

@Composable
private fun PickerDialog(
    title: String,
    onDismiss: () -> Unit,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit,
) {
    val shape = RoundedCornerShape(16.u())
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.width(560.u()).clip(shape).background(RemoteSheetBg).border(2.u(), FocusBorder, shape).padding(20.u()),
            verticalArrangement = Arrangement.spacedBy(12.u()),
        ) {
            Text(title, color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            LazyColumn(
                Modifier.fillMaxWidth().height(400.u()),
                verticalArrangement = Arrangement.spacedBy(8.u()),
                content = content,
            )
        }
    }
}
