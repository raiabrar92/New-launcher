package com.raiabrar.tvhome

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Full-screen screensaver. Any remote key closes it (handled in MainActivity). */
@Composable
internal fun Screensaver(
    type: String,
    weather: Weather? = null,
    placeName: String = Place.DEFAULT.name,
    oled: Boolean = false,
    modifier: Modifier = Modifier,
) {
    Box(modifier.fillMaxSize().background(Color.Black)) {
        when (type) {
            "colors" -> ColorsSaver()
            "backdrop" -> BackdropSaver()
            else -> ClockCalendarSaver(weather, oled)
        }
    }
}

/** Slowly drifting solid colour, like the Google TV "Colors" screensaver. */
@Composable
private fun ColorsSaver() {
    val t = rememberInfiniteTransition(label = "colors")
    val hue by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(90_000, easing = LinearEasing), RepeatMode.Restart),
        label = "hue",
    )
    Box(Modifier.fillMaxSize().background(Color.hsv(hue, 0.55f, 0.42f)))
}

/** Slow slideshow of the weather scenes, like the Google TV "Backdrop" screensaver. */
@Composable
private fun BackdropSaver() {
    val scenes = remember { WallCond.values().toList() }
    var idx by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(12_000)
            idx = (idx + 1) % scenes.size
        }
    }
    Crossfade(targetState = idx, animationSpec = tween(2500), label = "backdrop") { i ->
        WallpaperLayer(scenes[i], "weather", 0, Modifier.fillMaxSize())
    }
}

/**
 * Big digital clock; centred under it the day name with today's temperature, the date and tomorrow's weather; plus a calendar
 * of the current month. Stays still by default; with the OLED TV option on it shifts a little every
 * minute (burn-in safe).
 */
@Composable
private fun ClockCalendarSaver(weather: Weather?, oled: Boolean) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000)
        }
    }
    val slot = (now.time / 60_000L).toInt()
    val dx = if (oled) listOf(-14, 0, 14, 0)[slot % 4] else 0
    val dy = if (oled) listOf(-8, 8, 0, -4)[(slot / 4) % 4] else 0
    val time = SimpleDateFormat("h:mm", Locale.getDefault()).format(now)
    val ampm = SimpleDateFormat("a", Locale.ENGLISH).format(now).uppercase(Locale.ENGLISH)
    val day = SimpleDateFormat("EEEE", Locale.ENGLISH).format(now)
    val date = SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH).format(now)

    // SpaceEvenly: the gap left of the text block, between block and divider, between divider and
    // calendar, and right of the calendar are all the same.
    Row(
        Modifier.fillMaxSize().offset(dx.u(), dy.u()),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // 12:25 PM
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    time, color = TextPrimary, fontSize = 128.us(), fontWeight = FontWeight.Medium,
                    letterSpacing = (-4).us(), maxLines = 1, softWrap = false,
                    style = TextStyle(lineHeight = 140.us(), lineHeightStyle = CenterLine),
                )
                Spacer(Modifier.width(10.u()))
                Text(
                    ampm, color = DateColor, fontSize = 30.us(), maxLines = 1,
                    style = TextStyle(lineHeight = 36.us(), lineHeightStyle = CenterLine),
                    modifier = Modifier.offset(y = (-22).u()),
                )
            }
            // Tuesday  [icon] 25°C
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(day, color = DateColor, fontSize = 28.us(), maxLines = 1)
                Spacer(Modifier.width(18.u()))
                Icon(weatherIcon(weather), null, tint = TextPrimary, modifier = Modifier.size(36.u()))
                Spacer(Modifier.width(6.u()))
                Text(tempText(weather?.tempC, 34, 18), color = TextPrimary, fontSize = 34.us(),
                    fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
            }
            // 22-Nov-2026
            Text(date, color = DateColor, fontSize = 28.us(), maxLines = 1)
            Spacer(Modifier.height(14.u()))
            // Tomorrow: [icon] 16°C
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Tomorrow:", color = DateColor, fontSize = 26.us(), maxLines = 1)
                Spacer(Modifier.width(12.u()))
                Icon(tomorrowIcon(weather), null, tint = TextPrimary, modifier = Modifier.size(32.u()))
                Spacer(Modifier.width(8.u()))
                Text(tempText(weather?.tomorrowC, 28, 16), color = TextPrimary, fontSize = 28.us(),
                    fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
            }
        }
        Box(Modifier.width(2.u()).height(280.u()).background(LineColor))
        MonthCalendar(now)
    }
}

/** "24°C" with the unit smaller, like on the home screen. */
@Composable
private fun tempText(t: Int?, @Suppress("UNUSED_PARAMETER") size: Int, unit: Int) = buildAnnotatedString {
    append(t?.toString() ?: "--")
    withStyle(SpanStyle(fontSize = unit.us(), fontWeight = FontWeight.Normal)) { append("°C") }
}

@Composable
private fun MonthCalendar(now: Date) {
    val cal = Calendar.getInstance().apply { time = now }
    val today = cal.get(Calendar.DAY_OF_MONTH)
    val first = cal.firstDayOfWeek // 1 = Sunday
    val firstOfMonth = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
    val offset = (firstOfMonth.get(Calendar.DAY_OF_WEEK) - first + 7) % 7
    val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val rows = (offset + days + 6) / 7
    val letters = listOf("S", "M", "T", "W", "T", "F", "S")
    val title = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(now)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = TextPrimary, fontSize = 30.us(), fontWeight = FontWeight.Medium, maxLines = 1)
        Spacer(Modifier.height(12.u()))
        Row {
            for (i in 0 until 7) {
                Box(Modifier.size(46.u(), 36.u()), contentAlignment = Alignment.Center) {
                    Text(letters[(first - 1 + i) % 7], color = TextDim, fontSize = 19.us())
                }
            }
        }
        for (r in 0 until rows) {
            Row {
                for (c in 0 until 7) {
                    val d = r * 7 + c - offset + 1
                    Box(Modifier.size(46.u(), 46.u()), contentAlignment = Alignment.Center) {
                        if (d in 1..days) {
                            val isToday = d == today
                            Box(
                                Modifier.size(40.u()).clip(CircleShape)
                                    .background(if (isToday) TextPrimary else Color.Transparent),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    "$d", color = if (isToday) BgColor else DateColor, fontSize = 22.us(),
                                    fontWeight = if (isToday) FontWeight.Medium else FontWeight.Normal,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
