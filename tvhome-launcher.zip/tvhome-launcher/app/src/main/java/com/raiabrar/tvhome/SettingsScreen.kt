package com.raiabrar.tvhome

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedBorderColor = TextPrimary,
    unfocusedBorderColor = LineColor,
    focusedLabelColor = TextPrimary,
    unfocusedLabelColor = TextDim,
    cursorColor = TextPrimary,
)

@Composable
internal fun LauncherSettings(
    links: List<String>,
    onLinks: (List<String>) -> Unit,
    intervalMin: Int,
    onIntervalMin: (Int) -> Unit,
    muted: Boolean,
    onMuted: (Boolean) -> Unit,
    pin: String,
    onPin: (String) -> Unit,
    hiddenApps: List<Pair<String, String>>,
    onUnhide: (String) -> Unit,
    onResetOrder: () -> Unit,
    onClose: () -> Unit,
) {
    // Unlimited links: the first is always there (prefilled), "Add link" appears once the
    // last one is filled in.
    val items = remember { mutableStateListOf<String>().also { it.addAll(links.ifEmpty { listOf("") }) } }
    var focusNew by remember { mutableIntStateOf(-1) }
    var minutesText by remember { mutableStateOf(intervalMin.toString()) }
    var mutedState by remember { mutableStateOf(muted) }
    var pinText by remember { mutableStateOf(pin) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 60.u(), vertical = 28.u()),
        verticalArrangement = Arrangement.spacedBy(10.u()),
    ) {
        item {
            Text("Launcher Settings", color = TextPrimary, fontSize = 34.us(), fontWeight = FontWeight.Medium)
        }
        item {
            Text("Live stream links", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.u()))
            Text(
                "Add as many links as you like. With one link only that stream plays. With more, each plays " +
                    "for the time set below, then the next one loads (playlist).",
                color = TextDim, fontSize = 19.us(),
            )
        }
        itemsIndexed(items) { i, value ->
            val requester = remember { FocusRequester() }
            LaunchedEffect(Unit) {
                if (focusNew == i) {
                    focusNew = -1
                    runCatching { requester.requestFocus() }
                }
            }
            OutlinedTextField(
                value = value,
                onValueChange = { items[i] = it; onLinks(items.toList()) },
                label = { Text("Link ${i + 1}") },
                singleLine = true,
                textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth().focusRequester(requester),
            )
        }
        if (items.last().isNotBlank()) {
            item {
                SettingsButton("+  Add link", onClick = {
                    items.add("")
                    focusNew = items.lastIndex
                })
            }
        }
        // Time-to-next and muted-play side by side, below the links option.
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.u()),
                verticalAlignment = Alignment.Top,
            ) {
                OutlinedTextField(
                    value = minutesText,
                    onValueChange = { v ->
                        val d = v.filter { it.isDigit() }.take(3)
                        minutesText = d
                        d.toIntOrNull()?.takeIf { it >= 1 }?.let(onIntervalMin)
                    },
                    label = { Text("Play next stream after (min)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                    colors = fieldColors(),
                    modifier = Modifier.weight(1f),
                )
                ToggleRow(
                    "Muted play", mutedState,
                    onToggle = { mutedState = !mutedState; onMuted(mutedState) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
        item {
            Spacer(Modifier.height(8.u()))
            Text("App lock code", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.u()))
            Text(
                "Digits only. Used by Lock / Unlock in the app menu and to open locked apps.",
                color = TextDim, fontSize = 19.us(),
            )
        }
        item {
            OutlinedTextField(
                value = pinText,
                onValueChange = { v ->
                    val d = v.filter { it.isDigit() }.take(8)
                    pinText = d
                    onPin(d)
                },
                label = { Text("Lock code (4 to 8 digits)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            Spacer(Modifier.height(8.u()))
            Text("Hidden apps", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
        }
        if (hiddenApps.isEmpty()) {
            item { Text("No hidden apps.", color = TextDim, fontSize = 20.us()) }
        } else {
            items(hiddenApps, key = { it.first }) { (pkg, label) ->
                SettingsButton("$label  -  Unhide", onClick = { onUnhide(pkg) }, pkg = pkg)
            }
        }
        item {
            Spacer(Modifier.height(8.u()))
            SettingsButton("Reset app order (A-Z)", onClick = onResetOrder)
        }
        item { SettingsButton("Done", onClick = onClose) }
    }
}

/** Focusable tick box row, same height as a text field so it sits level beside one. */
@Composable
private fun ToggleRow(text: String, checked: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        modifier
            .height(56.dp)
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onToggle)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = checked, onCheckedChange = null,
            colors = CheckboxDefaults.colors(
                checkedColor = TextPrimary, checkmarkColor = BgColor, uncheckedColor = TextDim,
            ),
        )
        Spacer(Modifier.width(12.u()))
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 22.us(), maxLines = 1,
            style = TextStyle(lineHeight = 28.us(), lineHeightStyle = MidLine),
        )
    }
}

@Composable
private fun SettingsButton(text: String, onClick: () -> Unit, pkg: String? = null) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        Modifier
            .fillMaxWidth()
            .height(62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (pkg != null) {
            AppIcon(pkg, 40.u())
            Spacer(Modifier.width(14.u()))
        }
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
        )
    }
}
