package com.raiabrar.tvhome

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Pages of Launcher Settings. */
internal enum class SettingsPage { Main, Links, Apps, Display, Weather, Backup, Remote }

internal class AppEntry(val pkg: String, val name: String)

/** What the Hide / Lock page needs from the launcher. */
internal interface SettingsHost {
    val pin: String
    /** All apps in launcher order. */
    val apps: List<AppEntry>
    val hiddenSet: Set<String>
    val lockedSet: Set<String>
    fun setPin(v: String)
    fun hide(pkgs: Set<String>)
    fun unhide(pkgs: Set<String>)
    fun lock(pkgs: Set<String>)
    fun unlock(pkgs: Set<String>)
    fun resetOrder()
}

private val SAVER_MINUTES = listOf(1, 2, 5, 10, 15, 30)

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedBorderColor = TextPrimary,
    unfocusedBorderColor = LineColor,
    focusedLabelColor = TextPrimary,
    unfocusedLabelColor = TextDim,
    cursorColor = TextPrimary,
)

@Composable
internal fun LauncherSettings(
    page: SettingsPage,
    onPage: (SettingsPage) -> Unit,
    host: SettingsHost,
    prefs: Prefs,
    links: List<String>,
    onLinks: (List<String>) -> Unit,
    intervalMin: Int,
    onIntervalMin: (Int) -> Unit,
    muted: Boolean,
    onMuted: (Boolean) -> Unit,
    wallMode: String,
    onWallMode: (String) -> Unit,
    staticWall: String,
    onStaticWall: (String) -> Unit,
    place: Place,
    onPlace: (Place) -> Unit,
    oled: Boolean,
    onOled: (Boolean) -> Unit,
    blurPct: Int,
    onBlurPct: (Int) -> Unit,
    saverType: String,
    onSaverType: (String) -> Unit,
    saverMin: Int,
    onSaverMin: (Int) -> Unit,
    onPreviewSaver: () -> Unit,
    onClose: () -> Unit,
) {
    val back = { onPage(SettingsPage.Main) }
    when (page) {
        SettingsPage.Main -> MainPage(
            host = host, linkCount = links.size, intervalMin = intervalMin, muted = muted,
            wallMode = wallMode, staticWall = staticWall, place = place, blurPct = blurPct,
            saverType = saverType, saverMin = saverMin,
            remoteCount = RemoteKeys.all(prefs).count { it.value != "none" },
            onPage = onPage, onClose = onClose,
        )
        SettingsPage.Links -> LinksPage(
            links, onLinks, intervalMin, onIntervalMin, muted, onMuted, onBack = back,
        )
        SettingsPage.Apps -> AppsPage(host, onBack = back)
        SettingsPage.Display -> DisplayPage(
            wallMode, staticWall, onStaticWall, blurPct, onBlurPct,
            saverType, onSaverType, saverMin, onSaverMin, oled, onOled, onPreviewSaver, onBack = back,
        )
        SettingsPage.Weather -> WeatherPage(prefs, wallMode, onWallMode, place, onPlace, onBack = back)
        SettingsPage.Backup -> BackupPage(onBack = back)
        SettingsPage.Remote -> RemotePage(host, prefs, onBack = back)
    }
}

// ---- Main menu -------------------------------------------------------------------------------

@Composable
private fun MainPage(
    host: SettingsHost,
    linkCount: Int,
    intervalMin: Int,
    muted: Boolean,
    wallMode: String,
    staticWall: String,
    place: Place,
    blurPct: Int,
    saverType: String,
    saverMin: Int,
    remoteCount: Int,
    onPage: (SettingsPage) -> Unit,
    onClose: () -> Unit,
) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { first.requestFocus() }
    }
    val pkgs = host.apps.map { it.pkg }.toSet()
    val hiddenN = host.hiddenSet.count { it in pkgs }
    val lockedN = host.lockedSet.count { it in pkgs }
    PageList("Launcher Settings") {
        item {
            SettingsButton(
                "Live stream links", { onPage(SettingsPage.Links) }, Modifier.focusRequester(first),
                subtitle = "$linkCount link${if (linkCount == 1) "" else "s"}, next stream after $intervalMin min, " +
                    if (muted) "muted" else "sound on",
            )
        }
        item {
            SettingsButton(
                "Hide / Lock apps", { onPage(SettingsPage.Apps) },
                subtitle = "$hiddenN hidden, $lockedN locked" + if (host.pin.isEmpty()) ", no lock code set" else "",
            )
        }
        item {
            val src = when {
                wallMode == "weather" -> "weather background"
                staticWall == "none" -> "plain background"
                staticWall == "custom" -> "your image"
                else -> BundledWalls.title(staticWall.removePrefix("pic:"))
            }
            val saver = if (saverType == "off") "screensaver off" else "screensaver after $saverMin min"
            SettingsButton("Display Settings", { onPage(SettingsPage.Display) }, subtitle = "Wallpaper: $src, blur $blurPct%, $saver")
        }
        item {
            SettingsButton(
                "Weather Settings", { onPage(SettingsPage.Weather) },
                subtitle = place.name + if (wallMode == "weather") ", weather background on" else "",
            )
        }
        item {
            val ctx = LocalContext.current
            var isDef by remember { mutableStateOf(isDefaultLauncher(ctx)) }
            LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { isDef = isDefaultLauncher(ctx) }
            SettingsButton(
                if (isDef) "Change default launcher" else "Make this the default launcher",
                { openDefaultLauncherSettings(ctx) },
                subtitle = if (isDef) "TV Home is the default launcher" else "Another launcher opens when you press Home",
            )
        }
        item {
            SettingsButton(
                "Remote buttons", { onPage(SettingsPage.Remote) },
                subtitle = "$remoteCount button${if (remoteCount == 1) "" else "s"} assigned",
            )
        }
        item {
            val sub = when {
                !DriveSync.signedIn -> "Not connected"
                else -> "Connected, auto sync " + if (DriveSync.autoSync) "on" else "off"
            }
            SettingsButton("Backup & sync (Google Drive)", { onPage(SettingsPage.Backup) }, subtitle = sub)
        }
        item { SettingsButton("Done", onClose) }
    }
}

// ---- Live stream links -----------------------------------------------------------------------

@Composable
private fun LinksPage(
    links: List<String>,
    onLinks: (List<String>) -> Unit,
    intervalMin: Int,
    onIntervalMin: (Int) -> Unit,
    muted: Boolean,
    onMuted: (Boolean) -> Unit,
    onBack: () -> Unit,
) {
    // Unlimited links: the first is always there (prefilled), "Add link" appears once the
    // last one is filled in.
    val items = remember { mutableStateListOf<String>().also { it.addAll(links.ifEmpty { listOf("") }) } }
    var focusNew by remember { mutableIntStateOf(-1) }
    var minutesText by remember { mutableStateOf(intervalMin.toString()) }
    var mutedState by remember { mutableStateOf(muted) }

    PageList("Live stream links") {
        item {
            Text(
                "Add as many links as you like. With one link only that stream plays. With more, each plays " +
                    "for the time set below, then the next one loads (playlist).",
                color = TextDim, fontSize = 19.us(),
            )
        }
        itemsIndexed(items) { i, value ->
            val requester = remember { FocusRequester() }
            LaunchedEffect(Unit) {
                if (focusNew == i) {
                    focusNew = -1
                    runCatching { requester.requestFocus() }
                }
            }
            OutlinedTextField(
                value = value,
                onValueChange = { items[i] = it; onLinks(items.toList()) },
                label = { Text("Link ${i + 1}") },
                singleLine = true,
                textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth().focusRequester(requester),
            )
        }
        if (items.last().isNotBlank()) {
            item {
                SettingsButton("+  Add link", onClick = {
                    items.add("")
                    focusNew = items.lastIndex
                })
            }
        }
        // Time-to-next and muted-play side by side, below the links.
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.u()),
                verticalAlignment = Alignment.Top,
            ) {
                OutlinedTextField(
                    value = minutesText,
                    onValueChange = { v ->
                        val d = v.filter { it.isDigit() }.take(3)
                        minutesText = d
                        d.toIntOrNull()?.takeIf { it >= 1 }?.let(onIntervalMin)
                    },
                    label = { Text("Play next stream after (min)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                    colors = fieldColors(),
                    modifier = Modifier.weight(1f),
                )
                ToggleRow(
                    "Muted play", mutedState,
                    onToggle = { mutedState = !mutedState; onMuted(mutedState) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
        item { SettingsButton("Back", onBack) }
    }
}

// ---- Hide / Lock apps ------------------------------------------------------------------------

/**
 * One page for hiding and locking. Tick apps (one by one or Select all), then press Hide or Lock below
 * the list. Locked apps show a lock icon beside them, hidden apps show a darkened icon. Pressing the
 * button again on apps that are already hidden / locked undoes it (Unhide / Unlock; Unlock asks the PIN).
 */
@Composable
private fun AppsPage(host: SettingsHost, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val apps = host.apps
    val hidden = host.hiddenSet
    val locked = host.lockedSet
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var changePin by remember { mutableStateOf(false) }
    var lockAfterPin by remember { mutableStateOf<Set<String>?>(null) }
    var askUnlock by remember { mutableStateOf<Set<String>?>(null) }
    val allSelected = apps.isNotEmpty() && apps.all { it.pkg in selected }
    val allHidden = selected.isNotEmpty() && selected.all { it in hidden }
    val allLocked = selected.isNotEmpty() && selected.all { it in locked }
    val count = if (selected.isEmpty()) "" else " (${selected.size})"

    Column(
        Modifier.fillMaxSize().padding(horizontal = 60.u(), vertical = 28.u()),
        verticalArrangement = Arrangement.spacedBy(10.u()),
    ) {
        Text("Hide / Lock apps", color = TextPrimary, fontSize = 34.us(), fontWeight = FontWeight.Medium)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.u())) {
            item {
                Text(
                    "Tick apps, then press Hide or Lock. Locked apps show a lock icon, hidden apps go dark.",
                    color = TextDim, fontSize = 19.us(),
                )
            }
            item {
                // The code itself is never shown. Changing it needs the current code first.
                SettingsButton(
                    if (host.pin.isEmpty()) "Set lock code" else "Change lock code",
                    onClick = { changePin = true },
                    subtitle = if (host.pin.isEmpty()) "Not set" else "Hidden. Asks for the current code first",
                )
            }
            item {
                CheckRow(
                    "Select all", allSelected,
                    onToggle = { selected = if (allSelected) emptySet() else apps.map { it.pkg }.toSet() },
                )
            }
            items(apps, key = { it.pkg }) { a ->
                AppPickRow(
                    a.name, a.pkg, a.pkg in selected, a.pkg in hidden, a.pkg in locked,
                    onToggle = { selected = if (a.pkg in selected) selected - a.pkg else selected + a.pkg },
                )
            }
        }
        // [Hide] [Lock] side by side below the list.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.u())) {
            SettingsButton(
                (if (allHidden) "Unhide" else "Hide") + count,
                onClick = {
                    if (selected.isEmpty()) {
                        Toast.makeText(ctx, "Tick at least one app first", Toast.LENGTH_SHORT).show()
                    } else {
                        if (allHidden) host.unhide(selected) else host.hide(selected)
                        selected = emptySet()
                    }
                },
                modifier = Modifier.weight(1f),
            )
            SettingsButton(
                (if (allLocked) "Unlock" else "Lock") + count,
                onClick = {
                    if (selected.isEmpty()) {
                        Toast.makeText(ctx, "Tick at least one app first", Toast.LENGTH_SHORT).show()
                    } else if (allLocked) {
                        askUnlock = selected                 // unlocking needs the PIN
                    } else if (host.pin.isEmpty()) {
                        lockAfterPin = selected              // set a lock code first
                    } else {
                        host.lock(selected)
                        selected = emptySet()
                    }
                },
                modifier = Modifier.weight(1f),
            )
            SettingsButton("Back", onBack, modifier = Modifier.weight(1f))
        }
    }

    askUnlock?.let { pending ->
        PinPromptDialog(
            title = "Enter PIN to unlock", expected = host.pin,
            onOk = { host.unlock(pending); askUnlock = null; selected = emptySet() },
            onDismiss = { askUnlock = null },
        )
    }
    lockAfterPin?.let { pending ->
        ChangePinDialog(
            currentPin = "",
            onSave = {
                host.setPin(it)
                host.lock(pending)
                Toast.makeText(ctx, "Lock code set. Locked ${pending.size} app(s)", Toast.LENGTH_SHORT).show()
                selected = emptySet()
                lockAfterPin = null
            },
            onDismiss = { lockAfterPin = null },
        )
    }
    if (changePin) {
        ChangePinDialog(
            currentPin = host.pin,
            onSave = {
                host.setPin(it)
                changePin = false
                Toast.makeText(ctx, "Lock code saved", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { changePin = false },
        )
    }
}

/** App row with a tick box. Hidden apps show a darkened icon; locked apps show a lock icon beside them. */
@Composable
private fun AppPickRow(
    name: String, pkg: String, checked: Boolean, hidden: Boolean, locked: Boolean, onToggle: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        Modifier
            .fillMaxWidth()
            .height(62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onToggle)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = checked, onCheckedChange = null,
            colors = CheckboxDefaults.colors(
                checkedColor = TextPrimary, checkmarkColor = BgColor, uncheckedColor = TextDim,
            ),
        )
        Spacer(Modifier.width(10.u()))
        Box(Modifier.alpha(if (hidden) 0.22f else 1f)) { AppIcon(pkg, 40.u()) }
        Spacer(Modifier.width(14.u()))
        Text(
            name, color = if (focused) TextPrimary else if (hidden) TextDim else DateColor,
            fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
            modifier = Modifier.weight(1f),
        )
        if (locked) {
            Icon(
                Icons.Outlined.Lock, contentDescription = "Locked",
                tint = if (focused) TextPrimary else DateColor, modifier = Modifier.size(28.u()),
            )
        }
    }
}

// ---- Display Settings (wallpaper + screensaver) ------------------------------------------------

@Composable
private fun DisplayPage(
    wallMode: String,
    staticWall: String,
    onStaticWall: (String) -> Unit,
    blurPct: Int,
    onBlurPct: (Int) -> Unit,
    saverType: String,
    onSaverType: (String) -> Unit,
    saverMin: Int,
    onSaverMin: (Int) -> Unit,
    oled: Boolean,
    onOled: (Boolean) -> Unit,
    onPreviewSaver: () -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { Prefs(ctx) }
    val first = remember { FocusRequester() }
    var link by remember { mutableStateOf(prefs.wallLinks["custom"] ?: "") }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val pics = remember { BundledWalls.list(ctx) }
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { first.requestFocus() }
    }

    PageList("Display Settings") {
        item { SectionTitle("Wallpaper") }
        if (wallMode == "weather") {
            item {
                Text(
                    "The weather condition background is on, so the wallpaper follows the weather. " +
                        "To pick your own wallpaper, untick it in Weather Settings.",
                    color = TextDim, fontSize = 19.us(),
                )
            }
        } else {
            item { WallpaperGallery(pics, staticWall, onStaticWall, Modifier.focusRequester(first)) }
            item { RadioRow("None (plain background)", staticWall == "none", { onStaticWall("none") }) }
            item { RadioRow("My image link", staticWall == "custom", { onStaticWall("custom") }) }
            item {
                OutlinedTextField(
                    value = link,
                    onValueChange = { link = it; status = null },
                    label = { Text("Image link (jpg / png)") },
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                    colors = fieldColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item {
                SettingsButton(if (busy) "Downloading..." else "Download my image", onClick = {
                    if (busy) return@SettingsButton
                    scope.launch {
                        busy = true
                        prefs.wallLinks = prefs.wallLinks + ("custom" to link)
                        val ok = link.isNotBlank() && WallpaperStore.download(ctx.applicationContext, link, "custom")
                        WallpaperStore.bump()
                        if (ok) onStaticWall("custom")
                        status = if (ok) "Image saved and used as wallpaper." else "Could not download that link."
                        busy = false
                    }
                })
            }
            status?.let { st -> item { Text(st, color = TextDim, fontSize = 20.us()) } }
        }
        item {
            StepperRow(
                "Blur", "$blurPct%",
                onLeft = { onBlurPct((blurPct - 10).coerceAtLeast(0)) },
                onRight = { onBlurPct((blurPct + 10).coerceAtMost(100)) },
            )
        }

        item { SectionTitle("Screensaver") }
        item {
            Text(
                "Starts on the home screen after the remote has not been touched for the time below. " +
                    "Press any button to close it.",
                color = TextDim, fontSize = 19.us(),
            )
        }
        item { RadioRow("Digital clock + weather + calendar", saverType == "clock", { onSaverType("clock") }) }
        item { RadioRow("Colors", saverType == "colors", { onSaverType("colors") }) }
        item { RadioRow("Backdrop (scenes)", saverType == "backdrop", { onSaverType("backdrop") }) }
        item { RadioRow("Off", saverType == "off", { onSaverType("off") }) }
        item {
            StepperRow(
                "Start after", "$saverMin min",
                onLeft = { SAVER_MINUTES.lastOrNull { it < saverMin }?.let(onSaverMin) },
                onRight = { SAVER_MINUTES.firstOrNull { it > saverMin }?.let(onSaverMin) },
            )
        }
        item { ToggleRow("OLED TV (screensaver moves a little so no pixel burns in)", oled, { onOled(!oled) }, Modifier.fillMaxWidth()) }
        item { SettingsButton("Preview screensaver", onPreviewSaver) }
        item { SettingsButton("Back", onBack, if (wallMode == "weather") Modifier.focusRequester(first) else Modifier) }
    }
}

/** Row of thumbnails of the bundled wallpapers. Left / Right moves, OK picks. */
@Composable
private fun WallpaperGallery(pics: List<String>, selected: String, onPick: (String) -> Unit, firstModifier: Modifier) {
    val ctx = LocalContext.current
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.u()), modifier = Modifier.fillMaxWidth()) {
        itemsIndexed(pics) { i, f ->
            val id = "pic:$f"
            var focused by remember { mutableStateOf(false) }
            val bmp by produceState<ImageBitmap?>(null, f) {
                value = withContext(Dispatchers.IO) { BundledWalls.load(ctx, f, 320, thumb = true)?.asImageBitmap() }
            }
            val shape = RoundedCornerShape(10.u())
            Box(
                Modifier
                    .then(if (i == 0) firstModifier else Modifier)
                    .size(176.u(), 99.u())
                    .clip(shape)
                    .background(Color(0xFF181A1F))
                    .border(
                        if (selected == id || focused) 3.u() else 1.u(),
                        if (focused) TextPrimary else if (selected == id) WifiGreen else LineColor, shape,
                    )
                    .onFocusChanged { focused = it.isFocused }
                    .clickable { onPick(id) },
            ) {
                bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                if (selected == id) {
                    Icon(
                        Icons.Outlined.CheckCircle, null, tint = WifiGreen,
                        modifier = Modifier.align(Alignment.TopEnd).padding(4.u()).size(26.u()),
                    )
                }
                if (focused) {
                    Text(
                        BundledWalls.title(f), color = TextPrimary, fontSize = 15.us(), maxLines = 1,
                        modifier = Modifier.align(Alignment.BottomStart).background(Color(0xAA000000)).fillMaxWidth().padding(4.u()),
                    )
                }
            }
        }
    }
}

// ---- Weather Settings --------------------------------------------------------------------------

@Composable
private fun WeatherPage(
    prefs: Prefs,
    wallMode: String,
    onWallMode: (String) -> Unit,
    place: Place,
    onPlace: (Place) -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val first = remember { FocusRequester() }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Place>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var links by remember { mutableStateOf(prefs.wallLinks) }
    var busy by remember { mutableStateOf(false) }
    val bgOn = wallMode == "weather"
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { first.requestFocus() }
    }

    PageList("Weather Settings") {
        item { Text("Weather area: ${place.name}", color = TextPrimary, fontSize = 24.us(), fontWeight = FontWeight.Medium) }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                label = { Text("Search your city or town") },
                singleLine = true,
                textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth().focusRequester(first),
            )
        }
        item {
            SettingsButton(if (searching) "Searching..." else "Search", onClick = {
                if (searching || query.isBlank()) return@SettingsButton
                scope.launch {
                    searching = true
                    results = searchPlaces(query)
                    status = if (results.isEmpty()) "No place found. Check the spelling and the internet connection." else null
                    searching = false
                }
            })
        }
        status?.let { st -> item { Text(st, color = TextDim, fontSize = 20.us()) } }
        items(results) { p ->
            SettingsButton(p.name, onClick = {
                onPlace(p)
                results = emptyList()
                query = ""
                Toast.makeText(ctx, "Weather area: ${p.name}", Toast.LENGTH_SHORT).show()
            })
        }
        item { SettingsButton("Use default area (${Place.DEFAULT.name})", { onPlace(Place.DEFAULT) }) }

        item { SectionTitle("Background") }
        item {
            ToggleRow(
                "Weather condition background", bgOn,
                { onWallMode(if (bgOn) "static" else "weather") }, Modifier.fillMaxWidth(),
            )
        }
        if (bgOn) {
            item {
                Text(
                    "The wallpaper changes with the weather. Paste a photo link for any weather; " +
                        "empty ones use the built-in scene. Blur is set in Display Settings.",
                    color = TextDim, fontSize = 19.us(),
                )
            }
            items(WallCond.values().toList()) { c ->
                OutlinedTextField(
                    value = links[c.name] ?: "",
                    onValueChange = { links = links + (c.name to it); status = null },
                    label = { Text(c.label) },
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 20.us(), color = TextPrimary),
                    colors = fieldColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item {
                SettingsButton(if (busy) "Downloading..." else "Download images", onClick = {
                    if (busy) return@SettingsButton
                    scope.launch {
                        busy = true
                        prefs.wallLinks = prefs.wallLinks.filterKeys { it == "custom" } +
                            links.filterValues { it.isNotBlank() }
                        var tried = 0
                        var ok = 0
                        for (c in WallCond.values()) {
                            val u = links[c.name] ?: continue
                            if (u.isBlank()) continue
                            tried++
                            if (WallpaperStore.download(ctx.applicationContext, u, c.name)) ok++
                        }
                        WallpaperStore.bump()
                        status = if (tried == 0) "Enter at least one image link first." else "Downloaded $ok of $tried images."
                        busy = false
                    }
                })
            }
            item {
                SettingsButton("Remove downloaded weather images", onClick = {
                    WallCond.values().forEach { WallpaperStore.file(ctx.applicationContext, it.name).delete() }
                    WallpaperStore.bump()
                    status = "Downloaded weather images removed."
                })
            }
        }
        item { SettingsButton("Back", onBack) }
    }
}

// ---- Backup & sync (Google Drive) ------------------------------------------------------------

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private val SheetBg = Color(0xFF1B1E24)

@Composable
private fun BackupPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val first = remember { FocusRequester() }
    var codeDialog by remember { mutableStateOf<DeviceCode?>(null) }
    var confirmRestore by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    fun toast() {
        if (DriveSync.message.isNotEmpty()) Toast.makeText(ctx, DriveSync.message, Toast.LENGTH_LONG).show()
    }
    val act = ctx.findActivity()
    val gms = remember { DriveSync.playServicesPresent() }
    var perm by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.GET_ACCOUNTS) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perm = it }
    var accountsTick by remember { mutableIntStateOf(0) }
    // Coming back from the "add account" screen: look again.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        perm = ContextCompat.checkSelfPermission(ctx, Manifest.permission.GET_ACCOUNTS) == PackageManager.PERMISSION_GRANTED
        accountsTick++
    }
    val accounts = remember(perm, accountsTick) { DriveSync.googleAccounts() }
    fun addAccount() {
        val tries = listOf(
            Intent(Settings.ACTION_ADD_ACCOUNT).putExtra(Settings.EXTRA_ACCOUNT_TYPES, arrayOf("com.google")),
            Intent(Settings.ACTION_SYNC_SETTINGS),
            Intent(Settings.ACTION_SETTINGS),
        )
        val ok = tries.any { i ->
            runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
        }
        if (!ok) Toast.makeText(ctx, "This TV has no screen to add a Google account", Toast.LENGTH_LONG).show()
    }
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { first.requestFocus() }
    }
    // Needed to see the Google account that is signed in on this TV.
    LaunchedEffect(perm, DriveSync.signedIn) {
        if (!DriveSync.signedIn && !perm && gms) runCatching { permLauncher.launch(Manifest.permission.GET_ACCOUNTS) }
    }
    // A Google account is already on this TV: connect to it automatically (once per app run).
    LaunchedEffect(accounts, DriveSync.signedIn) {
        if (!DriveSync.signedIn && gms && accounts.isNotEmpty() && !DriveSync.autoAttachTried && act != null) {
            DriveSync.autoAttachTried = true
            DriveSync.attachDeviceAccount(act, accounts[0])
            toast()
        }
    }

    PageList("Backup & sync (Google Drive)") {
        item {
            Text(
                "Saves all launcher settings and data (app order, hidden and locked apps, lock code, names, " +
                    "icons, stream links, wallpaper and screensaver settings) to a private folder in your " +
                    "own Google Drive. Restore them any time, for example on a new TV.",
                color = TextDim, fontSize = 19.us(),
            )
        }
        if (!DriveSync.signedIn) {
            if (accounts.isNotEmpty() && gms) {
                item {
                    Text(
                        "Google account found on this TV. Connecting to it automatically...",
                        color = TextPrimary, fontSize = 20.us(),
                    )
                }
                itemsIndexed(accounts) { i, name ->
                    SettingsButton(
                        "Use $name",
                        { scope.launch { act?.let { DriveSync.attachDeviceAccount(it, name) }; toast() } },
                        if (i == 0) Modifier.focusRequester(first) else Modifier,
                        subtitle = "Google may ask for permission once",
                    )
                }
            } else {
                item {
                    Text(
                        if (!gms) "Google Play Services is not on this TV, so a Google account cannot be added here. " +
                            "Use the phone code below."
                        else if (!perm) "Allow this launcher to see the Google accounts on this TV."
                        else "No Google account found on this TV.",
                        color = TextPrimary, fontSize = 20.us(),
                    )
                }
                if (gms && !perm) {
                    item {
                        SettingsButton(
                            "Allow access to accounts",
                            { runCatching { permLauncher.launch(Manifest.permission.GET_ACCOUNTS) } },
                            Modifier.focusRequester(first),
                        )
                    }
                }
                if (gms) {
                    item {
                        SettingsButton(
                            "Add a Google account to this TV",
                            { addAccount() },
                            if (perm) Modifier.focusRequester(first) else Modifier,
                            subtitle = "Opens the TV's own account screen. Come back here afterwards",
                        )
                    }
                }
            }
            if (DriveSync.configured) {
                item {
                    SettingsButton(
                        "Sign in with a phone code",
                        {
                            scope.launch {
                                val dc = DriveSync.beginSignIn()
                                if (dc != null) codeDialog = dc else toast()
                            }
                        },
                        if (!gms) Modifier.focusRequester(first) else Modifier,
                        subtitle = "Open google.com/device on your phone and enter a code",
                    )
                }
            } else {
                item {
                    Text(
                        "Phone-code sign-in is not set up in this build: add your Google client ID and secret " +
                            "in DriveConfig.kt (see README).",
                        color = Color(0xFFE8A87C), fontSize = 19.us(),
                    )
                }
            }
            item {
                SettingsButton(
                    "Reset all settings to default",
                    { confirmReset = true },
                    subtitle = "Back to a fresh launcher. Your Google Drive copy is not touched",
                )
            }
            item {
                val noOtherButton = !gms && !DriveSync.configured
                SettingsButton("Back", onBack, if (noOtherButton) Modifier.focusRequester(first) else Modifier)
            }
        } else {
            item {
                val status = when {
                    DriveSync.busy -> "Working..."
                    DriveSync.lastBackup > 0L ->
                        "Last backup: " + SimpleDateFormat("dd MMM yyyy, h:mm a", Locale.ENGLISH).format(Date(DriveSync.lastBackup))
                    else -> "No backup made from this TV yet"
                }
                Column {
                    Text(status, color = TextPrimary, fontSize = 22.us(), fontWeight = FontWeight.Medium)
                    Text(
                        "Account: " + DriveSync.accountName.ifEmpty { "Google Drive (phone code)" },
                        color = TextDim, fontSize = 19.us(),
                    )
                }
            }
            item {
                SettingsButton(
                    "Back up now",
                    { if (!DriveSync.busy) scope.launch { DriveSync.backup(manual = true); toast() } },
                    Modifier.focusRequester(first),
                    subtitle = "Upload everything to Google Drive",
                )
            }
            item {
                SettingsButton(
                    "Restore from Google Drive",
                    { if (!DriveSync.busy) confirmRestore = true },
                    subtitle = "Replaces all settings on this TV with the saved copy",
                )
            }
            item {
                ToggleRow(
                    "Auto sync: upload changes automatically", DriveSync.autoSync,
                    { DriveSync.enableAutoSync(!DriveSync.autoSync); toast() },
                    Modifier.fillMaxWidth(),
                )
            }
            item { SettingsButton("Sign out", { DriveSync.signOut(); toast() }) }
            item {
                SettingsButton(
                    "Reset all settings to default",
                    { confirmReset = true },
                    subtitle = "Back to a fresh launcher. Your Google Drive copy is not touched",
                )
            }
            item { SettingsButton("Back", onBack) }
        }
    }

    codeDialog?.let { dc ->
        DriveCodeDialog(
            dc,
            onDone = { codeDialog = null; toast() },
            onCancel = { codeDialog = null },
        )
    }
    if (confirmReset) {
        ConfirmDialog(
            title = "Reset all settings to default?",
            text = "This clears everything you set up in the launcher: app order, hidden and locked apps, lock " +
                "code, custom names and icons, stream links, wallpaper, screensaver and remote button settings. " +
                "Auto sync is switched off so your copy in Google Drive stays untouched. The launcher reloads afterwards.",
            okText = "Reset everything",
            onOk = {
                confirmReset = false
                DriveSync.resetAllSettings()
                toast()
                ctx.findActivity()?.recreate()
            },
            onCancel = { confirmReset = false },
        )
    }
    if (confirmRestore) {
        ConfirmDialog(
            title = "Restore from Google Drive?",
            text = "This replaces the app order, hidden and locked apps, lock code, names, icons, links and " +
                "all other settings on this TV with your saved copy. The launcher reloads afterwards.",
            okText = "Restore",
            onOk = {
                confirmRestore = false
                scope.launch {
                    val ok = DriveSync.restore()
                    toast()
                    if (ok) ctx.findActivity()?.recreate()
                }
            },
            onCancel = { confirmRestore = false },
        )
    }
}

/** Shows the code to type on a phone, and waits for the approval. */
@Composable
private fun DriveCodeDialog(dc: DeviceCode, onDone: (Boolean) -> Unit, onCancel: () -> Unit) {
    val cancelFocus = remember { FocusRequester() }
    val shape = RoundedCornerShape(16.u())
    LaunchedEffect(dc) {
        val ok = DriveSync.finishSignIn(dc)
        onDone(ok)
    }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { cancelFocus.requestFocus() }
    }
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.width(620.u()).clip(shape).background(SheetBg).border(2.u(), FocusBorder, shape).padding(24.u()),
            verticalArrangement = Arrangement.spacedBy(10.u()),
        ) {
            Text("Sign in to Google Drive", color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            Text("1. On your phone or computer open:", color = TextDim, fontSize = 20.us())
            Text(
                dc.url.removePrefix("https://"), color = TextPrimary, fontSize = 30.us(),
                fontWeight = FontWeight.Medium,
            )
            Text("2. Enter this code and approve:", color = TextDim, fontSize = 20.us())
            Text(
                dc.userCode, color = TextPrimary, fontSize = 52.us(), fontWeight = FontWeight.Medium,
                letterSpacing = 4.us(),
            )
            Text("Waiting for approval...", color = TextDim, fontSize = 18.us())
            DialogButton("Cancel", Modifier.focusRequester(cancelFocus), onCancel)
        }
    }
}

@Composable
private fun ConfirmDialog(title: String, text: String, okText: String, onOk: () -> Unit, onCancel: () -> Unit) {
    val cancelFocus = remember { FocusRequester() }
    val shape = RoundedCornerShape(16.u())
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { cancelFocus.requestFocus() }
    }
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.width(560.u()).clip(shape).background(SheetBg).border(2.u(), FocusBorder, shape).padding(24.u()),
            verticalArrangement = Arrangement.spacedBy(14.u()),
        ) {
            Text(title, color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
            Text(text, color = TextDim, fontSize = 20.us())
            Row(horizontalArrangement = Arrangement.spacedBy(12.u())) {
                DialogButton("Cancel", Modifier.focusRequester(cancelFocus), onCancel)
                DialogButton(okText, onClick = onOk)
            }
        }
    }
}

// ---- Shared pieces ---------------------------------------------------------------------------

@Composable
internal fun PageList(title: String, content: LazyListScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 60.u(), vertical = 28.u()),
        verticalArrangement = Arrangement.spacedBy(10.u()),
    ) {
        item { Text(title, color = TextPrimary, fontSize = 34.us(), fontWeight = FontWeight.Medium) }
        content()
    }
}

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(8.u()))
    Text(text, color = TextPrimary, fontSize = 26.us(), fontWeight = FontWeight.Medium)
}

/** Focusable tick box row, same height as a text field so it sits level beside one. */
@Composable
private fun ToggleRow(text: String, checked: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        modifier
            .height(56.dp)
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onToggle)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = checked, onCheckedChange = null,
            colors = CheckboxDefaults.colors(
                checkedColor = TextPrimary, checkmarkColor = BgColor, uncheckedColor = TextDim,
            ),
        )
        Spacer(Modifier.width(12.u()))
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 22.us(), maxLines = 1,
            style = TextStyle(lineHeight = 28.us(), lineHeightStyle = MidLine),
        )
    }
}

/** Tick row for lists of apps (and "Select all"). */
@Composable
private fun CheckRow(text: String, checked: Boolean, onToggle: () -> Unit, pkg: String? = null) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        Modifier
            .fillMaxWidth()
            .height(62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onToggle)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = checked, onCheckedChange = null,
            colors = CheckboxDefaults.colors(
                checkedColor = TextPrimary, checkmarkColor = BgColor, uncheckedColor = TextDim,
            ),
        )
        Spacer(Modifier.width(10.u()))
        if (pkg != null) {
            AppIcon(pkg, 40.u())
            Spacer(Modifier.width(14.u()))
        }
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
        )
    }
}

@Composable
private fun RadioRow(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        modifier
            .fillMaxWidth()
            .height(62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(
            selected = selected, onClick = null,
            colors = RadioButtonDefaults.colors(selectedColor = TextPrimary, unselectedColor = TextDim),
        )
        Spacer(Modifier.width(12.u()))
        Text(
            text, color = if (focused) TextPrimary else TextDim, fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
        )
    }
}

/** A value you change with Left / Right on the remote (or OK to step up). */
@Composable
private fun StepperRow(label: String, value: String, onLeft: () -> Unit, onRight: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        Modifier
            .fillMaxWidth()
            .height(62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .onPreviewKeyEvent { ev ->
                when {
                    ev.type != KeyEventType.KeyDown -> false
                    ev.key == Key.DirectionLeft -> { onLeft(); true }
                    ev.key == Key.DirectionRight -> { onRight(); true }
                    else -> false
                }
            }
            .clickable(onClick = onRight)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label, color = if (focused) TextPrimary else TextDim, fontSize = 24.us(), maxLines = 1,
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
            modifier = Modifier.weight(1f),
        )
        Icon(Icons.Outlined.ChevronLeft, null, tint = TextDim, modifier = Modifier.size(30.u()))
        Text(
            value, color = TextPrimary, fontSize = 24.us(), fontWeight = FontWeight.Medium, maxLines = 1,
            modifier = Modifier.width(110.u()),
            style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
        )
        Icon(Icons.Outlined.ChevronRight, null, tint = TextDim, modifier = Modifier.size(30.u()))
    }
}

@Composable
internal fun SettingsButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    pkg: String? = null,
    subtitle: String? = null,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.u())
    Row(
        modifier
            .fillMaxWidth()
            .height(if (subtitle != null) 78.u() else 62.u())
            .clip(shape)
            .background(if (focused) FocusFill else Color(0xFF181A1F))
            .border(2.u(), if (focused) FocusBorder else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 18.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (pkg != null) {
            AppIcon(pkg, 40.u())
            Spacer(Modifier.width(14.u()))
        }
        Column(verticalArrangement = Arrangement.Center) {
            Text(
                text, color = if (focused) TextPrimary else DateColor, fontSize = 24.us(), maxLines = 1,
                style = TextStyle(lineHeight = 30.us(), lineHeightStyle = MidLine),
            )
            if (subtitle != null) {
                Text(
                    subtitle, color = TextDim, fontSize = 18.us(), maxLines = 1,
                    style = TextStyle(lineHeight = 24.us(), lineHeightStyle = MidLine),
                )
            }
        }
    }
}
