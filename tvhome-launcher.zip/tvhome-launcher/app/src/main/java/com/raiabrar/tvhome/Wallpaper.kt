package com.raiabrar.tvhome

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Random

/** Downloaded wallpaper photos (custom image and optional per-weather photos). */
internal object WallpaperStore {
    /** Bumped whenever images are saved / removed so every wallpaper reloads. */
    var tick by mutableIntStateOf(0)
        private set

    private const val UA =
        "Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

    fun bump() { tick++ }

    private fun dir(ctx: Context) = File(ctx.filesDir, "wallpapers").also { it.mkdirs() }

    fun file(ctx: Context, key: String) = File(dir(ctx), key.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".jpg")

    fun clear(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
        tick++
    }

    /** Downloads an image link, shrinks it to at most ~1920 px wide and stores it under [key]. */
    suspend fun download(ctx: Context, url: String, key: String): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val u = url.trim().let { if (it.startsWith("http")) it else "https://$it" }
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 10_000
            c.readTimeout = 20_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            val bytes = try {
                if (c.responseCode != 200) return@runCatching false
                c.inputStream.use { it.readBytes() }
            } finally {
                c.disconnect()
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0) return@runCatching false
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1920) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return@runCatching false
            file(ctx, key).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            true
        }.getOrDefault(false)
    }
}

/** Built-in wallpaper scenes (used when no photo is set for a weather condition). */
internal object SceneArt {
    private const val W = 640
    private const val H = 360
    private val cache = HashMap<WallCond, Bitmap>()

    @Synchronized
    fun render(c: WallCond): Bitmap = cache.getOrPut(c) { draw(c) }

    private fun draw(c: WallCond): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val rnd = Random(7)

        fun sky(top: Int, bottom: Int) {
            p.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), top, bottom, Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p)
            p.shader = null
        }
        fun glow(x: Float, y: Float, r: Float, col: Int) {
            p.shader = RadialGradient(x, y, r, col, col and 0x00FFFFFF, Shader.TileMode.CLAMP)
            cv.drawCircle(x, y, r, p)
            p.shader = null
        }
        fun disc(x: Float, y: Float, r: Float, col: Int) { p.color = col; cv.drawCircle(x, y, r, p) }
        fun cloud(x: Float, y: Float, s: Float, col: Int) {
            p.color = col
            cv.drawCircle(x, y, 22 * s, p)
            cv.drawCircle(x + 26 * s, y - 12 * s, 28 * s, p)
            cv.drawCircle(x + 58 * s, y, 24 * s, p)
            cv.drawCircle(x + 30 * s, y + 8 * s, 24 * s, p)
        }
        fun hills(c1: Int, c2: Int) {
            p.color = c1
            val a = Path()
            a.moveTo(0f, 270f); a.quadTo(160f, 200f, 330f, 262f); a.quadTo(500f, 320f, 640f, 240f)
            a.lineTo(640f, 360f); a.lineTo(0f, 360f); a.close()
            cv.drawPath(a, p)
            p.color = c2
            val b = Path()
            b.moveTo(0f, 310f); b.quadTo(200f, 262f, 400f, 318f); b.quadTo(540f, 350f, 640f, 296f)
            b.lineTo(640f, 360f); b.lineTo(0f, 360f); b.close()
            cv.drawPath(b, p)
        }
        fun streaks(n: Int, col: Int) {
            p.color = col
            p.strokeWidth = 2f
            repeat(n) {
                val x = rnd.nextFloat() * W
                val y = rnd.nextFloat() * H
                cv.drawLine(x, y, x - 6f, y + 18f, p)
            }
        }
        fun dots(n: Int, col: Int, maxR: Float) {
            p.color = col
            repeat(n) { cv.drawCircle(rnd.nextFloat() * W, rnd.nextFloat() * H * 0.85f, 0.8f + rnd.nextFloat() * maxR, p) }
        }

        when (c) {
            WallCond.SUNNY -> {
                sky(0xFF3D8FD6.toInt(), 0xFFBFE3F7.toInt())
                glow(500f, 86f, 190f, 0xCCFFE9A8.toInt())
                disc(500f, 86f, 40f, 0xFFFFF4C9.toInt())
                cloud(70f, 80f, 1.1f, 0xE6FFFFFF.toInt())
                cloud(250f, 130f, 0.8f, 0xCCFFFFFF.toInt())
                hills(0xFF5E9A5B.toInt(), 0xFF3F7A4A.toInt())
            }
            WallCond.NIGHT -> {
                sky(0xFF0B1230.toInt(), 0xFF2A3F73.toInt())
                dots(110, 0xFFE8EEFF.toInt(), 1.3f)
                glow(470f, 78f, 120f, 0x66BFD0FF.toInt())
                disc(470f, 78f, 32f, 0xFFF4F1DC.toInt())
                disc(484f, 70f, 28f, 0xFF16224A.toInt())
                hills(0xFF0A1128.toInt(), 0xFF060B1C.toInt())
            }
            WallCond.CLOUDY -> {
                sky(0xFF56697D.toInt(), 0xFFA9B8C6.toInt())
                cloud(40f, 70f, 1.5f, 0xCCD5DDE4.toInt())
                cloud(300f, 50f, 1.7f, 0xCCC4CFD9.toInt())
                cloud(150f, 150f, 1.3f, 0xCCB4C1CD.toInt())
                cloud(420f, 170f, 1.4f, 0xCCCDD7DF.toInt())
                hills(0xFF4A5B64.toInt(), 0xFF38474F.toInt())
            }
            WallCond.RAIN -> {
                sky(0xFF2A3644.toInt(), 0xFF5B6E80.toInt())
                cloud(20f, 50f, 1.7f, 0xFF3B4A5B.toInt())
                cloud(280f, 40f, 1.9f, 0xFF33414F.toInt())
                cloud(460f, 70f, 1.5f, 0xFF3F4F60.toInt())
                streaks(170, 0x88C9D8E6.toInt())
                hills(0xFF2E3A44.toInt(), 0xFF222C34.toInt())
            }
            WallCond.SNOW -> {
                sky(0xFF7E92A8.toInt(), 0xFFDCE6F0.toInt())
                cloud(60f, 60f, 1.4f, 0xCCF2F6FA.toInt())
                cloud(330f, 90f, 1.5f, 0xCCE8EEF4.toInt())
                dots(190, 0xFFFFFFFF.toInt(), 2.2f)
                hills(0xFFEFF4F9.toInt(), 0xFFD3DEE8.toInt())
            }
            WallCond.STORM -> {
                sky(0xFF1B1730.toInt(), 0xFF4A4668.toInt())
                cloud(10f, 50f, 1.8f, 0xFF2A2640.toInt())
                cloud(300f, 30f, 2.1f, 0xFF231F38.toInt())
                cloud(470f, 70f, 1.6f, 0xFF2D2946.toInt())
                glow(330f, 150f, 150f, 0x55F2E8A0.toInt())
                p.color = 0xFFF5E27A.toInt()
                val bolt = Path()
                bolt.moveTo(340f, 110f); bolt.lineTo(312f, 190f); bolt.lineTo(334f, 190f)
                bolt.lineTo(318f, 262f); bolt.lineTo(372f, 170f); bolt.lineTo(348f, 170f); bolt.lineTo(366f, 110f)
                bolt.close()
                cv.drawPath(bolt, p)
                streaks(150, 0x77AEB0CC.toInt())
                hills(0xFF171428.toInt(), 0xFF0F0D1C.toInt())
            }
        }
        return bmp
    }
}

private fun scaleDown(b: Bitmap, maxW: Int): Bitmap =
    if (b.width <= maxW) b
    else Bitmap.createScaledBitmap(b, maxW, (b.height.toLong() * maxW / b.width).toInt().coerceAtLeast(1), true)

/**
 * Blur by shrinking and letting the display scale it back up smoothly. Works on every Android
 * version (no RenderEffect needed). 0 % = sharp, 100 % = very soft. 40 % is a clearly soft look.
 */
internal fun softBitmap(src: Bitmap, pct: Int): Bitmap {
    if (pct <= 0) return src
    val f = Math.pow(1.0 - pct.coerceIn(0, 100) / 100.0, 2.0).toFloat().coerceAtLeast(0.025f)
    val w = (src.width * f).toInt().coerceAtLeast(16)
    val h = (src.height * f).toInt().coerceAtLeast(9)
    var cur = src
    while (cur.width / 2 > w) cur = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
    return Bitmap.createScaledBitmap(cur, w, h, true)
}

/** Wallpapers bundled in assets/wallpapers (from the cleanyourtv project, see THIRD_PARTY.md). */
internal object BundledWalls {
    fun list(ctx: Context): List<String> =
        runCatching { ctx.assets.list("wallpapers")?.filter { it.endsWith(".jpg") }?.sorted() }.getOrNull() ?: emptyList()

    /** Nice name from the file name: "ambient-glass-01.jpg" -> "Ambient glass 01". */
    fun title(file: String): String =
        file.removeSuffix(".jpg").replace('-', ' ').replace('_', ' ').replaceFirstChar { it.uppercase() }

    fun load(ctx: Context, file: String, maxW: Int, thumb: Boolean = false): Bitmap? = runCatching {
        ctx.assets.open("wallpapers/$file").use { ins ->
            val o = BitmapFactory.Options().apply { inSampleSize = if (thumb) 8 else 1 }
            BitmapFactory.decodeStream(ins, null, o)
        }?.let { scaleDown(it, maxW) }
    }.getOrNull()
}

/** The wallpaper for the current setting: a downloaded photo if there is one, else a built-in scene. */
internal fun loadWallpaper(ctx: Context, cond: WallCond, mode: String, blurPct: Int): Bitmap? {
    if (mode == "none" || mode == "static") return null
    if (mode.startsWith("pic:")) {
        return BundledWalls.load(ctx, mode.removePrefix("pic:"), 960)?.let { softBitmap(it, blurPct) }
    }
    val file = WallpaperStore.file(ctx, if (mode == "custom") "custom" else cond.name)
    val photo = if (file.exists()) runCatching { BitmapFactory.decodeFile(file.path) }.getOrNull() else null
    val src = photo?.let { scaleDown(it, 960) } ?: SceneArt.render(cond)
    return softBitmap(src, blurPct)
}

/** Full-screen blurred wallpaper with a light dark overlay so text stays readable. */
@Composable
internal fun WallpaperLayer(cond: WallCond, mode: String, blurPct: Int, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val tick = WallpaperStore.tick
    val bmp by produceState<ImageBitmap?>(null, cond, mode, blurPct, tick) {
        value = withContext(Dispatchers.Default) {
            runCatching { loadWallpaper(ctx, cond, mode, blurPct)?.asImageBitmap() }.getOrNull()
        }
    }
    Box(modifier.background(BgColor)) {
        bmp?.let {
            Image(
                it, contentDescription = null, modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop, filterQuality = FilterQuality.High,
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.28f)))
        }
    }
}
