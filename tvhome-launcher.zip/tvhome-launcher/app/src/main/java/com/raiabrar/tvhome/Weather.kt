package com.raiabrar.tvhome

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AcUnit
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.NightsStay
import androidx.compose.material.icons.outlined.Thunderstorm
import androidx.compose.material.icons.outlined.Umbrella
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Where the weather comes from. Default Karachi; change it in Launcher Settings > Weather. */
internal data class Place(val name: String, val lat: Double, val lon: Double) {
    companion object { val DEFAULT = Place("Karachi", 24.8607, 67.0011) }
}

/** Today's reading plus tomorrow's forecast (tomorrowC / tomorrowCode are null if unknown). */
internal data class Weather(
    val tempC: Int, val code: Int, val isDay: Boolean,
    val tomorrowC: Int? = null, val tomorrowCode: Int? = null,
)

/** Weather looks the launcher wallpaper can match. */
internal enum class WallCond(val label: String) {
    SUNNY("Sunny"), NIGHT("Clear night"), CLOUDY("Cloudy"), RAIN("Rain"), SNOW("Snow"), STORM("Storm"),
}

internal fun wallCond(w: Weather?): WallCond = when {
    w == null -> WallCond.CLOUDY
    w.code in 95..99 -> WallCond.STORM
    w.code in 71..77 || w.code == 85 || w.code == 86 -> WallCond.SNOW
    w.code in 51..67 || w.code in 80..82 -> WallCond.RAIN
    w.code <= 1 -> if (w.isDay) WallCond.SUNNY else WallCond.NIGHT
    else -> WallCond.CLOUDY
}

internal fun weatherIcon(w: Weather?): ImageVector = iconFor(wallCond(w))

/** Icon for tomorrow's forecast (always the daytime look). */
internal fun tomorrowIcon(w: Weather?): ImageVector =
    iconFor(wallCond(w?.tomorrowCode?.let { Weather(0, it, true) }))

private fun iconFor(c: WallCond): ImageVector = when (c) {
    WallCond.SUNNY -> Icons.Outlined.WbSunny
    WallCond.NIGHT -> Icons.Outlined.NightsStay
    WallCond.RAIN -> Icons.Outlined.Umbrella
    WallCond.SNOW -> Icons.Outlined.AcUnit
    WallCond.STORM -> Icons.Outlined.Thunderstorm
    WallCond.CLOUDY -> Icons.Outlined.Cloud
}

private suspend fun fetchWeather(p: Place): Weather? = withContext(Dispatchers.IO) {
    runCatching {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}" +
                "&current=temperature_2m,weather_code,is_day" +
                "&daily=weather_code,temperature_2m_max&forecast_days=2&timezone=auto"
        )
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            val cur = root.getJSONObject("current")
            val daily = root.optJSONObject("daily")
            val tmrC = daily?.optJSONArray("temperature_2m_max")?.let { if (it.length() > 1) Math.round(it.getDouble(1)).toInt() else null }
            val tmrCode = daily?.optJSONArray("weather_code")?.let { if (it.length() > 1) it.getInt(1) else null }
            Weather(
                Math.round(cur.getDouble("temperature_2m")).toInt(),
                cur.getInt("weather_code"),
                cur.optInt("is_day", 1) == 1,
                tmrC, tmrCode,
            )
        } finally {
            c.disconnect()
        }
    }.getOrNull()
}

/**
 * Current weather, refreshed whenever [refreshKey] changes (TV on / launcher resumes), then every
 * 15 minutes. If the network is not up yet right after power-on, retries every 10 seconds.
 */
@Composable
internal fun rememberWeather(refreshKey: Int, place: Place): Weather? {
    var weather by remember { mutableStateOf<Weather?>(null) }
    LaunchedEffect(refreshKey, place) {
        while (true) {
            val w = fetchWeather(place)
            if (w != null) {
                weather = w
                delay(15 * 60 * 1000L)
            } else {
                delay(10_000L)
            }
        }
    }
    return weather
}

/** Looks a town / city up by name (Open-Meteo geocoding, no key needed). Empty list if nothing found. */
internal suspend fun searchPlaces(query: String): List<Place> = withContext(Dispatchers.IO) {
    runCatching {
        val q = java.net.URLEncoder.encode(query.trim(), "UTF-8")
        val c = URL("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=8&language=en&format=json")
            .openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            val arr = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).optJSONArray("results")
            val out = mutableListOf<Place>()
            if (arr != null) for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val label = listOf(o.optString("name"), o.optString("admin1"), o.optString("country"))
                    .filter { it.isNotBlank() }.distinct().joinToString(", ")
                out += Place(label, o.getDouble("latitude"), o.getDouble("longitude"))
            }
            out
        } finally {
            c.disconnect()
        }
    }.getOrDefault(emptyList())
}
